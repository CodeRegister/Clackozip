import React from 'react';
import ReactDOM from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import './fonts.css';
import './styles.css';
import App from './App';
import { AppProvider } from './AppProvider';
import { database, initializeDatabase } from './core/database';

async function main() {
  const root = ReactDOM.createRoot(document.getElementById('root')!);
  root.render(
    <div className="startup-error">
      <h1>Opening your little corner.</h1>
      <p>Loading the study material saved on this device…</p>
    </div>,
  );
  try {
    await initializeDatabase();
    const profiles = await database.profiles.toArray();
    const savedId = localStorage.getItem('clacko-profile');
    const profileId = profiles.find((profile) => profile.id === savedId)?.id ?? profiles[0].id;
    root.render(
      <React.StrictMode>
        <AppProvider initialProfileId={profileId}>
          <App />
        </AppProvider>
      </React.StrictMode>,
    );
  } catch {
    root.render(
      <div className="startup-error">
        <h1>A little storage hiccup.</h1>
        <p>
          Clacko needs browser storage to keep your cards safe. Allow storage for this site, then
          try again.
        </p>
        <button onClick={() => location.reload()}>Try again</button>
      </div>,
    );
  }
}

void main();

const updateWorker = registerSW({
  onOfflineReady() {
    window.dispatchEvent(new Event('clacko-offline-ready'));
  },
  onNeedRefresh() {
    window.dispatchEvent(new Event('clacko-update'));
  },
});
window.addEventListener('clacko-apply-update', () => {
  void updateWorker(true);
});

import { useState, type ChangeEvent } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { createProfile, database, deleteProfile } from '../core/database';
import { exportProfile, inspectBackup, restoreBackup } from '../core/transfer';
import { Icon } from '../components/Icon';
import { Modal } from '../components/Modal';

export function ProfileSettings({ onClose }: { onClose: () => void }) {
  const { profileId, preferences, switchProfile, notify } = useApp();
  const profiles = useLiveQuery(() => database.profiles.toArray(), [], []);
  const [name, setName] = useState('');
  const [renaming, setRenaming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [backup, setBackup] = useState<Awaited<ReturnType<typeof inspectBackup>> | null>(null);
  const current = profiles.find((profile) => profile.id === profileId);

  async function addProfile() {
    if (!name.trim()) return;
    try {
      const id = await createProfile(name);
      switchProfile(id);
      onClose();
      notify('A fresh little corner, just for you.');
    } catch {
      notify('This profile could not be created.');
    }
  }

  async function downloadBackup() {
    setBusy(true);
    try {
      await exportProfile(profileId, preferences);
      notify('Your backup is ready. Keep it somewhere safe.');
    } catch (error) {
      notify((error as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function readBackup(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setBusy(true);
    try {
      setBackup(await inspectBackup(file));
    } catch (error) {
      notify((error as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function restore() {
    if (!backup) return;
    setBusy(true);
    try {
      const id = await restoreBackup(backup);
      switchProfile(id);
      onClose();
      notify('Everything is right where you left it. Welcome back.');
    } catch {
      notify('The backup could not be restored. Your existing profiles are unchanged.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title={backup ? 'A little homecoming.' : 'Your little corner.'} onClose={onClose}>
      {backup ? (
        <>
          <p className="muted">
            Restore “{backup.manifest.profile.name}” as a new profile. Your existing profiles will
            stay as they are.
          </p>
          <div className="backup-summary">
            <span>
              <strong>{backup.manifest.sets.length}</strong> study sets
            </span>
            <span>
              <strong>{backup.manifest.cards.length}</strong> cards
            </span>
            <span>
              <strong>{backup.assets.length}</strong> image & sound files
            </span>
            <span>
              <strong>{backup.manifest.sessions.length}</strong> sessions
            </span>
          </div>
          <p className="fine-print">
            <Icon name="check" size={14} />
            All included files passed their integrity checks.
          </p>
          <div className="modal-footer">
            <button className="button button-secondary" onClick={() => setBackup(null)}>
              Go back
            </button>
            <button
              className="button button-primary"
              disabled={busy}
              onClick={() => void restore()}
            >
              {busy ? 'Restoring…' : 'Bring it all back'}
              <Icon name="arrow" size={17} />
            </button>
          </div>
        </>
      ) : (
        <>
          <p className="muted">
            Different minds, different spaces. Everything stays on this device.
          </p>
          <div className="profile-list">
            {profiles.map((profile) => (
              <button
                className={`profile-row ${profile.id === profileId ? 'selected' : ''}`}
                key={profile.id}
                onClick={() => {
                  if (profile.id !== profileId) {
                    switchProfile(profile.id);
                    onClose();
                  }
                }}
              >
                <span className="profile-avatar">{profile.name.slice(0, 1).toUpperCase()}</span>
                <span>
                  <strong>{profile.name}</strong>
                  <small>
                    {profile.id === profileId ? 'You’re here' : 'A separate local profile'}
                  </small>
                </span>
                {profile.id === profileId && <Icon name="check" size={18} />}
              </button>
            ))}
          </div>
          <div className="profile-name-form">
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              placeholder={renaming ? 'A new name for your corner' : 'Name a new little corner'}
              aria-label={renaming ? 'New profile name' : 'New profile name'}
              maxLength={60}
            />
            <button
              className="button button-primary"
              disabled={!name.trim()}
              onClick={async () => {
                if (renaming) {
                  await database.profiles.update(profileId, { name: name.trim() });
                  setRenaming(false);
                  setName('');
                  notify('A new name. Same lovely corner.');
                } else await addProfile();
              }}
            >
              {renaming ? 'Save' : 'Create'}
              <Icon name={renaming ? 'check' : 'plus'} size={16} />
            </button>
          </div>
          <div className="profile-text-actions">
            <button
              className="text-button"
              onClick={() => {
                setRenaming(!renaming);
                setName(renaming ? '' : (current?.name ?? ''));
              }}
            >
              <Icon name="edit" size={14} />
              {renaming ? 'Cancel rename' : 'Rename current profile'}
            </button>
            {profiles.length > 1 && (
              <button
                className="text-button danger-text"
                onClick={async () => {
                  if (
                    !window.confirm(
                      `Delete “${current?.name}” and all of its study data? Export a backup first if you want to keep it.`,
                    )
                  )
                    return;
                  const next = profiles.find((profile) => profile.id !== profileId)!;
                  switchProfile(next.id);
                  await deleteProfile(profileId);
                  onClose();
                  notify('Profile deleted.');
                }}
              >
                <Icon name="trash" size={14} />
                Delete profile
              </button>
            )}
          </div>
          <div className="settings-divider" />
          <h3>Keep your good things safe.</h3>
          <p className="muted">
            Browser storage can be cleared. A backup keeps your cards, images, sounds, and progress
            together.
          </p>
          <div className="backup-actions">
            <button
              className="button button-secondary"
              disabled={busy}
              onClick={() => void downloadBackup()}
            >
              <Icon name="download" size={17} />
              {busy ? 'Working…' : 'Export profile'}
            </button>
            <label className={`button button-secondary file-button ${busy ? 'disabled' : ''}`}>
              <Icon name="upload" size={17} />
              Restore a backup
              <input
                disabled={busy}
                type="file"
                accept=".clacko,.zip"
                onChange={(event) => void readBackup(event)}
              />
            </label>
          </div>
          <button
            className="text-button storage-button"
            onClick={async () => {
              if (!navigator.storage?.persist) {
                notify(
                  'Persistent storage is not available in this browser. Keep regular backups.',
                );
                return;
              }
              const granted = await navigator.storage.persist();
              notify(
                granted
                  ? 'Your browser granted persistent storage. Keep backups too.'
                  : 'Your browser manages storage automatically. Regular backups are the safest way to keep your data.',
              );
            }}
          >
            <Icon name="shield" size={15} />
            Ask the browser to keep my data
          </button>
        </>
      )}
    </Modal>
  );
}

import { useEffect, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { createId, database } from '../core/database';
import { defaultKeyboardDesign } from '../core/design';
import { codeForCharacter, gymLessons, gymText, type GymExercise } from '../core/gym';
import { fingerForCode, keyboardLayouts, type KeyboardLayout } from '../core/keyboards';
import { calculateMetrics, formatDuration, graphemes } from '../core/typing';
import type { GymRun } from '../core/review';
import { Keyboard } from '../components/Keyboard';
import { TypingSurface } from '../components/TypingSurface';
import { Icon } from '../components/Icon';
import { ZenAtmosphere } from './ZenAtmosphere';

export function ClackoGym() {
  const { profileId, preferences, setPreferences, notify } = useApp();
  const runs = useLiveQuery(
    () => database.gymRuns.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const [lessonId, setLessonId] = useState(1);
  const [exercise, setExercise] = useState<GymExercise>('keys');
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);
  const [value, setValue] = useState('');
  const [target, setTarget] = useState('');
  const [elapsed, setElapsed] = useState(0);
  const [result, setResult] = useState<GymRun>();
  const [showFingers, setShowFingers] = useState(true);
  const [showKeyboard, setShowKeyboard] = useState(true);
  const [busy, setBusy] = useState(false);
  const [weakPractice, setWeakPractice] = useState(false);
  const inserted = useRef(0),
    correct = useRef(0),
    errors = useRef<Record<string, number>>({}),
    started = useRef<number | undefined>(undefined),
    baseTime = useRef(0),
    pasted = useRef(false),
    saving = useRef(false);
  const layout = preferences.keyboard?.layout ?? 'qwerty-us';
  const lesson = gymLessons[lessonId - 1];
  const history = runs.filter((run) => run.layout === layout);
  const passed = new Set(history.filter((run) => run.passed).map((run) => run.lessonId));
  const recommended = gymLessons.find((item) => !passed.has(item.id))?.id ?? 15;
  const weakTotals: Record<string, number> = {};
  history.forEach((run) =>
    Object.entries(run.errors).forEach(([code, count]) => {
      weakTotals[code] = (weakTotals[code] ?? 0) + count;
    }),
  );
  const weakCodes = Object.entries(weakTotals)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([code]) => code);
  const nextCode = codeForCharacter(target[value.length], layout);
  const metrics = calculateMetrics(value, target, inserted.current, correct.current, elapsed);

  useEffect(() => {
    if (!running || paused) return;
    const timer = setInterval(() => {
      if (started.current !== undefined)
        setElapsed(baseTime.current + (performance.now() - started.current) / 1000);
    }, 100);
    return () => clearInterval(timer);
  }, [running, paused]);
  useEffect(() => {
    const hide = () => {
      if (document.hidden && running) pause();
    };
    document.addEventListener('visibilitychange', hide);
    return () => document.removeEventListener('visibilitychange', hide);
  }, [running]);

  function start() {
    inserted.current = 0;
    correct.current = 0;
    errors.current = {};
    pasted.current = false;
    started.current = undefined;
    baseTime.current = 0;
    saving.current = false;
    setTarget(gymText(lessonId, layout, exercise, weakPractice ? weakCodes : []));
    setValue('');
    setElapsed(0);
    setResult(undefined);
    setPaused(false);
    setRunning(true);
  }
  function pause() {
    if (started.current !== undefined)
      baseTime.current += (performance.now() - started.current) / 1000;
    started.current = undefined;
    setElapsed(baseTime.current);
    setPaused(true);
  }
  function resume() {
    if (inserted.current) started.current = performance.now();
    setPaused(false);
  }
  function type(next: string, addition: string, offset: number, wasPasted: boolean) {
    if (paused) return;
    if (wasPasted) {
      pasted.current = true;
      notify('Pasted text is allowed for preview, but this run will not count toward progress.');
    }
    if (started.current === undefined) started.current = performance.now();
    if (!wasPasted)
      graphemes(addition).forEach((letter, index) => {
        inserted.current++;
        const expected = graphemes(target.slice(offset))[index];
        if (letter === expected) correct.current++;
        else {
          const code = codeForCharacter(expected, layout) ?? 'Other';
          errors.current[code] = (errors.current[code] ?? 0) + 1;
        }
      });
    setValue(next);
  }
  async function finish() {
    if (saving.current || !value.length) return;
    saving.current = true;
    setBusy(true);
    const duration =
      baseTime.current +
      (started.current === undefined ? 0 : (performance.now() - started.current) / 1000);
    const finalMetrics = calculateMetrics(
      value,
      target,
      inserted.current,
      correct.current,
      duration,
    );
    const completed = value === target;
    const run: GymRun = {
      id: createId(),
      profileId,
      layout,
      lessonId,
      exercise: weakPractice ? 'weak' : exercise,
      duration,
      wpm: finalMetrics.adjustedWpm,
      accuracy: finalMetrics.accuracy,
      passed: completed && finalMetrics.accuracy >= 95 && !pasted.current,
      characters: inserted.current,
      errors: errors.current,
      createdAt: Date.now(),
    };
    try {
      if (!pasted.current) await database.gymRuns.add(run);
      setResult(run);
      setRunning(false);
    } catch {
      notify('This practice could not be saved. Try again.');
      saving.current = false;
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="gym-page">
      <div className="studio-heading">
        <div>
          <div className="eyebrow muted">CLACKO GYM</div>
          <h1>
            Good habits. Happy hands<span className="heading-period">.</span>
          </h1>
          <p>Find your home row. Reach a little further. Keep typing at your own pace.</p>
        </div>
        <span className="gym-badge">
          <Icon name="keyboard" size={30} />
          <strong>{passed.size}/15</strong>
          <small>lessons practiced</small>
        </span>
      </div>
      <div className="gym-shell">
        <aside className="gym-lessons">
          <div className="eyebrow muted">YOUR NEXT SMALL STEP</div>
          <button
            className="text-button"
            disabled={running}
            onClick={() => {
              setLessonId(recommended);
              setResult(undefined);
            }}
          >
            Go to lesson {recommended}
            <Icon name="arrow" size={15} />
          </button>
          {gymLessons.map((item) => (
            <button
              key={item.id}
              disabled={running}
              className={`gym-lesson ${item.id === lessonId ? 'active' : ''}`}
              onClick={() => {
                setLessonId(item.id);
                setResult(undefined);
              }}
            >
              <span>{passed.has(item.id) ? '✓' : String(item.id).padStart(2, '0')}</span>
              <div>
                <strong>{item.title}</strong>
                <small>Lesson {item.id}</small>
              </div>
            </button>
          ))}
        </aside>
        <div className="gym-workspace">
          <div className="gym-workspace-heading">
            <span className="eyebrow muted">LESSON {lessonId}</span>
            <h2>{lesson.title}</h2>
            <p>{lesson.tip}</p>
          </div>
          {!running ? (
            <>
              <div className="setup-controls">
                <label className="field-label">
                  Your keyboard layout
                  <select
                    value={layout}
                    onChange={(event) =>
                      setPreferences({
                        keyboard: {
                          ...defaultKeyboardDesign(),
                          ...preferences.keyboard,
                          layout: event.target.value as KeyboardLayout,
                        },
                      })
                    }
                  >
                    {keyboardLayouts.map((item) => (
                      <option value={item.id} key={item.id}>
                        {item.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field-label">
                  Practice
                  <select
                    value={exercise}
                    onChange={(event) => setExercise(event.target.value as GymExercise)}
                  >
                    <option value="keys">Key drills</option>
                    <option value="words">Word drills</option>
                    <option value="text">Text practice</option>
                  </select>
                </label>
              </div>
              <p className="fine-print">
                Choose the same layout as your operating system. Clacko shows the keys and finger
                positions; it does not remap your computer’s keyboard. Early word/text drills use
                key patterns until enough letters are unlocked.
              </p>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={weakPractice}
                  disabled={!weakCodes.length}
                  onChange={(event) => setWeakPractice(event.target.checked)}
                />
                Focus on my tricky keys{!weakCodes.length && ' · available after practice'}
              </label>
              {result && (
                <div className="gym-result">
                  <h3>
                    {pasted.current
                      ? 'Preview complete'
                      : result.passed
                        ? 'A good little step forward.'
                        : 'Keep finding your rhythm.'}
                  </h3>
                  <div className="result-metrics">
                    <div>
                      <strong>{result.accuracy}%</strong>
                      <span>accuracy</span>
                    </div>
                    <div>
                      <strong>{pasted.current ? '—' : result.wpm}</strong>
                      <span>WPM</span>
                    </div>
                    <div>
                      <strong>{formatDuration(result.duration)}</strong>
                      <span>active time</span>
                    </div>
                  </div>
                  <p>
                    {pasted.current
                      ? 'Pasted practice does not count toward progress.'
                      : result.passed
                        ? 'Lesson progress saved. There is no speed requirement.'
                        : 'Complete the text with at least 95% accuracy to mark this lesson practiced.'}
                  </p>
                </div>
              )}
              <div className="row-actions">
                <button className="button button-primary button-large" onClick={start}>
                  {result ? 'Practice again' : 'Start practicing'}
                  <Icon name="arrow" size={18} />
                </button>
                {result?.passed && lessonId < 15 && (
                  <button
                    className="button button-secondary"
                    onClick={() => {
                      setLessonId(lessonId + 1);
                      setResult(undefined);
                    }}
                  >
                    Next lesson
                  </button>
                )}
              </div>
            </>
          ) : (
            <>
              <div className="session-topline">
                <span>Start with your first keystroke. No countdown.</span>
                <div className="row-actions">
                  <button className="text-button" onClick={() => (paused ? resume() : pause())}>
                    {paused ? 'Resume' : 'Rest a moment'}
                  </button>
                  <button
                    className="text-button"
                    onClick={() => {
                      setRunning(false);
                      setResult(undefined);
                    }}
                  >
                    Leave practice
                  </button>
                </div>
              </div>
              {paused ? (
                <div className="pause-overlay">
                  <h2>Relax your hands.</h2>
                  <button className="button button-primary" onClick={resume}>
                    Ready again
                  </button>
                </div>
              ) : (
                <TypingSurface
                  value={value}
                  target={target}
                  onChange={type}
                  label="Gym typing practice"
                />
              )}
              <div className="live-metrics">
                <span>
                  {metrics.accuracy}% <small>accuracy</small>
                </span>
                <span>
                  {pasted.current ? '—' : metrics.adjustedWpm} <small>WPM</small>
                </span>
                <span>
                  {Math.min(100, Math.round((value.length / target.length) * 100))}%{' '}
                  <small>complete</small>
                </span>
              </div>
              <div className="gym-key-hint">
                {nextCode ? (
                  <>
                    <strong>{nextCode === 'Space' ? 'Space' : target[value.length]}</strong>
                    <span>
                      {fingerForCode(nextCode)} · {nextCode}
                    </span>
                  </>
                ) : (
                  <span>Compare your text, then save your practice.</span>
                )}
              </div>
              <button
                className="button button-primary"
                disabled={busy || !value.length}
                onClick={() => void finish()}
              >
                {value === target ? 'Complete practice' : 'Finish this attempt'}
                <Icon name="check" size={17} />
              </button>
            </>
          )}
          <div className="gym-keyboard">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={showFingers}
                onChange={(event) => setShowFingers(event.target.checked)}
              />
              Show finger guide
            </label>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={showKeyboard}
                onChange={(event) => setShowKeyboard(event.target.checked)}
              />
              Show keyboard · turn off for blind practice
            </label>
            {showKeyboard && (
              <Keyboard targetCode={running ? nextCode : undefined} showFingers={showFingers} />
            )}
            <p className="fine-print">
              Left: pinky · ring · middle · index. Right: index · middle · ring · pinky. Thumbs use
              the spacebar.
            </p>
          </div>
          {history.length > 0 && (
            <details className="gym-history">
              <summary>Your recent practice · {history.length} attempts</summary>
              <div className="history-table-wrap">
                <table className="history-table">
                  <thead>
                    <tr>
                      <th>Lesson</th>
                      <th>Accuracy</th>
                      <th>WPM</th>
                      <th>When</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...history]
                      .sort((a, b) => b.createdAt - a.createdAt)
                      .slice(0, 8)
                      .map((run) => (
                        <tr key={run.id}>
                          <td>
                            {run.lessonId} · {run.exercise}
                          </td>
                          <td>{run.accuracy}%</td>
                          <td>{run.wpm}</td>
                          <td>{new Date(run.createdAt).toLocaleDateString()}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </details>
          )}
          <details className="zen-sound-controls">
            <summary>Practice atmosphere & music</summary>
            <ZenAtmosphere compact />
          </details>
          <p className="fine-print">
            Curriculum structure inspired by{' '}
            <a href="https://www.typingstudy.com/" target="_blank" rel="noreferrer">
              TypingStudy
            </a>
            . Clacko’s drills and lesson text are original. Try short sessions and keep your
            shoulders relaxed.
          </p>
        </div>
      </div>
    </div>
  );
}

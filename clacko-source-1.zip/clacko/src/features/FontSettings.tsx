import { useState } from 'react';
import { useApp } from '../appContext';
import { downloadFont, importFontFile } from '../core/fonts';
import type { Preferences } from '../core/types';
import { Icon } from '../components/Icon';

export function FontSettings() {
  const { preferences, setPreferences, notify } = useApp();
  const [fontName, setFontName] = useState('');
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);

  async function install(file?: File) {
    setBusy(true);
    try {
      const customFont = file
        ? await importFontFile(file, fontName)
        : await downloadFont(url, fontName);
      setPreferences({ customFont, fontFamily: 'custom' });
      notify('Your font is saved locally and ready for offline typing.');
    } catch (error) {
      notify(`${(error as Error).message} If the server blocks downloads, upload the font file.`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="panel-heading">
        <h2>Your words. Your font.</h2>
        <p>Choose one, upload one, or bring a link.</p>
      </div>
      <label className="field-label">
        Typing typeface
        <select
          value={preferences.fontFamily}
          onChange={(event) =>
            setPreferences({ fontFamily: event.target.value as Preferences['fontFamily'] })
          }
        >
          <option value="system">My device’s monospace</option>
          <option value="mono">JetBrains Mono</option>
          <option value="sans">Inter</option>
          {preferences.customFont && <option value="custom">{preferences.customFont.name}</option>}
        </select>
      </label>
      <label className="field-label">
        Font name
        <input
          value={fontName}
          onChange={(event) => setFontName(event.target.value)}
          placeholder="My favorite font"
          maxLength={70}
        />
      </label>
      <label className="field-label">
        Font or Google Fonts CSS link
        <input
          type="url"
          value={url}
          onChange={(event) => setUrl(event.target.value)}
          placeholder="https://…/my-font.woff2"
        />
      </label>
      <button
        className="button button-primary full-width"
        disabled={busy || !url.trim()}
        onClick={() => void install()}
      >
        <Icon name="download" size={15} />
        {busy ? 'Downloading font…' : 'Download & use font'}
      </button>
      <label className="button button-secondary full-width file-button font-upload">
        <Icon name="upload" size={15} />
        Upload a font
        <input
          type="file"
          accept=".woff2,.woff,.ttf,.otf"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void install(file);
          }}
        />
      </label>
      <p className="fine-print">
        Downloads happen only when you ask. Font files are kept on this device; use fonts you have
        permission to use.
      </p>
      <label className="range-control">
        <span>
          Text size<output>{preferences.fontSize}px</output>
        </span>
        <input
          type="range"
          min={18}
          max={36}
          value={preferences.fontSize}
          onChange={(event) => setPreferences({ fontSize: Number(event.target.value) })}
        />
      </label>
      <label className="field-label">
        Copy-mode caret
        <select
          value={preferences.caretStyle}
          onChange={(event) =>
            setPreferences({ caretStyle: event.target.value as Preferences['caretStyle'] })
          }
        >
          <option value="line">Line</option>
          <option value="block">Block</option>
          <option value="underline">Underline</option>
        </select>
      </label>
    </div>
  );
}

import { useState } from 'react';
import { useApp } from '../appContext';
import {
  applyLook,
  exportLook,
  inspectLook,
  type LookKind,
  type LookPreview,
} from '../core/portableLook';
import { Modal } from '../components/Modal';
import { Icon } from '../components/Icon';

export function DesignTransfer({ kind }: { kind: LookKind }) {
  const { profileId, preferences, setPreferences, notify } = useApp();
  const [preview, setPreview] = useState<LookPreview | null>(null);
  const [busy, setBusy] = useState(false);

  return (
    <div className="design-transfer">
      <h3 className="control-section-title">Take your {kind} with you</h3>
      <div className="two-control-grid">
        <button
          className="button button-secondary"
          onClick={async () => {
            try {
              await exportLook(preferences, kind, `My Clacko ${kind}`);
            } catch (error) {
              notify((error as Error).message);
            }
          }}
        >
          <Icon name="download" size={14} />
          Export {kind}
        </button>
        <label className="button button-secondary file-button">
          <Icon name="upload" size={14} />
          Import
          <input
            type="file"
            accept=".clacko-look,.zip"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              event.target.value = '';
              if (!file) return;
              try {
                setPreview(await inspectLook(file));
              } catch (error) {
                notify((error as Error).message);
              }
            }}
          />
        </label>
      </div>
      <p className="fine-print">
        A versioned .clacko-look file includes its images, font, or custom sounds. Share only assets
        you have permission to share.
      </p>
      {preview && (
        <Modal title={`A new ${preview.manifest.kind}, incoming.`} onClose={() => setPreview(null)}>
          <h3>{preview.manifest.name}</h3>
          <p>
            {preview.assets.length} local assets · {preview.manifest.packs.length} sound packs
          </p>
          <p className="muted">
            This updates your {preview.manifest.kind} settings. Other studio settings stay as they
            are.
          </p>
          <div className="modal-footer">
            <button className="button button-secondary" onClick={() => setPreview(null)}>
              Cancel
            </button>
            <button
              className="button button-primary"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  setPreferences(await applyLook(preview, profileId));
                  setPreview(null);
                  notify('A new look, right at home.');
                } catch (error) {
                  notify((error as Error).message);
                } finally {
                  setBusy(false);
                }
              }}
            >
              {busy ? 'Applying…' : 'Use this design'}
              <Icon name="check" size={15} />
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

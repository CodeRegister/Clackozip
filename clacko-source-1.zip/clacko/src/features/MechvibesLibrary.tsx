import { useEffect, useState } from 'react';
import { useApp } from '../appContext';
import {
  installOfficialPack,
  officialMechvibesPacks,
  type OfficialPack,
} from '../core/builtinPacks';
import { Icon } from '../components/Icon';

export function MechvibesLibrary() {
  const { profileId, setPreferences, notify } = useApp();
  const [catalog, setCatalog] = useState<OfficialPack[]>([]);
  const [selected, setSelected] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    officialMechvibesPacks()
      .then((packs) => {
        setCatalog(packs);
        setSelected(packs[0]?.id ?? '');
      })
      .catch((error: Error) => notify(error.message));
  }, []);
  const pack = catalog.find((item) => item.id === selected);

  async function install() {
    if (!pack) return;
    setBusy(true);
    try {
      const id = await installOfficialPack(pack, profileId);
      setPreferences({ soundPackId: id, soundEnabled: true });
      notify('The real Mechvibes pack is installed locally.');
    } catch (error) {
      notify((error as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="official-packs">
      <h3>More from Mechvibes 3</h3>
      <p className="fine-print">
        Optional packs from Mechvibes 3.5.6’s official catalog. V2 refers to the pack format.
      </p>
      <label className="field-label">
        Official sound pack
        <select value={selected} onChange={(event) => setSelected(event.target.value)}>
          {catalog.map((item) => (
            <option key={item.id} value={item.id}>
              {item.name}
            </option>
          ))}
        </select>
      </label>
      {pack && (
        <>
          <p className="pack-license">
            By {pack.author} · {pack.keyCount} mappings · Free for personal use
          </p>
          <button
            className="button button-primary full-width"
            disabled={busy}
            onClick={() => void install()}
          >
            <Icon name="download" size={16} />
            {busy ? 'Downloading…' : 'Install in my local profile'}
          </button>
          <a
            className="button button-secondary full-width"
            href={pack.downloadUrl}
            target="_blank"
            rel="noreferrer"
          >
            Download official ZIP
            <Icon name="download" size={15} />
          </a>
          <a className="text-button" href={pack.officialUrl} target="_blank" rel="noreferrer">
            Pack details & license
            <Icon name="arrow" size={14} />
          </a>
        </>
      )}
      <p className="fine-print">
        The recordings are personal-use downloads. They install into your browser, rather than being
        redistributed in Clacko’s source. If direct installation is blocked, download the ZIP and
        use Import ZIP below.
      </p>
    </section>
  );
}

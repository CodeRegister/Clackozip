import { useEffect, useMemo, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { database } from '../core/database';
import { filterStudyCards, type CardFilters } from '../core/review';
import { downloadFile } from '../core/transfer';
import { Icon } from '../components/Icon';
import { useAssetUrl } from '../hooks/useAssetUrl';
import { SetEditor } from './SetEditor';

function Media({ hash }: { hash?: string }) {
  const url = useAssetUrl(hash);
  return url ? <img src={url} alt="Card attachment" className="glossary-image" /> : null;
}

export function CardLibrary({ onStudy }: { onStudy: (sets: string[], cards?: string[]) => void }) {
  const { profileId, notify } = useApp();
  const cards = useLiveQuery(
    () => database.cards.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const sets = useLiveQuery(
    () => database.sets.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const states = useLiveQuery(
    () => database.reviews.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const [setId, setSetId] = useState('all');
  const [filters, setFilters] = useState<CardFilters>({ query: '', tag: '', status: 'all' });
  const [includeSuspended, setIncludeSuspended] = useState(false);
  const [view, setView] = useState<'definitions' | 'flashcards'>('definitions');
  const [selected, setSelected] = useState<string[]>([]);
  const [sort, setSort] = useState('deck');
  const [index, setIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [editing, setEditing] = useState<string>();
  const tags = [...new Set(cards.flatMap((card) => card.tags).filter(Boolean))].sort();
  const visible = useMemo(() => {
    const pool = cards.filter((card) => setId === 'all' || card.setId === setId);
    return filterStudyCards(
      includeSuspended ? pool.map((card) => ({ ...card, suspended: false })) : pool,
      states,
      filters,
    )
      .map((item) => cards.find((card) => card.id === item.id)!)
      .sort((left, right) =>
        sort === 'alphabet'
          ? left.prompt.localeCompare(right.prompt)
          : left.setId.localeCompare(right.setId) || left.position - right.position,
      );
  }, [cards, setId, filters, includeSuspended, states, sort]);
  useEffect(() => {
    setIndex(0);
    setFlipped(false);
  }, [setId, filters.query, filters.tag, filters.status, sort, includeSuspended]);
  const current = visible[Math.min(index, Math.max(0, visible.length - 1))];
  const selectedCards = visible.filter((card) => selected.includes(card.id));

  function study(ids: string[]) {
    const picked = cards.filter((card) => ids.includes(card.id) && !card.suspended);
    onStudy(
      [...new Set(picked.map((card) => card.setId))],
      picked.map((card) => card.id),
    );
  }
  async function bulk(field: 'starred' | 'suspended', value: boolean) {
    await database.transaction('rw', database.cards, async () => {
      for (const card of selectedCards)
        await database.cards.update(
          card.id,
          field === 'starred' ? { starred: value } : { suspended: value },
        );
    });
    notify(`${selectedCards.length} cards updated.`);
  }
  function exportText() {
    const quote = (text: string) => `"${text.replaceAll('"', '""')}"`;
    const source = selectedCards.length ? selectedCards : visible;
    downloadFile(
      new Blob(
        [
          [
            'Prompt,Answer',
            ...source.map((card) => `${quote(card.prompt)},${quote(card.answer)}`),
          ].join('\n'),
        ],
        { type: 'text/csv;charset=utf-8' },
      ),
      'clacko-cards.csv',
    );
  }

  return (
    <div className="cards-page">
      <div className="studio-heading">
        <div>
          <div className="eyebrow muted">YOUR CARD LIBRARY</div>
          <h1>
            Every little definition<span className="heading-period">.</span>
          </h1>
          <p>Read both sides. Flip through a set. No timer, no grading, no pressure.</p>
        </div>
        <button
          className="button button-primary"
          disabled={!visible.some((card) => !card.suspended)}
          onClick={() =>
            study((selectedCards.length ? selectedCards : visible).map((card) => card.id))
          }
        >
          Study {selectedCards.length ? 'selected' : 'these cards'}
          <Icon name="arrow" size={17} />
        </button>
      </div>
      <div className="card-library-controls">
        <label className="search-field">
          <Icon name="search" size={17} />
          <input
            aria-label="Search card library"
            value={filters.query}
            onChange={(event) => {
              setFilters({ ...filters, query: event.target.value });
              setIndex(0);
            }}
            placeholder="Search questions, definitions, and tags…"
          />
        </label>
        <select
          aria-label="Library study set"
          value={setId}
          onChange={(event) => {
            setSetId(event.target.value);
            setIndex(0);
          }}
        >
          <option value="all">All sets</option>
          {sets.map((set) => (
            <option key={set.id} value={set.id}>
              {set.title}
            </option>
          ))}
        </select>
        <select
          aria-label="Library card status"
          value={filters.status}
          onChange={(event) =>
            setFilters({ ...filters, status: event.target.value as CardFilters['status'] })
          }
        >
          <option value="all">All cards</option>
          <option value="new">New</option>
          <option value="due">Due</option>
          <option value="weak">Needs practice</option>
          <option value="starred">Starred</option>
        </select>
        <select
          aria-label="Library tag"
          value={filters.tag}
          onChange={(event) => setFilters({ ...filters, tag: event.target.value })}
        >
          <option value="">All tags</option>
          {tags.map((tag) => (
            <option key={tag}>{tag}</option>
          ))}
        </select>
      </div>
      <div className="library-view-bar">
        <div className="mode-bar">
          <button
            className={`mode-button ${view === 'definitions' ? 'active' : ''}`}
            onClick={() => setView('definitions')}
          >
            All definitions
          </button>
          <button
            className={`mode-button ${view === 'flashcards' ? 'active' : ''}`}
            onClick={() => {
              setView('flashcards');
              setFlipped(false);
            }}
          >
            Flip through
          </button>
        </div>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={includeSuspended}
            onChange={(event) => setIncludeSuspended(event.target.checked)}
          />
          Include suspended
        </label>
        <select
          aria-label="Card library sort"
          value={sort}
          onChange={(event) => setSort(event.target.value)}
        >
          <option value="deck">Set order</option>
          <option value="alphabet">A–Z</option>
        </select>
        <span>{visible.length} cards</span>
      </div>
      <div className="picker-selection-bar">
        <button className="text-button" onClick={() => setSelected(visible.map((card) => card.id))}>
          Select matching
        </button>
        <button className="text-button" onClick={() => setSelected([])}>
          Clear selection
        </button>
        <span className="muted">{selectedCards.length} selected</span>
        <button className="text-button" onClick={exportText}>
          Export CSV
          <Icon name="download" size={14} />
        </button>
        {selectedCards.length > 0 && (
          <>
            <button className="text-button" onClick={() => void bulk('starred', true)}>
              Star
            </button>
            <button className="text-button" onClick={() => void bulk('starred', false)}>
              Unstar
            </button>
            <button className="text-button" onClick={() => void bulk('suspended', true)}>
              Suspend
            </button>
            <button className="text-button" onClick={() => void bulk('suspended', false)}>
              Unsuspend
            </button>
          </>
        )}
      </div>
      {view === 'definitions' ? (
        <div className="glossary-list">
          {visible.map((card) => (
            <article
              key={card.id}
              className={`glossary-card ${card.suspended ? 'card-suspended' : ''}`}
            >
              <div className="glossary-card-tools">
                <input
                  type="checkbox"
                  aria-label={`Select ${card.prompt}`}
                  checked={selected.includes(card.id)}
                  onChange={() =>
                    setSelected(
                      selected.includes(card.id)
                        ? selected.filter((id) => id !== card.id)
                        : [...selected, card.id],
                    )
                  }
                />
                <span>{sets.find((set) => set.id === card.setId)?.title}</span>
                <button
                  className="text-button"
                  aria-label={`Star ${card.prompt}`}
                  onClick={() => void database.cards.update(card.id, { starred: !card.starred })}
                >
                  {card.starred ? '★' : '☆'}
                </button>
                <button
                  className="icon-button small"
                  aria-label={`Edit ${card.prompt}`}
                  onClick={() => setEditing(card.setId)}
                >
                  <Icon name="edit" size={15} />
                </button>
              </div>
              <div className="glossary-sides">
                <div>
                  <small>PROMPT</small>
                  <h2>{card.prompt}</h2>
                  <Media hash={card.frontImage} />
                </div>
                <div>
                  <small>DEFINITION</small>
                  <p>{card.answer}</p>
                  <Media hash={card.backImage} />
                </div>
              </div>
              <div className="glossary-tags">
                {card.tags.filter(Boolean).map((tag) => (
                  <button key={tag} onClick={() => setFilters({ ...filters, tag })}>
                    #{tag}
                  </button>
                ))}
                {card.suspended && <span>Suspended from study</span>}
              </div>
            </article>
          ))}
        </div>
      ) : current ? (
        <div className="browse-flashcard">
          <span className="eyebrow muted">
            {Math.min(index + 1, visible.length)} / {visible.length} ·{' '}
            {flipped ? 'ANSWER' : 'PROMPT'}
          </span>
          <h2>{flipped ? current.answer : current.prompt}</h2>
          <Media hash={flipped ? current.backImage : current.frontImage} />
          <button className="button button-primary" onClick={() => setFlipped(!flipped)}>
            Flip card
            <Icon name="flip" size={17} />
          </button>
          <div className="flashcard-navigation">
            <button
              className="button button-secondary"
              disabled={index === 0}
              onClick={() => {
                setIndex(index - 1);
                setFlipped(false);
              }}
            >
              Previous
            </button>
            <button
              className="text-button"
              onClick={() => {
                setIndex(Math.floor(Math.random() * visible.length));
                setFlipped(false);
              }}
            >
              A random card
            </button>
            <button
              className="button button-secondary"
              disabled={index >= visible.length - 1}
              onClick={() => {
                setIndex(index + 1);
                setFlipped(false);
              }}
            >
              Next
            </button>
          </div>
        </div>
      ) : null}
      {!visible.length && (
        <p className="empty-message">
          No matching cards. Try a different filter or create a set from Home.
        </p>
      )}
      {editing && (
        <SetEditor
          studySet={sets.find((set) => set.id === editing)}
          initialCards={cards.filter((card) => card.setId === editing)}
          onClose={() => setEditing(undefined)}
        />
      )}
    </div>
  );
}

import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { database } from '../core/database';
import { filterStudyCards, type CardFilters } from '../core/review';
import { Icon } from '../components/Icon';

export function CardPicker({
  initialSetIds = [],
  initialCardIds = [],
  onSelect,
}: {
  initialSetIds?: string[];
  initialCardIds?: string[];
  onSelect: (ids: string[]) => void;
}) {
  const { profileId } = useApp();
  const sets = useLiveQuery(
    () => database.sets.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const cards = useLiveQuery(
    () => database.cards.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const states = useLiveQuery(
    () => database.reviews.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const [setIds, setSetIds] = useState(initialSetIds);
  const [filters, setFilters] = useState<CardFilters>({ query: '', tag: '', status: 'all' });
  const [picked, setPicked] = useState<string[]>(initialCardIds);
  const initialized = useRef(false);
  const [expanded, setExpanded] = useState(false);
  const deckCards = useMemo(
    () => cards.filter((card) => !setIds.length || setIds.includes(card.setId)),
    [cards, setIds],
  );
  const matching = useMemo(
    () => filterStudyCards(deckCards, states, filters),
    [deckCards, states, filters],
  );
  const chosen = matching.filter((card) => picked.includes(card.id)).map((card) => card.id);
  const signature = chosen.join('|');
  const tags = [...new Set(cards.flatMap((card) => card.tags).filter(Boolean))].sort();
  useEffect(() => {
    if (!initialized.current && cards.length) {
      if (!initialCardIds.length)
        setPicked(deckCards.filter((card) => !card.suspended).map((card) => card.id));
      initialized.current = true;
    }
  }, [cards, deckCards]);
  useEffect(() => {
    onSelect(chosen);
  }, [signature]);

  return (
    <section className="card-picker">
      <div className="picker-decks">
        <label className="field-label">
          Choose study sets
          <select
            aria-label="Study set filter"
            value={setIds.length === 1 ? setIds[0] : 'all'}
            onChange={(event) => {
              const next = event.target.value === 'all' ? [] : [event.target.value];
              setSetIds(next);
              setPicked(
                cards
                  .filter((card) => !card.suspended && (!next.length || next.includes(card.setId)))
                  .map((card) => card.id),
              );
            }}
          >
            <option value="all">All my study sets</option>
            {sets.map((set) => (
              <option key={set.id} value={set.id}>
                {set.title}
              </option>
            ))}
          </select>
        </label>
        <details>
          <summary>Select several sets</summary>
          <div className="set-checks">
            {sets.map((set) => (
              <label className="checkbox-label" key={set.id}>
                <input
                  type="checkbox"
                  checked={!setIds.length || setIds.includes(set.id)}
                  onChange={() => {
                    const current = setIds.length ? setIds : sets.map((item) => item.id);
                    const next = current.includes(set.id)
                      ? current.filter((id) => id !== set.id)
                      : [...current, set.id];
                    setSetIds(next.length ? next : ['none']);
                  }}
                />
                {set.title}
              </label>
            ))}
          </div>
        </details>
      </div>
      <div className="picker-filters">
        <label className="search-field">
          <Icon name="search" size={16} />
          <input
            value={filters.query}
            onChange={(event) => setFilters({ ...filters, query: event.target.value })}
            placeholder="Find a question, definition, or tag"
            aria-label="Find study cards"
          />
        </label>
        <select
          aria-label="Card status filter"
          value={filters.status}
          onChange={(event) =>
            setFilters({ ...filters, status: event.target.value as CardFilters['status'] })
          }
        >
          <option value="all">All active cards</option>
          <option value="new">New</option>
          <option value="due">Due</option>
          <option value="weak">Needs practice</option>
          <option value="starred">Starred</option>
        </select>
        <select
          aria-label="Card tag filter"
          value={filters.tag}
          onChange={(event) => setFilters({ ...filters, tag: event.target.value })}
        >
          <option value="">All tags</option>
          {tags.map((tag) => (
            <option key={tag}>{tag}</option>
          ))}
        </select>
      </div>
      <div className="picker-selection-bar">
        <strong>
          {chosen.length} selected{' '}
          <span className="muted">of {matching.length} matching cards</span>
        </strong>
        <button
          className="text-button"
          onClick={() => setPicked([...new Set([...picked, ...matching.map((card) => card.id)])])}
        >
          Select matching
        </button>
        <button className="text-button" onClick={() => setPicked([])}>
          Clear
        </button>
        <button className="text-button" onClick={() => setExpanded(!expanded)}>
          {expanded ? 'Hide cards' : 'Choose individual cards'}
          <Icon name="chevron" size={14} />
        </button>
      </div>
      {expanded && (
        <div className="picker-card-list">
          {matching.map((card) => (
            <label key={card.id}>
              <input
                type="checkbox"
                checked={picked.includes(card.id)}
                onChange={() =>
                  setPicked(
                    picked.includes(card.id)
                      ? picked.filter((id) => id !== card.id)
                      : [...picked, card.id],
                  )
                }
              />
              <span>
                <strong>{card.prompt}</strong>
                <small>{card.answer}</small>
              </span>
            </label>
          ))}
        </div>
      )}
    </section>
  );
}

import { useState } from 'react';
import { useApp } from '../appContext';
import { createId, database, removeUnusedAssets, saveAsset } from '../core/database';
import type { Flashcard, StudySet } from '../core/types';
import { useAssetUrl } from '../hooks/useAssetUrl';
import { Icon } from '../components/Icon';
import { Modal } from '../components/Modal';

function blankCard(profileId: string, setId: string, position: number): Flashcard {
  return { id: createId(), profileId, setId, prompt: '', answer: '', tags: [], position };
}

function ImageAttachment({
  hash,
  onChange,
  label,
}: {
  hash?: string;
  onChange: (hash?: string) => void;
  label: string;
}) {
  const url = useAssetUrl(hash);
  const { notify } = useApp();
  async function attach(file?: File) {
    if (!file) return;
    if (!file.type.startsWith('image/') || file.type === 'image/svg+xml') {
      notify('Choose a PNG, JPEG, WebP, or GIF image.');
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      notify('Choose an image smaller than 8 MB.');
      return;
    }
    try {
      onChange(await saveAsset(file));
    } catch {
      notify('This image could not be saved. Check your storage.');
    }
  }
  return (
    <div
      className="image-attachment"
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        event.preventDefault();
        void attach(event.dataTransfer.files[0]);
      }}
      onPaste={(event) => {
        const file = Array.from(event.clipboardData.files)[0];
        if (file) {
          event.preventDefault();
          void attach(file);
        }
      }}
    >
      {url ? (
        <div className="attached-image">
          <img src={url} alt={label} />
          <button
            className="icon-button"
            onClick={() => onChange(undefined)}
            aria-label={`Remove ${label}`}
          >
            <Icon name="close" size={16} />
          </button>
        </div>
      ) : (
        <label className="text-button image-picker">
          <Icon name="image" size={15} /> Add image
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            onChange={(event) => void attach(event.target.files?.[0])}
          />
        </label>
      )}
    </div>
  );
}

export function SetEditor({
  studySet,
  initialCards,
  onClose,
}: {
  studySet?: StudySet;
  initialCards?: Flashcard[];
  onClose: () => void;
}) {
  const { profileId, notify } = useApp();
  const [setId] = useState(studySet?.id ?? createId());
  const [title, setTitle] = useState(studySet?.title ?? '');
  const [description, setDescription] = useState(studySet?.description ?? '');
  const [color, setColor] = useState<StudySet['color']>(studySet?.color ?? 'sand');
  const [cards, setCards] = useState<Flashcard[]>(
    initialCards?.length
      ? [...initialCards].sort((left, right) => left.position - right.position)
      : [blankCard(profileId, setId, 0)],
  );
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  function updateCard(index: number, patch: Partial<Flashcard>) {
    setDirty(true);
    setCards((previous) =>
      previous.map((card, cardIndex) => (cardIndex === index ? { ...card, ...patch } : card)),
    );
  }
  function close() {
    if (!dirty || window.confirm('Discard your unsaved changes?')) onClose();
  }

  async function save() {
    if (!title.trim()) {
      notify('Give your set a name first.');
      return;
    }
    const nonempty = cards.filter((card) => card.prompt.trim() || card.answer.trim());
    if (nonempty.some((card) => !card.prompt.trim() || !card.answer.trim())) {
      notify('Each card needs both a prompt and an answer.');
      return;
    }
    setSaving(true);
    try {
      await database.transaction(
        'rw',
        database.sets,
        database.cards,
        database.reviews,
        async () => {
          const existing = await database.sets.get(setId);
          if (existing && existing.profileId !== profileId)
            throw new Error('This set belongs to a different profile.');
          await database.sets.put({
            id: setId,
            profileId,
            title: title.trim(),
            description: description.trim(),
            color,
            updatedAt: Date.now(),
          });
          const retainedIds = new Set(nonempty.map((card) => card.id));
          const removedCards = await database.cards
            .where('[profileId+setId]')
            .equals([profileId, setId])
            .filter((card) => !retainedIds.has(card.id))
            .toArray();
          const removedIds = new Set(removedCards.map((card) => card.id));
          await database.reviews
            .where('profileId')
            .equals(profileId)
            .filter((state) => removedIds.has(state.cardId))
            .delete();
          await database.cards.where('[profileId+setId]').equals([profileId, setId]).delete();
          await database.cards.bulkPut(
            nonempty.map((card, position) => ({ ...card, setId, profileId, position })),
          );
        },
      );
      notify('Set saved. A little more knowledge, tucked away.');
      onClose();
      void removeUnusedAssets();
    } catch (error) {
      notify(error instanceof Error ? error.message : 'Your set could not be saved.');
    } finally {
      setSaving(false);
    }
  }

  function moveCard(index: number, direction: number) {
    const destination = index + direction;
    if (destination < 0 || destination >= cards.length) return;
    const next = [...cards];
    [next[index], next[destination]] = [next[destination], next[index]];
    setCards(next);
    setDirty(true);
  }

  return (
    <Modal title={studySet ? 'A little editing.' : 'Make room for an idea.'} onClose={close} wide>
      <div className="editor-metadata">
        <label className="field-label">
          Set name
          <input
            autoFocus
            value={title}
            onChange={(event) => {
              setTitle(event.target.value);
              setDirty(true);
            }}
            placeholder="What are we learning?"
            maxLength={100}
          />
        </label>
        <label className="field-label">
          Description <span className="muted">(optional)</span>
          <input
            value={description}
            onChange={(event) => {
              setDescription(event.target.value);
              setDirty(true);
            }}
            placeholder="A small note about this set"
            maxLength={250}
          />
        </label>
        <div className="color-options" aria-label="Set color">
          {(['sand', 'sage', 'lavender', 'rose'] as const).map((choice) => (
            <button
              key={choice}
              className={`color-choice color-${choice} ${color === choice ? 'selected' : ''}`}
              aria-label={`${choice} set color`}
              aria-pressed={color === choice}
              onClick={() => {
                setColor(choice);
                setDirty(true);
              }}
            >
              {color === choice && <Icon name="check" size={15} />}
            </button>
          ))}
        </div>
      </div>
      <div className="card-editor-list">
        {cards.map((card, index) => (
          <div className="card-editor" key={card.id}>
            <div className="card-editor-heading">
              <span>Card {index + 1}</span>
              <div className="row-actions">
                <button
                  className="icon-button small"
                  disabled={index === 0}
                  aria-label={`Move card ${index + 1} up`}
                  onClick={() => moveCard(index, -1)}
                >
                  ↑
                </button>
                <button
                  className="icon-button small"
                  disabled={index === cards.length - 1}
                  aria-label={`Move card ${index + 1} down`}
                  onClick={() => moveCard(index, 1)}
                >
                  ↓
                </button>
                <button
                  className="icon-button small"
                  aria-label={`Duplicate card ${index + 1}`}
                  onClick={() => {
                    setCards([
                      ...cards.slice(0, index + 1),
                      { ...card, id: createId() },
                      ...cards.slice(index + 1),
                    ]);
                    setDirty(true);
                  }}
                >
                  <Icon name="copy" size={15} />
                </button>
                <button
                  className="icon-button small"
                  aria-label={`Delete card ${index + 1}`}
                  onClick={() => {
                    setCards(cards.filter((_, cardIndex) => cardIndex !== index));
                    setDirty(true);
                  }}
                >
                  <Icon name="trash" size={15} />
                </button>
              </div>
            </div>
            <div className="card-sides">
              <div>
                <label className="field-label">
                  Prompt
                  <textarea
                    value={card.prompt}
                    onChange={(event) => updateCard(index, { prompt: event.target.value })}
                    placeholder="A question, term, or idea"
                    rows={3}
                  />
                </label>
                <ImageAttachment
                  hash={card.frontImage}
                  onChange={(hash) => updateCard(index, { frontImage: hash })}
                  label={`Card ${index + 1} prompt image`}
                />
              </div>
              <div>
                <label className="field-label">
                  Answer
                  <textarea
                    value={card.answer}
                    onChange={(event) => updateCard(index, { answer: event.target.value })}
                    placeholder="The thing you want to remember"
                    rows={3}
                  />
                </label>
                <ImageAttachment
                  hash={card.backImage}
                  onChange={(hash) => updateCard(index, { backImage: hash })}
                  label={`Card ${index + 1} answer image`}
                />
              </div>
            </div>
            <input
              className="tag-input"
              aria-label={`Card ${index + 1} tags`}
              value={card.tags.join(', ')}
              onChange={(event) =>
                updateCard(index, { tags: event.target.value.split(',').map((tag) => tag.trim()) })
              }
              placeholder="Tags, separated by commas"
            />
          </div>
        ))}
      </div>
      <button
        className="button button-dashed full-width"
        onClick={() => {
          setCards([...cards, blankCard(profileId, setId, cards.length)]);
          setDirty(true);
        }}
      >
        <Icon name="plus" size={18} /> Add a card
      </button>
      <div className="modal-footer">
        <span className="muted">{cards.length} cards · saved on your device</span>
        <div className="row-actions">
          <button className="button button-secondary" onClick={close}>
            Cancel
          </button>
          <button className="button button-primary" disabled={saving} onClick={() => void save()}>
            {saving ? 'Saving…' : 'Save set'}
            <Icon name="check" size={17} />
          </button>
        </div>
      </div>
    </Modal>
  );
}

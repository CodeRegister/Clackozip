import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { CardPicker } from './CardPicker';
import { SpacedReview } from './SpacedReview';
import { ZenAtmosphere } from './ZenAtmosphere';
import { zenAudio } from '../core/zenAudio';
import { useApp } from '../appContext';
import { createId, database } from '../core/database';
import { prioritizeCards } from '../core/study';
import { calculateMetrics, extractRemixText, formatDuration, graphemes } from '../core/typing';
import type { Flashcard, SessionDraft, StudyMode, StudySession } from '../core/types';
import { Icon, type IconName } from '../components/Icon';
import { Keyboard } from '../components/Keyboard';
import { Mascot } from '../components/Mascot';
import { TypingSurface } from '../components/TypingSurface';
import { useAssetUrl } from '../hooks/useAssetUrl';
import { useSceneStyle } from '../hooks/useSceneStyle';

export const studyModes: Array<{
  id: StudyMode;
  name: string;
  icon: IconName;
  description: string;
}> = [
  {
    id: 'zen',
    name: 'Zen',
    icon: 'leaf',
    description: 'Just you and the keys. No timer, no pressure.',
  },
  {
    id: 'remix',
    name: 'Remix',
    icon: 'shuffle',
    description: 'Familiar ideas. A satisfying new rhythm.',
  },
  {
    id: 'recall',
    name: 'Recall',
    icon: 'book',
    description: 'Close the notes. See what comes back.',
  },
  {
    id: 'reverse',
    name: 'Reverse',
    icon: 'flip',
    description: 'A fresh angle on what you already know.',
  },
  {
    id: 'review',
    name: 'Spaced review',
    icon: 'book',
    description: 'Recall, reveal, and rate. Let the next review find its time.',
  },
];

function CardImage({ hash }: { hash?: string }) {
  const url = useAssetUrl(hash);
  return url ? <img src={url} alt="Study card attachment" className="study-card-image" /> : null;
}

export function StudyStudio({
  initialSetIds,
  initialCardIds,
}: {
  initialSetIds: string[];
  initialCardIds?: string[];
}) {
  const { profileId, preferences, setPreferences, notify } = useApp();
  const allCards = useLiveQuery(
    () => database.cards.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const attempts = useLiveQuery(
    () => database.attempts.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const savedDraft = useLiveQuery(() => database.drafts.get(profileId), [profileId]);
  const sceneStyle = useSceneStyle();
  const [mode, setMode] = useState<StudyMode>(initialSetIds.length ? 'review' : 'zen');
  const [setIds, setSetIds] = useState<string[]>(initialSetIds);
  const [selectedCardIds, setSelectedCardIds] = useState<string[]>(initialCardIds ?? []);
  const [source, setSource] = useState<'prompts' | 'answers' | 'both'>('answers');
  const [limit, setLimit] = useState(10);
  const [order, setOrder] = useState<'priority' | 'set' | 'shuffle'>('priority');
  const [running, setRunning] = useState(false);
  const [paused, setPaused] = useState(false);
  const [queue, setQueue] = useState<Flashcard[]>([]);
  const [cursor, setCursor] = useState(0);
  const [response, setResponse] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [sessionId, setSessionId] = useState('');
  const [result, setResult] = useState<StudySession | null>(null);
  const [showZenStats, setShowZenStats] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pasted, setPasted] = useState(false);
  const counters = useRef({ inserted: 0, correct: 0 });
  const draftSnapshot = useRef<SessionDraft | null>(null);
  const finished = useRef(false);
  const elapsedRef = useRef(0);
  const isRecall = ['recall', 'reverse'].includes(mode);
  const currentCard = queue[cursor];
  const target = mode === 'remix' ? extractRemixText(queue, source) : undefined;
  const actualAnswer =
    mode === 'reverse' ? (currentCard?.prompt ?? '') : (currentCard?.answer ?? '');
  const prompt = mode === 'reverse' ? currentCard?.answer : currentCard?.prompt;
  const metrics = calculateMetrics(
    response,
    target ?? '',
    counters.current.inserted,
    counters.current.correct,
    elapsed,
  );
  const modeDetails = studyModes.find((item) => item.id === mode)!;
  const selectedCards = useMemo(
    () => allCards.filter((card) => selectedCardIds.includes(card.id) && !card.suspended),
    [allCards, selectedCardIds],
  );

  useEffect(() => {
    if (!running || paused || (isRecall && revealed)) return;
    const started = performance.now();
    const base = elapsedRef.current;
    const timer = window.setInterval(() => {
      elapsedRef.current = base + (performance.now() - started) / 1000;
      setElapsed(elapsedRef.current);
    }, 150);
    return () => window.clearInterval(timer);
  }, [running, paused, revealed, isRecall]);

  useEffect(() => {
    if (!running) return;
    draftSnapshot.current = {
      profileId,
      mode,
      setIds,
      cardIds: queue.map((card) => card.id),
      cursor,
      response,
      elapsed,
      correct,
      score: 0,
      combo: 0,
      bestCombo: 0,
      sessionId,
      source,
      secondsPerCard: 0,
      cardStartedAt: 0,
      insertedCharacters: counters.current.inserted,
      correctInsertions: counters.current.correct,
      revealed,
      timedOut: false,
      pasted,
    };
  }, [
    running,
    mode,
    setIds,
    queue,
    cursor,
    response,
    elapsed,
    correct,
    sessionId,
    profileId,
    source,
    revealed,
    pasted,
  ]);

  useEffect(() => {
    if (!running) return;
    function saveDraft() {
      if (!finished.current && draftSnapshot.current) {
        void database.drafts.put(draftSnapshot.current).catch(() => {});
      }
    }
    const timer = window.setInterval(saveDraft, 1000);
    const saveOnLeave = () => saveDraft();
    window.addEventListener('pagehide', saveOnLeave);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('pagehide', saveOnLeave);
      saveDraft();
    };
  }, [running, profileId]);

  useEffect(() => {
    const pauseOnHidden = () => {
      if (document.hidden && running) setPaused(true);
    };
    document.addEventListener('visibilitychange', pauseOnHidden);
    return () => document.removeEventListener('visibilitychange', pauseOnHidden);
  }, [running]);

  useEffect(() => {
    if (mode === 'zen' && running && !paused && (preferences.proceduralScope ?? 'zen') === 'zen') {
      void zenAudio.start();
      return () => zenAudio.stop();
    }
  }, [mode, running, paused, profileId]);

  function buildQueue(): Flashcard[] {
    let ordered =
      order === 'priority'
        ? prioritizeCards(selectedCards, attempts, mode)
        : [...selectedCards].sort(
            (left, right) =>
              left.setId.localeCompare(right.setId) || left.position - right.position,
          );
    if (order === 'shuffle')
      for (let index = ordered.length - 1; index > 0; index--) {
        const other = Math.floor(Math.random() * (index + 1));
        [ordered[index], ordered[other]] = [ordered[other], ordered[index]];
      }
    return mode === 'remix' ? ordered : ordered.slice(0, limit);
  }

  async function start() {
    if (mode !== 'zen' && !selectedCards.length) {
      notify('Choose a set with at least one card first.');
      return;
    }
    setBusy(true);
    try {
      const id = createId();
      const chosenSetIds = [...new Set(selectedCards.map((card) => card.setId))];
      setSetIds(chosenSetIds);
      const newQueue = mode === 'zen' ? [] : buildQueue();
      await database.sessions.add({
        id,
        profileId,
        mode,
        setIds: chosenSetIds,
        startedAt: Date.now(),
        duration: 0,
        cardsStudied: 0,
        correct: 0,
        rawWpm: null,
        adjustedWpm: null,
        accuracy: null,
        insertedCharacters: 0,
        score: 0,
      });
      setQueue(newQueue);
      setCursor(0);
      setResponse('');
      setRevealed(false);
      setCorrect(0);
      setElapsed(0);
      elapsedRef.current = 0;

      setPasted(false);
      counters.current = { inserted: 0, correct: 0 };
      finished.current = false;
      setSessionId(id);
      setRunning(true);
      setPaused(false);
      setResult(null);
      if (mode === 'zen') {
        const writing = await database.writings.get(profileId);
        if (writing?.text) setResponse(writing.text);
      }
    } catch {
      notify('The session could not start. Check your browser storage.');
    } finally {
      setBusy(false);
    }
  }

  async function resume() {
    if (!savedDraft || savedDraft.mode === 'mystery') return;
    const restoredQueue = savedDraft.cardIds
      .map((id) => allCards.find((card) => card.id === id))
      .filter((card): card is Flashcard => Boolean(card));
    if (savedDraft.mode !== 'zen' && restoredQueue.length !== savedDraft.cardIds.length) {
      notify('Some cards in this session were removed. Start a fresh session.');
      return;
    }
    setMode(savedDraft.mode);
    setSetIds(savedDraft.setIds);
    setQueue(restoredQueue);
    setCursor(savedDraft.cursor);
    setResponse(savedDraft.response);
    setElapsed(savedDraft.elapsed);
    elapsedRef.current = savedDraft.elapsed;
    setSource(savedDraft.source ?? 'answers');

    setCorrect(savedDraft.correct);

    setSessionId(savedDraft.sessionId);
    setRevealed(savedDraft.revealed ?? false);

    setRunning(true);
    setPaused(true);
    counters.current = {
      inserted: savedDraft.insertedCharacters ?? 0,
      correct: savedDraft.correctInsertions ?? 0,
    };
    setPasted(savedDraft.pasted ?? false);
    finished.current = false;
    notify('Your place is saved. Resume when you’re ready.');
  }

  async function finish(finalCorrect = correct, cardsStudied = cursor) {
    if (busy) return;
    setBusy(true);
    try {
      const existing = await database.sessions.get(sessionId);
      if (!existing) throw new Error('This session could not be found.');
      const completed: StudySession = {
        ...existing,
        duration: elapsedRef.current,
        cardsStudied: isRecall ? cardsStudied : 0,
        correct: finalCorrect,
        rawWpm: !pasted && mode === 'remix' ? metrics.rawWpm : null,
        adjustedWpm: !pasted && mode === 'remix' ? metrics.adjustedWpm : null,
        accuracy: !pasted && mode === 'remix' ? metrics.accuracy : null,
        insertedCharacters: counters.current.inserted,
        score: 0,
      };
      finished.current = true;
      await database.transaction('rw', database.sessions, database.drafts, async () => {
        await database.sessions.put(completed);
        await database.drafts.delete(profileId);
      });
      setRunning(false);
      setResult(completed);
    } catch (error) {
      finished.current = false;
      notify((error as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function grade(wasCorrect: boolean) {
    if (busy || !currentCard) return;
    setBusy(true);
    const nextCorrect = correct + (wasCorrect ? 1 : 0);
    try {
      await database.transaction(
        'rw',
        database.attempts,
        database.sessions,
        database.drafts,
        async () => {
          await database.attempts.put({
            id: `${sessionId}-${cursor}`,
            profileId,
            sessionId,
            cardId: currentCard.id,
            direction: mode as 'recall' | 'reverse',
            correct: wasCorrect,
            createdAt: Date.now(),
          });
          await database.sessions.update(sessionId, {
            cardsStudied: cursor + 1,
            correct: nextCorrect,
            score: 0,
            duration: elapsedRef.current,
          });
          if (cursor + 1 >= queue.length) {
            finished.current = true;
            await database.drafts.delete(profileId);
          } else if (draftSnapshot.current) {
            draftSnapshot.current = {
              ...draftSnapshot.current,
              cursor: cursor + 1,
              response: '',
              elapsed: elapsedRef.current,
              cardStartedAt: elapsedRef.current,
              correct: nextCorrect,
              combo: 0,
              score: 0,
              bestCombo: 0,
              revealed: false,
              timedOut: false,
            };
            await database.drafts.put(draftSnapshot.current);
          }
        },
      );
      setCorrect(nextCorrect);

      if (cursor + 1 >= queue.length) {
        const completed = await database.sessions.get(sessionId);
        if (completed) setResult(completed);
        setRunning(false);
      } else {
        setCursor(cursor + 1);
        setResponse('');
        setRevealed(false);
      }
    } catch {
      finished.current = false;
      notify('Your review could not be saved. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  function type(next: string, inserted: string, offset: number, wasPasted: boolean) {
    if (paused || revealed) return;
    if (wasPasted && mode === 'remix') setPasted(true);
    if (!wasPasted) {
      const characters = graphemes(inserted);
      counters.current.inserted += characters.length;
      if (target)
        counters.current.correct += characters.filter(
          (character, index) => character === graphemes(target.slice(offset))[index],
        ).length;
    }
    setResponse(next);
  }

  async function keepWriting() {
    await database.writings.put({ profileId, text: response });
    notify('Your writing is tucked away on this device.');
  }

  return (
    <div
      className={`studio-page ${mode === 'zen' ? `zen-world-${preferences.zen?.profile ?? 'off'}` : ''}`}
    >
      <div className="studio-heading">
        <div>
          <div className="eyebrow muted">STUDY STUDIO</div>
          <h1>
            Find your flow<span className="heading-period">.</span>
          </h1>
          <p>A familiar idea. A fresh perspective. A really good click.</p>
        </div>
        <div className="small-mascot">
          <Mascot />
        </div>
      </div>
      <div className="mode-bar" role="tablist" aria-label="Study mode">
        {studyModes.map((item) => (
          <button
            role="tab"
            aria-selected={mode === item.id}
            key={item.id}
            disabled={running}
            className={`mode-button ${mode === item.id ? 'active' : ''}`}
            onClick={() => {
              setMode(item.id);
              setResult(null);
            }}
          >
            <Icon name={item.icon} size={18} />
            {item.name}
          </button>
        ))}
      </div>

      {mode !== 'review' && (
        <details className="zen-sound-controls">
          <summary>
            <Icon name="volume" size={17} /> Atmosphere & music{' '}
            <span>Pixel, festive, spooky, or your own playlist</span>
          </summary>
          <ZenAtmosphere compact />
        </details>
      )}
      {mode === 'review' ? (
        <SpacedReview initialSetIds={initialSetIds} initialCardIds={initialCardIds} />
      ) : result ? (
        <div className="session-result">
          <Mascot happy />
          <span className="eyebrow">A LITTLE MORE THAN BEFORE</span>
          <h2>{isRecall ? 'Look what came back.' : 'That felt good, didn’t it?'}</h2>
          <p>One little session. One good thing for yourself.</p>
          <div className="result-metrics">
            <div>
              <strong>{formatDuration(result.duration)}</strong>
              <span>time well spent</span>
            </div>
            {isRecall ? (
              <>
                <div>
                  <strong>
                    {result.correct}/{result.cardsStudied}
                  </strong>
                  <span>cards remembered</span>
                </div>
              </>
            ) : mode === 'remix' && !pasted ? (
              <>
                <div>
                  <strong>{result.adjustedWpm}</strong>
                  <span>adjusted WPM</span>
                </div>
                <div>
                  <strong>{result.accuracy}%</strong>
                  <span>typing accuracy</span>
                </div>
              </>
            ) : (
              <div>
                <strong>{result.insertedCharacters}</strong>
                <span>little keystrokes</span>
              </div>
            )}
          </div>
          <button className="button button-primary" onClick={() => setResult(null)}>
            A little more?
            <Icon name="refresh" size={17} />
          </button>
        </div>
      ) : !running ? (
        <div className="session-setup">
          <div className="setup-intro">
            <span className="mode-emblem">
              <Icon name={modeDetails.icon} size={30} />
            </span>
            <h2>
              {mode === 'zen'
                ? 'A blank page. A clear head.'
                : `A little ${modeDetails.name.toLowerCase()} goes a long way.`}
            </h2>
            <p>{modeDetails.description}</p>
            {isRecall && (
              <p className="fine-print">
                Free practice · your spaced review schedule stays unchanged.
              </p>
            )}
          </div>
          {mode !== 'zen' && (
            <CardPicker
              initialSetIds={initialSetIds}
              initialCardIds={initialCardIds}
              onSelect={setSelectedCardIds}
            />
          )}
          <div className="setup-controls">
            {mode !== 'zen' && (
              <label className="field-label">
                Card order
                <select
                  value={order}
                  onChange={(event) => setOrder(event.target.value as typeof order)}
                >
                  <option value="priority">Needs practice first</option>
                  <option value="set">Set order</option>
                  <option value="shuffle">Shuffle</option>
                </select>
              </label>
            )}
            {mode === 'remix' && (
              <label className="field-label">
                Copy from
                <select
                  value={source}
                  onChange={(event) => setSource(event.target.value as typeof source)}
                >
                  <option value="answers">Answers</option>
                  <option value="prompts">Prompts</option>
                  <option value="both">Both sides</option>
                </select>
              </label>
            )}
            {isRecall && (
              <label className="field-label">
                Cards per session
                <select value={limit} onChange={(event) => setLimit(Number(event.target.value))}>
                  <option value={5}>Up to 5 cards</option>
                  <option value={10}>Up to 10 cards</option>
                  <option value={20}>Up to 20 cards</option>
                  <option value={1000}>All selected cards</option>
                </select>
              </label>
            )}
          </div>
          <button
            className="button button-primary button-large"
            disabled={busy || (mode !== 'zen' && !selectedCards.length)}
            onClick={() => void start()}
          >
            {mode === 'zen' ? 'Enter your quiet corner' : 'Let’s begin'}
            <Icon name="arrow" size={18} />
          </button>
          {savedDraft && savedDraft.mode !== 'mystery' && (
            <button className="resume-session text-button" onClick={() => void resume()}>
              <Icon name="refresh" size={15} />
              Resume your unfinished {savedDraft.mode} session
            </button>
          )}
        </div>
      ) : (
        <div
          className={`active-session texture-${preferences.background} ${paused ? 'session-paused' : ''}`}
          style={sceneStyle}
        >
          <div className="session-topline">
            <span className="session-mode">
              <Icon name={modeDetails.icon} size={16} />
              {modeDetails.name} mode
              <span className="tiny-dot" />
              {mode === 'zen'
                ? 'a little peace & quiet'
                : mode === 'remix'
                  ? 'visible text · typing practice'
                  : `${cursor + 1} of ${queue.length} cards`}
            </span>
            <div className="row-actions">
              {mode === 'zen' && (
                <button
                  className="icon-button"
                  title="Toggle typing statistics"
                  aria-label="Toggle typing statistics"
                  aria-pressed={showZenStats}
                  onClick={() => setShowZenStats(!showZenStats)}
                >
                  <Icon name="chart" size={18} />
                </button>
              )}
              <button
                className="icon-button"
                aria-label={paused ? 'Resume session' : 'Pause session'}
                onClick={() => setPaused(!paused)}
              >
                <Icon name={paused ? 'play' : 'pause'} size={18} />
              </button>
              <button className="text-button" onClick={() => void finish()} disabled={busy}>
                Finish
                <Icon name="check" size={16} />
              </button>
            </div>
          </div>
          {isRecall && (
            <div className="recall-prompt">
              <span className="eyebrow muted">
                {mode === 'reverse' ? 'WHAT WAS THE QUESTION?' : 'WHAT COMES TO MIND?'}
              </span>
              <h2>{prompt}</h2>
              <CardImage
                hash={mode === 'reverse' ? currentCard?.backImage : currentCard?.frontImage}
              />
            </div>
          )}
          {paused ? (
            <div className="pause-overlay">
              <Icon name="pause" size={28} />
              <h2>Take your time.</h2>
              <p>Your place is right here.</p>
              <button className="button button-primary" onClick={() => setPaused(false)}>
                I’m ready
                <Icon name="play" size={17} />
              </button>
            </div>
          ) : (
            <TypingSurface
              key={`${sessionId}-${cursor}`}
              value={response}
              onChange={type}
              target={target}
              placeholder={
                isRecall
                  ? 'Type what you remember…'
                  : 'A thought. A list. The beginning of something.'
              }
              disabled={revealed}
              onSubmit={isRecall ? () => setRevealed(true) : undefined}
            />
          )}
          {revealed && (
            <div className="answer-reveal">
              <span className="eyebrow muted">HERE’S THE IDEA.</span>
              <p>{actualAnswer}</p>
              <CardImage
                hash={mode === 'reverse' ? currentCard?.frontImage : currentCard?.backImage}
              />
              <div className="self-grade">
                <p>How did you do? You’re the judge.</p>
                <button
                  className="button button-secondary"
                  disabled={busy}
                  onClick={() => void grade(false)}
                >
                  Still learning
                </button>
                <button
                  className="button button-primary"
                  disabled={busy}
                  onClick={() => void grade(true)}
                >
                  Got it
                  <Icon name="check" size={17} />
                </button>
              </div>
            </div>
          )}
          {isRecall && !revealed && !paused && (
            <div className="reveal-actions">
              <button className="button button-secondary" onClick={() => setRevealed(true)}>
                Reveal answer
                <kbd>↵</kbd>
              </button>
            </div>
          )}
          {!paused && (mode === 'remix' || (mode === 'zen' && showZenStats)) && (
            <div className="live-metrics">
              <span>
                {formatDuration(elapsed)} <small>active time</small>
              </span>
              {mode === 'remix' && !pasted ? (
                <>
                  <span>
                    {metrics.adjustedWpm} <small>WPM</small>
                  </span>
                  <span>
                    {metrics.accuracy}% <small>accuracy</small>
                  </span>
                </>
              ) : (
                <span>
                  {counters.current.inserted} <small>characters</small>
                </span>
              )}
              {pasted && <small>Scored metrics unavailable for pasted or recovered text.</small>}
            </div>
          )}
          {mode === 'remix' && target && response.length >= target.length && (
            <div className="reveal-actions">
              <button className="button button-primary" onClick={() => void finish()}>
                Wrap up this session
                <Icon name="check" size={17} />
              </button>
            </div>
          )}
          {mode === 'zen' && (
            <div className="zen-actions">
              <span>
                <Icon name="shield" size={13} />
                Private. Local. Entirely yours.
              </span>
              <button className="text-button" onClick={() => void keepWriting()}>
                Keep this writing
                <Icon name="download" size={14} />
              </button>
              <button
                className="text-button muted"
                onClick={async () => {
                  if (window.confirm('Discard this writing and the preserved copy?')) {
                    setResponse('');
                    await database.writings.delete(profileId);
                    notify('A fresh page.');
                  }
                }}
              >
                Discard
              </button>
            </div>
          )}
        </div>
      )}

      {preferences.showKeyboard && (
        <div className="studio-keyboard">
          <Keyboard />
        </div>
      )}
      <div className="studio-bottom">
        <span>
          <Icon name="keyboard" size={15} />
          Your keys, keeping you company.
        </span>
        <button
          className="text-button"
          onClick={() => setPreferences({ showKeyboard: !preferences.showKeyboard })}
        >
          {preferences.showKeyboard ? 'Hide keyboard' : 'Show keyboard'}
          <Icon name="chevron" size={14} />
        </button>
      </div>
    </div>
  );
}

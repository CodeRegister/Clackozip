import { useEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { sayClacko } from '../core/starterPack';
import { useApp } from '../appContext';
import { createId, database, removeUnusedAssets } from '../core/database';
import type { StudySet } from '../core/types';
import { Icon } from '../components/Icon';
import { Keyboard } from '../components/Keyboard';
import { Mascot } from '../components/Mascot';
import { TypingSurface } from '../components/TypingSurface';
import { SetEditor } from './SetEditor';
import { ImportCards } from './ImportCards';

export function Library({ onStudy }: { onStudy: (setIds?: string[]) => void }) {
  const { profileId, preferences, navigate, notify } = useApp();
  const sets = useLiveQuery(
    () => database.sets.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const cards = useLiveQuery(
    () => database.cards.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const searchInput = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState('');
  const [editor, setEditor] = useState<StudySet | 'new' | null>(null);
  const [importing, setImporting] = useState(false);
  const [playground, setPlayground] = useState('');
  const [mascotHappy, setMascotHappy] = useState(false);
  const [sort, setSort] = useState('recent');
  const [menu, setMenu] = useState('');
  const counts = useMemo(
    () =>
      cards.reduce<Record<string, number>>((result, card) => {
        result[card.setId] = (result[card.setId] ?? 0) + 1;
        return result;
      }, {}),
    [cards],
  );
  const visibleSets = sets
    .filter((set) => `${set.title} ${set.description}`.toLowerCase().includes(query.toLowerCase()))
    .sort((left, right) =>
      sort === 'name' ? left.title.localeCompare(right.title) : right.updatedAt - left.updatedAt,
    );

  useEffect(() => {
    function focusSearch(event: KeyboardEvent) {
      const target = event.target as HTMLElement;
      if (
        event.key !== '/' ||
        target.closest('input, textarea, select, dialog') ||
        target.isContentEditable
      )
        return;
      event.preventDefault();
      searchInput.current?.focus();
    }
    const typeAnywhere = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement;
      if (
        event.ctrlKey ||
        event.metaKey ||
        event.altKey ||
        target.closest('input, textarea, select, button, a, dialog') ||
        target.isContentEditable
      )
        return;
      if (event.key.length === 1 && event.key !== '/') {
        event.preventDefault();
        setPlayground((text) => text + event.key);
      } else if (event.key === 'Backspace') {
        event.preventDefault();
        setPlayground((text) => [...text].slice(0, -1).join(''));
      }
    };
    window.addEventListener('keydown', typeAnywhere);
    window.addEventListener('keydown', focusSearch);
    return () => {
      window.removeEventListener('keydown', focusSearch);
      window.removeEventListener('keydown', typeAnywhere);
    };
  }, []);

  async function duplicateSet(set: StudySet) {
    const id = createId();
    await database.transaction('rw', database.sets, database.cards, async () => {
      await database.sets.add({ ...set, id, title: `${set.title} (copy)`, updatedAt: Date.now() });
      await database.cards.bulkAdd(
        cards
          .filter((card) => card.setId === set.id)
          .map((card) => ({ ...card, id: createId(), setId: id })),
      );
    });
    setMenu('');
    notify('A fresh copy, just for you.');
  }

  async function deleteSet(set: StudySet) {
    if (!window.confirm(`Delete “${set.title}” and its cards? This cannot be undone.`)) return;
    await database.transaction('rw', database.sets, database.cards, database.reviews, async () => {
      const removedIds = new Set(
        cards.filter((card) => card.setId === set.id).map((card) => card.id),
      );
      await database.reviews
        .where('profileId')
        .equals(profileId)
        .filter((state) => removedIds.has(state.cardId))
        .delete();
      await database.cards.where('[profileId+setId]').equals([profileId, set.id]).delete();
      await database.sets.delete(set.id);
    });
    setMenu('');
    void removeUnusedAssets();
    notify('Set deleted.');
  }

  return (
    <>
      <section className="home-hero">
        <div className="hero-copy">
          <div className="eyebrow">
            <span className="tiny-dot" /> YOUR MIND. A LITTLE MORE AT HOME.
          </div>
          <h1>
            A little focus.
            <br />A lot of{' '}
            <span className="click-word">
              click
              <svg viewBox="0 0 180 18" aria-hidden="true">
                <path d="M4 12c43-11 105-10 171-7M23 17c45-7 88-7 131-5" />
              </svg>
            </span>
            .
          </h1>
          <p>
            Your ideas, your rhythm, your happy place.
            <br className="desktop-break" /> Make studying feel a little more like play.
          </p>
          <div className="hero-actions">
            <button className="button button-primary button-large" onClick={() => onStudy()}>
              Find your flow
              <Icon name="arrow" size={19} />
            </button>
            <button className="hero-secondary" onClick={() => navigate('personalize')}>
              Make it yours
              <Icon name="sliders" size={16} />
            </button>
          </div>
          <div className="hero-honesty">
            <Icon name="shield" size={14} />
            <span>No account. No pressure. Just you.</span>
          </div>
        </div>
        <div className="hero-playground">
          <svg className="hero-spark spark-one" viewBox="0 0 32 40" aria-hidden="true">
            <path d="m16 2 2 13 12 5-12 3-2 15-3-15L2 20l11-5 3-13Z" />
          </svg>
          <div className="mini-writing-pad">
            <div className="mini-pad-bar">
              <span className="window-dot" />
              <span className="window-dot" />
              <span className="window-dot" />
              <span>a tiny space for your thoughts</span>
              <Icon name="leaf" size={14} />
            </div>
            <TypingSurface
              value={playground}
              onChange={setPlayground}
              placeholder={'Clacko!\njust type. see what happens.'}
              compact
              label="Welcome typing playground"
            />
            <span className="mini-pad-footer">
              {playground ? 'Clacko! There you are.' : 'start typing anywhere'} <span>↵</span>
            </span>
          </div>
          <div className="hero-keyboard-stage">
            <Keyboard decorative />
          </div>
          <button
            className="hero-mascot-button"
            aria-label="Say hello to Clacko"
            onClick={() => {
              if (preferences.soundEnabled) sayClacko(preferences.volume);
              setMascotHappy(true);
              notify('Hey, you. One little click at a time.');
              window.setTimeout(() => setMascotHappy(false), 1500);
            }}
          >
            <Mascot happy={mascotHappy} />
          </button>
          <div className="hand-note">
            <svg viewBox="0 0 82 46" aria-hidden="true">
              <path d="M6 4c27 19 30 31 68 28m-12-9 13 9-14 9" />
            </svg>
            <span>your keys. your kind of cozy.</span>
          </div>
          <span className="hero-sticker">
            <span className="tiny-dot" /> SOUNDS LIKE A GOOD IDEA
          </span>
        </div>
      </section>

      <section className="library-section">
        <div className="section-heading">
          <div>
            <div className="eyebrow muted">A HOME FOR YOUR CURIOSITY</div>
            <h2>
              Your little library<span className="heading-period">.</span>
              <span className="count-chip">{sets.length}</span>
            </h2>
          </div>
          <div className="row-actions">
            <button className="button button-secondary" onClick={() => setImporting(true)}>
              <Icon name="upload" size={17} />
              Import
            </button>
            <button className="button button-primary" onClick={() => setEditor('new')}>
              <Icon name="plus" size={18} />
              New set
            </button>
          </div>
        </div>
        <div className="library-toolbar">
          <label className="search-field">
            <Icon name="search" size={17} />
            <input
              ref={searchInput}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Find a little something…"
              aria-label="Search study sets"
            />
            <kbd>/</kbd>
          </label>
          <label className="sort-label">
            Sort by
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value)}
              aria-label="Sort study sets"
            >
              <option value="recent">Recently updated</option>
              <option value="name">Name</option>
            </select>
          </label>
        </div>
        <div className="set-grid">
          {visibleSets.map((set, index) => (
            <article className={`set-card color-${set.color}`} key={set.id}>
              <div className="set-card-top">
                <span className="set-symbol">
                  {set.color === 'sage' ? (
                    <Icon name="book" size={25} />
                  ) : set.color === 'lavender' ? (
                    <Icon name="shield" size={25} />
                  ) : (
                    <Icon name="spark" size={25} />
                  )}
                </span>
                <span className="set-card-number">{String(index + 1).padStart(2, '0')}</span>
                <div className="set-menu-anchor">
                  <button
                    className="icon-button"
                    aria-label={`Options for ${set.title}`}
                    aria-expanded={menu === set.id}
                    onClick={() => setMenu(menu === set.id ? '' : set.id)}
                  >
                    <Icon name="more" />
                  </button>
                  {menu === set.id && (
                    <div className="dropdown set-dropdown">
                      <button
                        onClick={() => {
                          setEditor(set);
                          setMenu('');
                        }}
                      >
                        <Icon name="edit" size={15} />
                        Edit set
                      </button>
                      <button onClick={() => void duplicateSet(set)}>
                        <Icon name="copy" size={15} />
                        Duplicate
                      </button>
                      <button className="danger-text" onClick={() => void deleteSet(set)}>
                        <Icon name="trash" size={15} />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>
              <button className="set-title-button" onClick={() => setEditor(set)}>
                <h3>{set.title}</h3>
              </button>
              <p>{set.description || 'A fresh collection of things worth remembering.'}</p>
              <div className="set-card-bottom">
                <span>
                  <Icon name="copy" size={14} />
                  {counts[set.id] ?? 0} {(counts[set.id] ?? 0) === 1 ? 'card' : 'cards'}
                </span>
                <button
                  className="set-study-button"
                  disabled={!counts[set.id]}
                  onClick={() => onStudy([set.id])}
                >
                  Let’s study
                  <Icon name="arrow" size={17} />
                </button>
              </div>
            </article>
          ))}
          <button className="new-set-tile" onClick={() => setEditor('new')}>
            <span className="new-set-icon">
              <Icon name="plus" size={24} />
            </span>
            <strong>A new rabbit hole?</strong>
            <span>There’s always room for one more.</span>
          </button>
        </div>
        {query && !visibleSets.length && (
          <p className="empty-message">No sets match “{query}”. Try another little idea.</p>
        )}
      </section>

      <section className="quiet-banner">
        <div className="quiet-banner-icon">
          <Icon name="leaf" size={22} />
        </div>
        <div>
          <strong>Little sessions. Lasting ideas.</strong>
          <p>Five minutes counts. So does coming back tomorrow.</p>
        </div>
        <button className="text-button" onClick={() => onStudy()}>
          Take a breath. Start typing.
          <Icon name="arrow" size={16} />
        </button>
      </section>
      {editor && (
        <SetEditor
          studySet={editor === 'new' ? undefined : editor}
          initialCards={
            editor === 'new' ? undefined : cards.filter((card) => card.setId === editor.id)
          }
          onClose={() => setEditor(null)}
        />
      )}
      {importing && <ImportCards onClose={() => setImporting(false)} />}
    </>
  );
}

import { useState } from 'react';
import {
  allPhysicalKeys,
  keyboardModels,
  keyboardLayouts,
  type KeyboardModel,
  type KeyboardLayout,
} from '../core/keyboards';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { database, saveAsset } from '../core/database';
import { defaultKeyboardDesign, type KeyDesign } from '../core/design';
import { keyboardRows } from '../components/Keyboard';
import { Icon } from '../components/Icon';
import { useAssetUrl } from '../hooks/useAssetUrl';

export function KeyboardDesigner({
  selectedCode,
  selectKey,
}: {
  selectedCode: string;
  selectKey: (code: string) => void;
}) {
  const { profileId, preferences, setPreferences, notify } = useApp();
  const packs = useLiveQuery(
    () => database.packs.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const design = preferences.keyboard ?? defaultKeyboardDesign();
  const key = design.keys[selectedCode] ?? {};
  const decal = useAssetUrl(key.decal);
  const keys = allPhysicalKeys;
  const [customRows, setCustomRows] = useState(
    (design.customRows ?? keyboardRows.map((row) => row.map((key) => key.code)))
      .map((row) => row.join(' '))
      .join('\n'),
  );
  const update = (patch: Partial<typeof design>) =>
    setPreferences({ keyboard: { ...design, ...patch } });
  const updateKey = (patch: Partial<KeyDesign>) =>
    update({ keys: { ...design.keys, [selectedCode]: { ...key, ...patch } } });

  async function image(file: File | undefined, target: 'case' | 'key') {
    if (!file) return;
    if (
      !['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(file.type) ||
      file.size > 8 * 1024 * 1024
    ) {
      notify('Choose a PNG, JPEG, WebP, or GIF smaller than 8 MB.');
      return;
    }
    const hash = await saveAsset(file);
    if (target === 'case') update({ caseImage: hash });
    else updateKey({ decal: hash, decalOpacity: 0.7 });
  }

  async function customSound(file?: File) {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      notify('Choose a short sound clip smaller than 5 MB.');
      return;
    }
    const context = new AudioContext();
    try {
      const decoded = await context.decodeAudioData(await file.arrayBuffer());
      if (decoded.duration > 12) throw new Error('Key sounds should be 12 seconds or shorter.');
      updateKey({ sound: { assetHash: await saveAsset(file), volume: 1 } });
      notify(`Your sound is assigned to ${selectedCode}.`);
    } catch (error) {
      notify(error instanceof Error ? error.message : 'This audio file could not be decoded.');
    } finally {
      void context.close();
    }
  }

  return (
    <div className="keyboard-designer">
      <div className="panel-heading">
        <h2>A keyboard of your own.</h2>
        <p>Select a key in the preview. Make it yours.</p>
      </div>
      <label className="field-label">
        Keyboard model
        <select
          value={design.model ?? 'sixty-five'}
          onChange={(event) => update({ model: event.target.value as KeyboardModel })}
        >
          {keyboardModels.map((model) => (
            <option key={model.id} value={model.id}>
              {model.name}
            </option>
          ))}
        </select>
      </label>
      <p className="fine-print">
        {keyboardModels.find((model) => model.id === (design.model ?? 'sixty-five'))?.detail}
      </p>
      <label className="field-label">
        Keyboard layout
        <select
          value={design.layout ?? 'qwerty-us'}
          onChange={(event) => update({ layout: event.target.value as KeyboardLayout })}
        >
          {keyboardLayouts.map((layout) => (
            <option key={layout.id} value={layout.id}>
              {layout.name}
            </option>
          ))}
        </select>
      </label>
      <div className="two-control-grid">
        <label className="field-label">
          Frame material
          <select
            value={design.material ?? 'plastic'}
            onChange={(event) => update({ material: event.target.value as typeof design.material })}
          >
            <option value="plastic">Plastic</option>
            <option value="aluminum">Brushed aluminum</option>
            <option value="wood">Wood</option>
            <option value="glass">Frosted glass</option>
          </select>
        </label>
        <label className="field-label">
          Keycap finish
          <select
            value={design.keyMaterial ?? 'pbt'}
            onChange={(event) =>
              update({ keyMaterial: event.target.value as typeof design.keyMaterial })
            }
          >
            <option value="pbt">Matte PBT</option>
            <option value="abs">Glossy ABS</option>
            <option value="rubber">Soft rubber</option>
          </select>
        </label>
      </div>
      {design.model === 'custom' && (
        <div>
          <label className="field-label">
            Your rows
            <textarea
              rows={6}
              value={customRows}
              onChange={(event) => setCustomRows(event.target.value)}
            />
          </label>
          <p className="fine-print">
            One row per line. Physical key codes separated by spaces, such as KeyA KeyS KeyD Enter.
          </p>
          <button
            className="button button-secondary full-width"
            onClick={() => {
              const rows = customRows
                .split('\n')
                .map((row) => row.trim().split(/\s+/))
                .filter((row) => row[0]);
              const flattened = rows.flat();
              if (
                !rows.length ||
                rows.length > 8 ||
                rows.some((row) => row.length > 24) ||
                flattened.some((code) => !keys.some((key) => key.code === code)) ||
                new Set(flattened).size !== flattened.length
              ) {
                notify(
                  'Use 1–8 rows, up to 24 known keys per row, with no duplicate physical codes.',
                );
                return;
              }
              update({ customRows: rows });
              notify('Your custom keyboard is ready.');
            }}
          >
            Apply my rows
            <Icon name="check" size={15} />
          </button>
        </div>
      )}
      <h3 className="control-section-title">Click effects</h3>
      <label className="field-label">
        Keypress effect
        <select
          value={design.effect ?? 'press'}
          onChange={(event) => update({ effect: event.target.value as typeof design.effect })}
        >
          <option value="press">Tactile press</option>
          <option value="glow">Glow</option>
          <option value="ripple">Ripple</option>
          <option value="bounce">Bounce</option>
          <option value="none">None</option>
        </select>
      </label>
      <label className="range-control">
        <span>
          Effect intensity<output>{design.effectIntensity ?? 1}×</output>
        </span>
        <input
          type="range"
          min={0}
          max={2}
          step={0.1}
          value={design.effectIntensity ?? 1}
          onChange={(event) => update({ effectIntensity: Number(event.target.value) })}
        />
      </label>
      <label className="range-control">
        <span>
          Effect duration<output>{design.effectDuration ?? 220}ms</output>
        </span>
        <input
          type="range"
          min={80}
          max={800}
          step={20}
          value={design.effectDuration ?? 220}
          onChange={(event) => update({ effectDuration: Number(event.target.value) })}
        />
      </label>
      <h3 className="control-section-title">The whole keyboard</h3>
      <label className="field-label color-setting">
        Keycap color
        <input
          type="color"
          aria-label="All keycap color"
          value={preferences.keyColor}
          onChange={(event) => setPreferences({ keyColor: event.target.value })}
        />
      </label>
      <label className="field-label color-setting">
        Frame color
        <input
          type="color"
          aria-label="Keyboard frame color"
          value={design.caseColor}
          onChange={(event) => update({ caseColor: event.target.value })}
        />
      </label>
      <label className="field-label color-setting">
        Pressed key color
        <input
          type="color"
          aria-label="Pressed key color"
          value={design.pressedColor}
          onChange={(event) => update({ pressedColor: event.target.value })}
        />
      </label>
      <label className="button button-secondary full-width file-button">
        <Icon name="image" size={15} />
        Keyboard background
        <input
          type="file"
          accept="image/png,image/jpeg,image/webp,image/gif"
          onChange={(event) => void image(event.target.files?.[0], 'case')}
        />
      </label>
      {design.caseImage && (
        <>
          <label className="range-control">
            <span>
              Background visibility<output>{Math.round(design.imageOpacity * 100)}%</output>
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={design.imageOpacity * 100}
              onChange={(event) => update({ imageOpacity: Number(event.target.value) / 100 })}
            />
          </label>
          <button className="text-button" onClick={() => update({ caseImage: undefined })}>
            Remove frame image
          </button>
        </>
      )}
      <div className="two-control-grid">
        <label className="field-label">
          Roundness
          <input
            type="range"
            min={2}
            max={18}
            value={preferences.keyRadius}
            onChange={(event) => setPreferences({ keyRadius: Number(event.target.value) })}
          />
        </label>
        <label className="field-label">
          Size
          <input
            type="range"
            min={65}
            max={100}
            value={preferences.keyboardSize}
            onChange={(event) => setPreferences({ keyboardSize: Number(event.target.value) })}
          />
        </label>
      </div>
      <div className="key-inspector">
        <h3 className="control-section-title">One little key</h3>
        <label className="field-label">
          Selected physical key
          <select
            aria-label="Selected physical key"
            value={selectedCode}
            onChange={(event) => selectKey(event.target.value)}
          >
            {keys.map((item) => (
              <option key={item.code} value={item.code}>
                {item.code}
              </option>
            ))}
          </select>
        </label>
        <label className="field-label">
          Key label
          <input
            maxLength={12}
            value={key.label ?? ''}
            placeholder={keys.find((item) => item.code === selectedCode)?.label}
            onChange={(event) => updateKey({ label: event.target.value || undefined })}
          />
        </label>
        <div className="two-control-grid">
          <label className="field-label color-setting">
            Color
            <input
              aria-label="Selected key color"
              type="color"
              value={key.color ?? preferences.keyColor}
              onChange={(event) => updateKey({ color: event.target.value })}
            />
          </label>
          <label className="field-label color-setting">
            Legend
            <input
              type="color"
              aria-label="Selected key legend color"
              value={key.legendColor ?? design.legendColor}
              onChange={(event) => updateKey({ legendColor: event.target.value })}
            />
          </label>
        </div>
        <label className="button button-secondary full-width file-button">
          <Icon name="image" size={15} />
          {decal ? 'Replace decal' : 'Add a decal'}
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif"
            onChange={(event) => void image(event.target.files?.[0], 'key')}
          />
        </label>
        {decal && (
          <div className="decal-preview">
            <img src={decal} alt="Selected key decal" />
            <button className="text-button" onClick={() => updateKey({ decal: undefined })}>
              Remove decal
            </button>
          </div>
        )}
        <label className="field-label">
          This key’s effect
          <select
            value={key.effect ?? 'inherit'}
            onChange={(event) =>
              updateKey({
                effect:
                  event.target.value === 'inherit'
                    ? undefined
                    : (event.target.value as KeyDesign['effect']),
              })
            }
          >
            <option value="inherit">Use the keyboard’s effect</option>
            <option value="press">Tactile press</option>
            <option value="glow">Glow</option>
            <option value="ripple">Ripple</option>
            <option value="bounce">Bounce</option>
            <option value="none">None</option>
          </select>
        </label>
        {design.model === 'custom' && (
          <label className="range-control">
            <span>
              This key’s width
              <output>
                {design.customWidths?.[selectedCode] ??
                  keys.find((item) => item.code === selectedCode)?.width ??
                  1}
                u
              </output>
            </span>
            <input
              type="range"
              min={0.5}
              max={6}
              step={0.25}
              value={
                design.customWidths?.[selectedCode] ??
                keys.find((item) => item.code === selectedCode)?.width ??
                1
              }
              onChange={(event) =>
                update({
                  customWidths: {
                    ...design.customWidths,
                    [selectedCode]: Number(event.target.value),
                  },
                })
              }
            />
          </label>
        )}
        <label className="field-label">
          This key’s sound
          <select
            aria-label="Selected key sound pack"
            value={
              key.sound?.procedural
                ? `procedural:${key.sound.procedural}`
                : (key.sound?.packId ?? (key.sound?.assetHash ? 'custom' : 'default'))
            }
            onChange={(event) =>
              updateKey({
                sound:
                  event.target.value === 'default'
                    ? undefined
                    : event.target.value.startsWith('procedural:')
                      ? {
                          procedural: event.target.value.split(':')[1] as 'pixel' | 'bell' | 'wood',
                          volume: 1,
                        }
                      : { packId: event.target.value, volume: 1, sampleCode: selectedCode },
              })
            }
          >
            <option value="default">Use the keyboard’s sound</option>
            <option value="bundled-cherry-brown">Cherry MX Brown · included</option>
            <option value="procedural:pixel">Procedural · pixel</option>
            <option value="procedural:bell">Procedural · bell</option>
            <option value="procedural:wood">Procedural · wood</option>
            {key.sound?.assetHash && <option value="custom">My uploaded clip</option>}
            {packs.map((pack) => (
              <option key={pack.id} value={pack.id}>
                {pack.name}
              </option>
            ))}
          </select>
        </label>
        {key.sound?.packId && (
          <label className="field-label">
            Borrow a sound from
            <select
              value={key.sound.sampleCode ?? selectedCode}
              onChange={(event) =>
                updateKey({ sound: { ...key.sound!, sampleCode: event.target.value } })
              }
            >
              {keys.map((item) => (
                <option key={item.code} value={item.code}>
                  {item.code}
                </option>
              ))}
            </select>
          </label>
        )}
        <label className="button button-secondary full-width file-button">
          <Icon name="volume" size={15} />
          Upload this key’s sound
          <input
            type="file"
            accept="audio/*,.wav,.ogg,.mp3,.flac"
            onChange={(event) => void customSound(event.target.files?.[0])}
          />
        </label>
        {key.sound && (
          <label className="range-control">
            <span>
              This key’s volume<output>{Math.round(key.sound.volume * 100)}%</output>
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={key.sound.volume * 100}
              onChange={(event) =>
                updateKey({ sound: { ...key.sound!, volume: Number(event.target.value) / 100 } })
              }
            />
          </label>
        )}
        <button
          className="text-button reset-button"
          onClick={() => {
            const remaining = { ...design.keys };
            delete remaining[selectedCode];
            update({ keys: remaining });
          }}
        >
          Reset this key
          <Icon name="refresh" size={14} />
        </button>
      </div>
      <p className="fine-print">
        Per-key edits travel with exported keyboard designs, including their original images and
        audio.
      </p>
    </div>
  );
}

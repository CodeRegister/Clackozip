import { useEffect, useRef, useState, type ChangeEvent } from 'react';
import { useApp } from '../appContext';
import { createId, database, saveAsset } from '../core/database';
import { defaultZenSettings, type ZenProfile } from '../core/design';
import { zenAudio } from '../core/zenAudio';
import { Icon } from '../components/Icon';

export const zenProfiles: Array<{ id: ZenProfile; title: string; detail: string }> = [
  { id: 'off', title: 'Just the keys', detail: 'A quiet space, with your keyboard sound.' },
  { id: 'pixel', title: 'Pixel daydream', detail: '8-bit notes that dance with your typing.' },
  {
    id: 'christmas',
    title: 'December glow',
    detail: 'Gentle, generative bells. A little festive.',
  },
  { id: 'spooky', title: 'Midnight whispers', detail: 'Low drones and curious minor notes.' },
  { id: 'rain', title: 'Window weather', detail: 'A soft, procedurally generated rain bed.' },
];

export function ZenAtmosphere({ compact = false }: { compact?: boolean }) {
  const { preferences, setPreferences, notify } = useApp();
  const settings = { ...defaultZenSettings(), ...preferences.zen };
  const [previewing, setPreviewing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [trackIndex, setTrackIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const audio = useRef<HTMLAudioElement>(null);
  const autoplay = useRef(false);
  const update = (patch: Partial<typeof settings>) =>
    setPreferences({ zen: { ...settings, ...patch } });
  const track = settings.playlist[trackIndex];

  useEffect(() => {
    let active = true;
    let url: string | undefined;
    const player = audio.current;
    if (!track || !player) {
      if (player) player.removeAttribute('src');
      return;
    }
    database.assets.get(track.hash).then((asset) => {
      if (!active || !asset) return;
      url = URL.createObjectURL(asset.blob);
      player.src = url;
      if (autoplay.current) player.play().catch(() => setPlaying(false));
    });
    return () => {
      active = false;
      player.pause();
      if (url) URL.revokeObjectURL(url);
    };
  }, [track?.hash]);

  useEffect(() => {
    if (audio.current) audio.current.volume = settings.musicVolume;
  }, [settings.musicVolume]);
  useEffect(
    () => () => {
      if (previewing) zenAudio.stop();
    },
    [previewing],
  );

  async function importMusic(event: ChangeEvent<HTMLInputElement>) {
    const selected = Array.from(event.target.files ?? []).filter(
      (file) => file.type.startsWith('audio/') || /\.(mp3|wav|ogg|flac|m4a|aac)$/i.test(file.name),
    );
    event.target.value = '';
    if (!selected.length) {
      notify('Choose audio files or a folder containing music.');
      return;
    }
    if (
      selected.length > 100 ||
      selected.some((file) => file.size > 12 * 1024 * 1024) ||
      selected.reduce((total, file) => total + file.size, 0) > 50 * 1024 * 1024
    ) {
      notify('Import up to 100 tracks, 12 MB per file and 50 MB per batch.');
      return;
    }
    setBusy(true);
    try {
      const imported = [];
      for (const file of selected)
        imported.push({
          id: createId(),
          name: file.name.replace(/\.[^.]+$/, ''),
          hash: await saveAsset(file),
        });
      const existing = new Set(settings.playlist.map((item) => item.hash));
      update({
        playlist: [...settings.playlist, ...imported.filter((item) => !existing.has(item.hash))],
      });
      notify('Your playlist is copied locally. The original folder can stay where it is.');
    } catch {
      notify('These tracks could not be saved. Check your browser storage.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className={`zen-atmosphere ${compact ? 'zen-atmosphere-compact' : ''}`}>
      {!compact && (
        <div className="panel-heading">
          <h2>A whole little world.</h2>
          <p>Procedural sound, your music, or both.</p>
        </div>
      )}
      <label className="field-label">
        Procedural sound profile
        <select
          value={settings.profile}
          onChange={(event) => update({ profile: event.target.value as ZenProfile })}
        >
          {zenProfiles.map((profile) => (
            <option key={profile.id} value={profile.id}>
              {profile.title}
            </option>
          ))}
        </select>
      </label>
      <p className="fine-print">
        {zenProfiles.find((profile) => profile.id === settings.profile)?.detail}
      </p>
      <label className="field-label">
        Play procedural sound in
        <select
          value={preferences.proceduralScope ?? 'zen'}
          onChange={(event) =>
            setPreferences({
              proceduralScope: event.target.value as 'zen' | 'study' | 'everywhere',
            })
          }
        >
          <option value="zen">Zen sessions</option>
          <option value="study">Study Studio & Clacko Gym</option>
          <option value="everywhere">Everywhere, including Home</option>
        </select>
      </label>
      <div className="zen-mixer">
        <label className="range-control">
          <span>
            Soundscape volume<output>{Math.round(settings.volume * 100)}%</output>
          </span>
          <input
            type="range"
            min={0}
            max={100}
            value={settings.volume * 100}
            onChange={(event) => update({ volume: Number(event.target.value) / 100 })}
          />
        </label>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={settings.reactive}
            onChange={(event) => update({ reactive: event.target.checked })}
          />
          React to my typing
        </label>
        {!compact && (
          <button
            className="button button-secondary full-width"
            onClick={() => {
              if (previewing) zenAudio.stop();
              else void zenAudio.start();
              setPreviewing(!previewing);
            }}
          >
            <Icon name={previewing ? 'pause' : 'play'} size={16} />
            {previewing ? 'Stop sound preview' : 'Preview this atmosphere'}
          </button>
        )}
      </div>
      <h3 className="control-section-title">Your own little soundtrack</h3>
      <div className="music-import-actions">
        <label className="button button-secondary file-button">
          <Icon name="plus" size={15} />
          {busy ? 'Importing…' : 'Add audio'}
          <input
            disabled={busy}
            type="file"
            accept="audio/*,.mp3,.wav,.ogg,.flac,.m4a"
            multiple
            onChange={(event) => void importMusic(event)}
          />
        </label>
        <label className="button button-secondary file-button">
          <Icon name="book" size={15} />
          Choose folder
          <input
            disabled={busy}
            type="file"
            multiple
            {...({ webkitdirectory: '' } as Record<string, string>)}
            onChange={(event) => void importMusic(event)}
          />
        </label>
      </div>
      {settings.playlist.length > 0 ? (
        <>
          <select
            aria-label="Playlist track"
            value={trackIndex}
            onChange={(event) => {
              autoplay.current = playing;
              setTrackIndex(Number(event.target.value));
            }}
          >
            {settings.playlist.map((item, index) => (
              <option key={item.id} value={index}>
                {index + 1}. {item.name}
              </option>
            ))}
          </select>
          <audio
            ref={audio}
            controls
            preload="metadata"
            loop={settings.loopTrack}
            onPlay={() => {
              setPlaying(true);
              autoplay.current = true;
            }}
            onPause={() => setPlaying(false)}
            onEnded={() => {
              autoplay.current = true;
              setTrackIndex((trackIndex + 1) % settings.playlist.length);
            }}
            onError={() =>
              notify('This track could not be played by your browser. Try an MP3 or WAV version.')
            }
          />
          <div className="music-extra-controls">
            <button
              className="text-button"
              onClick={() => {
                autoplay.current = playing;
                setTrackIndex((trackIndex + 1) % settings.playlist.length);
              }}
            >
              Next track
              <Icon name="arrow" size={14} />
            </button>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={settings.loopTrack}
                onChange={(event) => update({ loopTrack: event.target.checked })}
              />
              Loop one
            </label>
            <button
              className="text-button"
              onClick={() => {
                update({ playlist: settings.playlist.filter((_, index) => index !== trackIndex) });
                setTrackIndex(0);
              }}
            >
              Remove track
            </button>
          </div>
          <label className="range-control">
            <span>
              Music volume<output>{Math.round(settings.musicVolume * 100)}%</output>
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.musicVolume * 100}
              onChange={(event) => update({ musicVolume: Number(event.target.value) / 100 })}
            />
          </label>
        </>
      ) : (
        <p className="fine-print">
          Choose a sound to loop, or import a music folder for a playlist. Files stay local.
        </p>
      )}
    </section>
  );
}

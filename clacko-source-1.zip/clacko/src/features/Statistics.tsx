import { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { database } from '../core/database';
import { formatDuration } from '../core/typing';
import { Icon } from '../components/Icon';
import { Mascot } from '../components/Mascot';

export function Statistics({ onStudy }: { onStudy: (setIds?: string[]) => void }) {
  const { profileId } = useApp();
  const sessions = useLiveQuery(
    () => database.sessions.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const attempts = useLiveQuery(
    () => database.attempts.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const cards = useLiveQuery(
    () => database.cards.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const [tab, setTab] = useState<'learning' | 'typing'>('learning');
  const completed = sessions
    .filter((session) => session.duration > 0 || session.cardsStudied > 0)
    .sort((left, right) => right.startedAt - left.startedAt);
  const totalSeconds = completed.reduce((sum, session) => sum + session.duration, 0);
  const correct = attempts.filter((attempt) => attempt.correct).length;
  const typingSessions = completed.filter(
    (session) => session.mode === 'remix' && session.adjustedWpm !== null,
  );
  const averageWpm = typingSessions.length
    ? Math.round(
        typingSessions.reduce((sum, session) => sum + (session.adjustedWpm ?? 0), 0) /
          typingSessions.length,
      )
    : null;
  const days = Array.from({ length: 84 }, (_, index) => {
    const date = new Date();
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() - 83 + index);
    return date;
  });
  const dayCounts = new Map<string, number>();
  completed.forEach((session) => {
    const day = new Date(session.startedAt).toLocaleDateString('en-CA');
    dayCounts.set(day, (dayCounts.get(day) ?? 0) + 1);
  });
  let streak = 0;
  const streakDate = new Date();
  if (!dayCounts.has(streakDate.toLocaleDateString('en-CA')))
    streakDate.setDate(streakDate.getDate() - 1);
  while (dayCounts.has(streakDate.toLocaleDateString('en-CA'))) {
    streak++;
    streakDate.setDate(streakDate.getDate() - 1);
  }
  const weakCards = cards
    .map((card) => {
      const history = attempts.filter(
        (attempt) =>
          attempt.cardId === card.id && ['recall', 'reverse'].includes(attempt.direction),
      );
      return {
        card,
        reviews: history.length,
        success: history.length
          ? history.filter((attempt) => attempt.correct).length / history.length
          : 1,
      };
    })
    .filter((item) => item.reviews && item.success < 1)
    .sort((left, right) => left.success - right.success)
    .slice(0, 5);

  return (
    <div className="statistics-page">
      <div className="studio-heading">
        <div>
          <div className="eyebrow muted">YOUR LITTLE WINS</div>
          <h1>
            Look at you, growing<span className="heading-period">.</span>
          </h1>
          <p>Progress doesn’t have to be loud to mean something.</p>
        </div>
        <Mascot happy />
      </div>
      <div className="stats-cards">
        <div className="stat-card">
          <span>
            <Icon name="clock" size={17} />
            Time for yourself
          </span>
          <strong>
            {Math.round(totalSeconds / 60)}
            <small>min</small>
          </strong>
          <p>Every minute counts.</p>
        </div>
        <div className="stat-card">
          <span>
            <Icon name="book" size={17} />
            Study moments
          </span>
          <strong>{completed.length}</strong>
          <p>Little sessions, adding up.</p>
        </div>
        <div className="stat-card">
          <span>
            <Icon name="spark" size={17} />
            Current streak
          </span>
          <strong>
            {streak}
            <small>{streak === 1 ? 'day' : 'days'}</small>
          </strong>
          <p>{streak ? 'A lovely little rhythm.' : 'Today is a nice place to start.'}</p>
        </div>
        <div className="stat-card">
          <span>
            <Icon name="check" size={17} />
            Cards remembered
          </span>
          <strong>
            {correct}
            <small>/ {attempts.length}</small>
          </strong>
          <p>Recall, reverse & spaced reviews.</p>
        </div>
      </div>
      <section className="activity-panel">
        <div className="panel-section-heading">
          <div>
            <h2>A little, often.</h2>
            <p>Your last 12 weeks, one small square at a time.</p>
          </div>
          <span className="quiet-chip">{dayCounts.size} active days</span>
        </div>
        <div className="activity-heatmap">
          {days.map((day) => {
            const count = dayCounts.get(day.toLocaleDateString('en-CA')) ?? 0;
            return (
              <div
                key={day.toISOString()}
                className={`activity-cell activity-${Math.min(count, 3)}`}
                title={`${day.toLocaleDateString()}: ${count} sessions`}
                aria-label={`${day.toLocaleDateString()}: ${count} sessions`}
              />
            );
          })}
        </div>
        <div className="heatmap-legend">
          <span>Just showing up is something.</span>
          <div>
            Less
            <span className="activity-cell" />
            <span className="activity-cell activity-1" />
            <span className="activity-cell activity-2" />
            <span className="activity-cell activity-3" />
            More
          </div>
        </div>
      </section>
      <div className="stats-tab-row">
        <button className={tab === 'learning' ? 'active' : ''} onClick={() => setTab('learning')}>
          <Icon name="book" size={17} />
          Learning
        </button>
        <button className={tab === 'typing' ? 'active' : ''} onClick={() => setTab('typing')}>
          <Icon name="keyboard" size={17} />
          Typing
        </button>
        <span>Different skills. Their own little wins.</span>
      </div>
      {tab === 'learning' ? (
        <section className="weak-cards-panel">
          <div className="panel-section-heading">
            <div>
              <h2>A second little look.</h2>
              <p>The ideas that could use some extra love.</p>
            </div>
            <Icon name="refresh" size={21} />
          </div>
          {weakCards.length ? (
            <div className="weak-card-list">
              {weakCards.map(({ card, reviews, success }) => (
                <div key={card.id}>
                  <span>
                    <strong>{card.prompt}</strong>
                    <small>
                      {Math.round(success * 100)}% remembered · {reviews} reviews
                    </small>
                  </span>
                  <button className="button button-secondary" onClick={() => onStudy([card.setId])}>
                    Review set
                    <Icon name="arrow" size={16} />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="stats-empty">
              <Icon name="leaf" size={30} />
              <h3>{attempts.length ? 'Looking good in here.' : 'A fresh page in your story.'}</h3>
              <p>
                {attempts.length
                  ? 'Nothing needs an extra review right now.'
                  : 'Try Recall or Reverse. Your learning progress will find a home here.'}
              </p>
              <button className="text-button" onClick={() => onStudy()}>
                Find your flow
                <Icon name="arrow" size={16} />
              </button>
            </div>
          )}
        </section>
      ) : (
        <section className="typing-stats-panel">
          <div className="panel-section-heading">
            <div>
              <h2>Finding your rhythm.</h2>
              <p>Remix typing performance, separate from what you remember.</p>
            </div>
            <strong className="average-wpm">
              {averageWpm ?? '—'}
              <small>avg. WPM</small>
            </strong>
          </div>
          {typingSessions.length ? (
            <div className="wpm-chart" aria-label="Recent adjusted words per minute">
              {typingSessions
                .slice(0, 12)
                .reverse()
                .map((session) => (
                  <div key={session.id}>
                    <span>{session.adjustedWpm}</span>
                    <div
                      style={{
                        height: `${Math.max(6, ((session.adjustedWpm ?? 0) / Math.max(...typingSessions.map((item) => item.adjustedWpm ?? 0), 1)) * 120)}px`,
                      }}
                    />
                    <small>
                      {new Date(session.startedAt).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                      })}
                    </small>
                  </div>
                ))}
            </div>
          ) : (
            <div className="stats-empty">
              <Icon name="keyboard" size={30} />
              <h3>Your rhythm starts here.</h3>
              <p>Complete a Remix session to see your speed and accuracy.</p>
            </div>
          )}
        </section>
      )}
      <section className="history-panel">
        <div className="panel-section-heading">
          <h2>Recently, in your corner.</h2>
          <span className="muted">Your last 10 sessions</span>
        </div>
        {completed.length ? (
          <div className="history-table-wrap">
            <table className="history-table">
              <thead>
                <tr>
                  <th>Mode</th>
                  <th>When</th>
                  <th>Time</th>
                  <th>Little wins</th>
                </tr>
              </thead>
              <tbody>
                {completed.slice(0, 10).map((session) => (
                  <tr key={session.id}>
                    <td>
                      <span className="mode-label">
                        {session.mode === 'mystery'
                          ? 'Legacy quiz'
                          : session.mode === 'review'
                            ? 'Spaced review'
                            : session.mode}
                      </span>
                    </td>
                    <td>
                      {new Date(session.startedAt).toLocaleDateString(undefined, {
                        month: 'short',
                        day: 'numeric',
                      })}
                    </td>
                    <td>{formatDuration(session.duration)}</td>
                    <td>
                      {session.mode === 'remix'
                        ? session.adjustedWpm !== null
                          ? `${session.adjustedWpm} WPM · ${session.accuracy}% accuracy`
                          : 'Unscored typing practice'
                        : session.mode === 'zen'
                          ? 'A quiet little moment'
                          : `${session.correct} / ${session.cardsStudied} remembered`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="empty-message">No sessions yet. There’s no rush.</p>
        )}
      </section>
    </div>
  );
}

import { useMemo, useState } from 'react';
import { useApp } from '../appContext';
import { createId, database } from '../core/database';
import { parseCards } from '../core/transfer';
import { Modal } from '../components/Modal';
import { Icon } from '../components/Icon';

export function ImportCards({ onClose }: { onClose: () => void }) {
  const { profileId, notify } = useApp();
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [delimiter, setDelimiter] = useState('\t');
  const [skipHeader, setSkipHeader] = useState(false);
  const [busy, setBusy] = useState(false);
  const preview = useMemo(() => {
    try {
      const rows = parseCards(text, delimiter);
      return { cards: skipHeader ? rows.slice(1) : rows, error: '' };
    } catch (error) {
      return { cards: [], error: (error as Error).message };
    }
  }, [text, delimiter, skipHeader]);

  async function importCards() {
    if (!title.trim() || !preview.cards.length) return;
    setBusy(true);
    try {
      const setId = createId();
      await database.transaction('rw', database.sets, database.cards, async () => {
        await database.sets.add({
          id: setId,
          profileId,
          title: title.trim(),
          description: 'Imported study material',
          color: 'sand',
          updatedAt: Date.now(),
        });
        await database.cards.bulkAdd(
          preview.cards.map(([prompt, answer], position) => ({
            id: createId(),
            profileId,
            setId,
            prompt,
            answer,
            tags: [],
            position,
          })),
        );
      });
      notify(`${preview.cards.length} cards imported. Make yourself comfortable.`);
      onClose();
    } catch {
      notify('Your cards could not be imported. Check your available storage.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Bring your ideas along." onClose={onClose} wide>
      <p className="muted">
        Import two columns: prompt and answer. CSV, TSV, and two-column Anki text exports work here.
      </p>
      <label className="field-label">
        Set name
        <input
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Name this collection"
        />
      </label>
      <div className="import-options">
        <label className="button button-secondary file-button">
          <Icon name="upload" size={17} /> Choose a text file
          <input
            type="file"
            accept=".csv,.tsv,.txt"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              if (!file) return;
              if (file.size > 3 * 1024 * 1024) {
                notify('Choose a text file smaller than 3 MB.');
                return;
              }
              setText(await file.text());
              setDelimiter(file.name.endsWith('.csv') ? ',' : '\t');
              if (!title) setTitle(file.name.replace(/\.[^.]+$/, ''));
            }}
          />
        </label>
        <select
          aria-label="Column separator"
          value={delimiter}
          onChange={(event) => setDelimiter(event.target.value)}
        >
          <option value={'\t'}>Tab separated</option>
          <option value=",">Comma separated</option>
          <option value=";">Semicolon separated</option>
        </select>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={skipHeader}
            onChange={(event) => setSkipHeader(event.target.checked)}
          />{' '}
          First row is a header
        </label>
      </div>
      <textarea
        className="import-text"
        value={text}
        onChange={(event) => setText(event.target.value)}
        placeholder={
          'What is active recall?\tRemembering without your notes.\nWhat is a backup?\tA separate copy of your data.'
        }
        rows={6}
        aria-label="Study material to import"
      />
      {preview.error && (
        <p className="inline-error" role="alert">
          {preview.error}
        </p>
      )}
      {preview.cards.length > 0 && (
        <div className="import-preview">
          <h3>Preview · {preview.cards.length} cards</h3>
          <table>
            <thead>
              <tr>
                <th>Prompt</th>
                <th>Answer</th>
              </tr>
            </thead>
            <tbody>
              {preview.cards.slice(0, 20).map(([prompt, answer], index) => (
                <tr key={index}>
                  <td>{prompt}</td>
                  <td>{answer}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {preview.cards.length > 20 && (
            <p className="muted">
              Showing the first 20 cards. All {preview.cards.length} will be imported.
            </p>
          )}
        </div>
      )}
      <p className="fine-print">
        Anki .apkg packages and image-occlusion cards are planned for a later release.
      </p>
      <div className="modal-footer">
        <button className="button button-secondary" onClick={onClose}>
          Cancel
        </button>
        <button
          className="button button-primary"
          disabled={busy || !title.trim() || !preview.cards.length}
          onClick={() => void importCards()}
        >
          {busy ? 'Importing…' : `Import ${preview.cards.length} cards`}
          <Icon name="arrow" size={17} />
        </button>
      </div>
    </Modal>
  );
}

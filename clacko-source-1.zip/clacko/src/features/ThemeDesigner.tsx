import { useApp } from '../appContext';
import type { CustomTheme } from '../core/design';

const paper: CustomTheme = {
  canvas: '#f5f5f3',
  surface: '#ffffff',
  ink: '#252522',
  muted: '#78786f',
  correct: '#506b44',
  incorrect: '#b34d3d',
  caret: '#fe8b19',
};
const labels: Record<keyof CustomTheme, string> = {
  canvas: 'Page background',
  surface: 'Study surfaces',
  ink: 'Text',
  muted: 'Secondary text',
  correct: 'Correct characters',
  incorrect: 'Incorrect characters',
  caret: 'Caret',
};

export function ThemeDesigner() {
  const { preferences, setPreferences } = useApp();
  const theme = preferences.customTheme ?? paper;
  return (
    <div className="theme-designer">
      <h3 className="control-section-title">Mix your own theme</h3>
      <p className="fine-print">
        These tokens color the entire app. Save a named preset when it feels right.
      </p>
      {Object.entries(labels).map(([token, label]) => (
        <label key={token} className="field-label color-setting">
          {label}
          <input
            type="color"
            aria-label={`Theme ${label.toLowerCase()}`}
            value={theme[token as keyof CustomTheme]}
            onChange={(event) =>
              setPreferences({ customTheme: { ...theme, [token]: event.target.value } })
            }
          />
        </label>
      ))}
      <button
        className="text-button reset-button"
        onClick={() => setPreferences({ customTheme: undefined })}
      >
        Use the built-in theme colors
      </button>
    </div>
  );
}

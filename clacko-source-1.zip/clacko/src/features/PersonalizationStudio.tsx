import { useRef, useState, type ChangeEvent } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { KeyboardDesigner } from './KeyboardDesigner';
import { FontSettings } from './FontSettings';
import { ThemeDesigner } from './ThemeDesigner';
import { DesignTransfer } from './DesignTransfer';
import { MechvibesLibrary } from './MechvibesLibrary';
import { ZenAtmosphere } from './ZenAtmosphere';
import { useSceneStyle } from '../hooks/useSceneStyle';
import {
  createId,
  database,
  defaultPreferences,
  removeUnusedAssets,
  saveAsset,
} from '../core/database';
import { bundledStarterPack, starterPackId } from '../core/starterPack';
import { keyboardAudio } from '../core/audio';
import {
  activateImportedPack,
  inspectSoundPack,
  loadStoredPack,
  removeSoundPack,
} from '../core/soundPackImport';
import type { Preferences } from '../core/types';
import { Icon, type IconName } from '../components/Icon';
import { Keyboard } from '../components/Keyboard';
import { Mascot } from '../components/Mascot';
import { Modal } from '../components/Modal';
import { TypingSurface } from '../components/TypingSurface';

const tabs: Array<{ id: string; name: string; icon: IconName }> = [
  { id: 'keyboard', name: 'Keyboard', icon: 'keyboard' },
  { id: 'sound', name: 'Sound', icon: 'volume' },
  { id: 'background', name: 'Background', icon: 'image' },
  { id: 'type', name: 'Typography', icon: 'edit' },
  { id: 'zen', name: 'Zen world', icon: 'leaf' },
  { id: 'presets', name: 'Presets', icon: 'spark' },
];

function RangeControl({
  title,
  value,
  min,
  max,
  suffix = '',
  onChange,
}: {
  title: string;
  value: number;
  min: number;
  max: number;
  suffix?: string;
  onChange: (value: number) => void;
}) {
  return (
    <label className="range-control">
      <span>
        {title}
        <output>
          {value}
          {suffix}
        </output>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
      />
    </label>
  );
}

function Toggle({
  title,
  description,
  checked,
  onChange,
}: {
  title: string;
  description?: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <label className="toggle-control">
      <span>
        {title}
        {description && <small>{description}</small>}
      </span>
      <button
        role="switch"
        aria-checked={checked}
        aria-label={title}
        className={`toggle ${checked ? 'on' : ''}`}
        onClick={onChange}
      >
        <span />
      </button>
    </label>
  );
}

export function PersonalizationStudio() {
  const { profileId, preferences, setPreferences, notify } = useApp();
  const packs = useLiveQuery(
    () => database.packs.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const presets = useLiveQuery(
    () => database.presets.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const sceneStyle = useSceneStyle();
  const packSelection = useRef(0);
  const [selectedKey, setSelectedKey] = useState('KeyA');
  const [tab, setTab] = useState(() => {
    const requested = location.hash.split('/')[1];
    return tabs.some((item) => item.id === requested) ? requested : 'keyboard';
  });
  const [text, setText] = useState('');
  const [pendingPack, setPendingPack] = useState<Awaited<
    ReturnType<typeof inspectSoundPack>
  > | null>(null);
  const [busy, setBusy] = useState(false);
  const [presetName, setPresetName] = useState('');
  const [showPresetDialog, setShowPresetDialog] = useState(false);

  async function importPack(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    setBusy(true);
    try {
      setPendingPack(await inspectSoundPack(file, profileId));
    } catch (error) {
      notify((error as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function activatePack() {
    if (!pendingPack) return;
    setBusy(true);
    try {
      await activateImportedPack(pendingPack.pack, pendingPack.blobs);
      setPreferences({
        soundPackId: pendingPack.pack.id,
        soundEnabled: true,
        volume: Math.min(1, pendingPack.pack.recommendedVolume * 0.35),
      });
      setPendingPack(null);
      notify('A whole new sound. Go on, try it.');
    } catch (error) {
      notify((error as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function selectPack(id: string) {
    const selection = ++packSelection.current;
    try {
      const pack = packs.find((candidate) => candidate.id === id);
      if (pack) await loadStoredPack(pack, () => selection === packSelection.current);
      else if (id === starterPackId) {
        const { pack, files } = await bundledStarterPack();
        await keyboardAudio.preparePack(pack, files);
      } else keyboardAudio.useGeneratedPack();
      if (selection !== packSelection.current) return;
      setPreferences({ soundPackId: id });
      keyboardAudio.configure({ ...preferences, soundPackId: id });
      keyboardAudio.unlock().then(() => keyboardAudio.play('KeyA'));
    } catch (error) {
      notify((error as Error).message);
    }
  }

  async function uploadBackground(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (
      !['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(file.type) ||
      file.size > 8 * 1024 * 1024
    ) {
      notify('Choose a PNG, JPEG, WebP, or GIF smaller than 8 MB.');
      return;
    }
    try {
      setPreferences({ backgroundImage: await saveAsset(file) });
    } catch {
      notify('Your background could not be saved.');
    }
  }

  function applyTheme(theme: Preferences['theme']) {
    const colors = {
      paper: { keyColor: '#fbfaf7', accentColor: '#fe8b19' },
      midnight: { keyColor: '#41423f', accentColor: '#ffa755' },
      matcha: { keyColor: '#e7eadc', accentColor: '#7e935b' },
    };
    setPreferences({ theme, customTheme: undefined, ...colors[theme] });
  }

  async function savePreset() {
    if (!presetName.trim()) return;
    await database.presets.add({
      id: createId(),
      profileId,
      name: presetName.trim(),
      preferences: { ...preferences },
    });
    setShowPresetDialog(false);
    setPresetName('');
    notify('Your kind of cozy, saved.');
  }

  return (
    <div className="personalization-page">
      <div className="studio-heading">
        <div>
          <div className="eyebrow muted">PERSONALIZATION STUDIO</div>
          <h1>
            Your keys. Your kind of cozy<span className="heading-period">.</span>
          </h1>
          <p>A little tweak here. A little thock there. Make yourself at home.</p>
        </div>
        <button className="button button-secondary" onClick={() => setShowPresetDialog(true)}>
          <Icon name="plus" size={17} />
          Save a preset
        </button>
      </div>
      <div className="personalization-layout">
        <aside className="personalization-panel">
          <div className="panel-tabs" role="tablist" aria-label="Personalization category">
            {tabs.map((item) => (
              <button
                key={item.id}
                role="tab"
                aria-selected={tab === item.id}
                className={tab === item.id ? 'active' : ''}
                onClick={() => setTab(item.id)}
              >
                <Icon name={item.icon} size={17} />
                {item.name}
              </button>
            ))}
          </div>
          <div className="panel-content">
            {tab === 'keyboard' && (
              <>
                <KeyboardDesigner selectedCode={selectedKey} selectKey={setSelectedKey} />
                <Toggle
                  title="Keep the keyboard around"
                  checked={preferences.showKeyboard}
                  onChange={() => setPreferences({ showKeyboard: !preferences.showKeyboard })}
                />
                <Toggle
                  title="A little movement"
                  checked={preferences.motion}
                  onChange={() => setPreferences({ motion: !preferences.motion })}
                />
                <DesignTransfer kind="keyboard" />
              </>
            )}
            {tab === 'sound' && (
              <>
                <div className="panel-heading">
                  <h2>Mechvibes 3, at home.</h2>
                  <p>A satisfying little soundtrack.</p>
                </div>
                <Toggle
                  title="Keyboard sounds"
                  checked={preferences.soundEnabled}
                  onChange={() => setPreferences({ soundEnabled: !preferences.soundEnabled })}
                />
                <RangeControl
                  title="Volume"
                  min={0}
                  max={100}
                  value={Math.round(preferences.volume * 100)}
                  suffix="%"
                  onChange={(volume) => setPreferences({ volume: volume / 100 })}
                />
                <label className="field-label">Ready to play</label>
                <div className="sound-packs">
                  {[
                    {
                      id: starterPackId,
                      name: 'Cherry MX Brown · included',
                      detail: 'Real recordings · ready offline · CC0 by majod',
                    },
                    { id: 'soft', name: 'Soft landing', detail: 'A soft, friendly tap.' },
                    { id: 'deep', name: 'Deep thoughts', detail: 'A low, mellow thock.' },
                    { id: 'crisp', name: 'Freshly clicked', detail: 'A crisp little tick.' },
                    ...packs.map((pack) => ({
                      id: pack.id,
                      name: pack.name,
                      detail: `By ${pack.author}`,
                    })),
                  ].map((pack) => (
                    <div
                      className={`sound-pack-row ${preferences.soundPackId === pack.id ? 'selected' : ''}`}
                      key={pack.id}
                    >
                      <button
                        className="sound-pack-select"
                        aria-pressed={preferences.soundPackId === pack.id}
                        onClick={() => void selectPack(pack.id)}
                      >
                        <span className="sound-pack-icon">
                          <Icon name="volume" size={18} />
                        </span>
                        <span>
                          <strong>{pack.name}</strong>
                          <small>{pack.detail}</small>
                        </span>
                        {preferences.soundPackId === pack.id && <Icon name="check" size={17} />}
                      </button>
                      {!['soft', 'crisp', 'deep', starterPackId].includes(pack.id) && (
                        <button
                          className="icon-button small"
                          aria-label={`Remove ${pack.name}`}
                          onClick={async () => {
                            if (!window.confirm(`Remove “${pack.name}”?`)) return;
                            try {
                              await removeSoundPack(pack.id, profileId);
                              if (preferences.soundPackId === pack.id)
                                setPreferences({ soundPackId: starterPackId });
                              void removeUnusedAssets();
                            } catch (error) {
                              notify((error as Error).message);
                            }
                          }}
                        >
                          <Icon name="trash" size={14} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <Toggle
                  title="Homepage Clacko! greeting"
                  description="Say hello on your first homepage keystroke."
                  checked={preferences.homepageGreeting ?? true}
                  onChange={() =>
                    setPreferences({ homepageGreeting: !preferences.homepageGreeting })
                  }
                />
                <a
                  href="https://mechvibes.com/sound-packs/"
                  target="_blank"
                  rel="noreferrer"
                  className="text-button"
                >
                  Get more packs from Mechvibes
                  <Icon name="arrow" size={15} />
                </a>
                <MechvibesLibrary />
                <label className="button button-secondary full-width file-button">
                  <Icon name="upload" size={16} />
                  {busy ? 'Reading pack…' : 'Import ZIP'}
                  <input
                    disabled={busy}
                    type="file"
                    accept=".zip"
                    onChange={(event) => void importPack(event)}
                  />
                </label>
                <p className="fine-print">
                  Cherry MX Brown is included with Clacko. Soft, deep, and crisp are optional
                  synthesized sounds. Mechvibes 3 compatible packs can be imported below.
                </p>
              </>
            )}
            {tab === 'background' && (
              <>
                <div className="panel-heading">
                  <h2>A room of your own.</h2>
                  <p>Set the mood. Stay a while.</p>
                </div>
                <label className="field-label">Your atmosphere</label>
                <div className="theme-options">
                  {(['paper', 'midnight', 'matcha'] as const).map((theme) => (
                    <button
                      key={theme}
                      className={`theme-choice theme-${theme} ${preferences.theme === theme ? 'selected' : ''}`}
                      onClick={() => applyTheme(theme)}
                    >
                      <span />
                      <strong>
                        {theme === 'paper'
                          ? 'Sunday paper'
                          : theme === 'midnight'
                            ? 'After hours'
                            : 'Matcha break'}
                      </strong>
                      {preferences.theme === theme && <Icon name="check" size={15} />}
                    </button>
                  ))}
                </div>
                <label className="field-label">
                  A little texture
                  <select
                    value={preferences.background}
                    onChange={(event) =>
                      setPreferences({
                        background: event.target.value as Preferences['background'],
                      })
                    }
                  >
                    <option value="plain">Quiet & plain</option>
                    <option value="dots">Dot notebook</option>
                    <option value="grid">Graph paper</option>
                  </select>
                </label>
                <label className="button button-secondary full-width file-button">
                  <Icon name="image" size={16} />
                  Bring your own background
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/gif"
                    onChange={(event) => void uploadBackground(event)}
                  />
                </label>
                {preferences.backgroundImage && (
                  <>
                    <RangeControl
                      title="Keep things readable"
                      min={35}
                      max={95}
                      value={preferences.backgroundDim}
                      suffix="%"
                      onChange={(backgroundDim) => setPreferences({ backgroundDim })}
                    />
                    <button
                      className="text-button"
                      onClick={() => setPreferences({ backgroundImage: undefined })}
                    >
                      Remove background
                      <Icon name="close" size={14} />
                    </button>
                  </>
                )}
              </>
            )}
            {tab === 'background' && (
              <>
                <ThemeDesigner />
                <DesignTransfer kind="theme" />
              </>
            )}
            {tab === 'type' && <FontSettings />}
            {tab === 'zen' && <ZenAtmosphere />}
            {tab === 'presets' && (
              <>
                <div className="panel-heading">
                  <h2>Bottled-up good feelings.</h2>
                  <p>Your favorite setups, a click away.</p>
                </div>
                {presets.length ? (
                  <div className="preset-list">
                    {presets.map((preset) => (
                      <div className="preset-row" key={preset.id}>
                        <button
                          onClick={() => {
                            setPreferences({ ...preset.preferences, profileId });
                            notify(`“${preset.name}” feels like home.`);
                          }}
                        >
                          <span
                            className="preset-dot"
                            style={{ background: preset.preferences.accentColor }}
                          />
                          <strong>{preset.name}</strong>
                          <Icon name="arrow" size={16} />
                        </button>
                        <button
                          className="icon-button small"
                          aria-label={`Delete preset ${preset.name}`}
                          onClick={() => {
                            if (window.confirm(`Delete “${preset.name}”?`))
                              void database.presets.delete(preset.id);
                          }}
                        >
                          <Icon name="trash" size={14} />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="empty-presets">
                    <Icon name="spark" size={30} />
                    <p>Your first favorite is waiting to happen.</p>
                  </div>
                )}
                <button
                  className="button button-primary full-width"
                  onClick={() => setShowPresetDialog(true)}
                >
                  <Icon name="plus" size={17} />
                  Save this feeling
                </button>
                <button
                  className="text-button reset-button"
                  onClick={() => {
                    if (window.confirm('Reset your appearance and sound settings to the defaults?'))
                      setPreferences(defaultPreferences(profileId));
                  }}
                >
                  Back to the beginning
                  <Icon name="refresh" size={15} />
                </button>
              </>
            )}
          </div>
        </aside>
        <section
          className={`personalization-preview texture-${preferences.background} ${tab === 'zen' ? `zen-preview-${preferences.zen?.profile ?? 'off'}` : ''}`}
          style={sceneStyle}
        >
          <div className="preview-topline">
            <span className="eyebrow">
              <span className="tiny-dot" />
              LIVE LITTLE PLAYGROUND
            </span>
            <span>
              changes saved as you go
              <Icon name="check" size={13} />
            </span>
          </div>
          <div className="preview-writing">
            <span className="preview-greeting">Make some happy little noises.</span>
            <TypingSurface
              value={text}
              onChange={setText}
              placeholder="this feels like my kind of place."
              label="Personalization typing playground"
            />
          </div>
          {preferences.showKeyboard && (
            <Keyboard
              selectedCode={tab === 'keyboard' ? selectedKey : undefined}
              onSelectKey={tab === 'keyboard' ? setSelectedKey : undefined}
            />
          )}
          <div className="preview-note">
            <Mascot />
            <span>
              Try a key.
              <br />
              Find your happy place.
            </span>
            <svg viewBox="0 0 80 40" aria-hidden="true">
              <path d="M5 30c25 0 48-5 60-22m-12 4 13-5-1 14" />
            </svg>
          </div>
          <p className="preview-footer">Every little change is a little more you.</p>
        </section>
      </div>
      {pendingPack && (
        <Modal title="A new sound, incoming." onClose={() => setPendingPack(null)}>
          <h3>{pendingPack.pack.name}</h3>
          <p className="muted">By {pendingPack.pack.author}</p>
          <p>
            {Object.keys(pendingPack.pack.keys).length} key mappings ·{' '}
            {Object.keys(pendingPack.blobs).length} audio files
          </p>
          {pendingPack.pack.warnings.length > 0 && (
            <div className="import-warnings">
              {pendingPack.pack.warnings.slice(0, 8).map((warning, index) => (
                <p key={index}>{warning}</p>
              ))}
            </div>
          )}
          <p className="fine-print">
            Clacko will check that your browser can decode every file before activating this pack.
          </p>
          <div className="modal-footer">
            <button className="button button-secondary" onClick={() => setPendingPack(null)}>
              Cancel
            </button>
            <button
              className="button button-primary"
              disabled={busy}
              onClick={() => void activatePack()}
            >
              {busy ? 'Preparing sounds…' : 'Make it click'}
              <Icon name="volume" size={16} />
            </button>
          </div>
        </Modal>
      )}
      {showPresetDialog && (
        <Modal title="Give this feeling a name." onClose={() => setShowPresetDialog(false)}>
          <label className="field-label">
            Preset name
            <input
              autoFocus
              value={presetName}
              onChange={(event) => setPresetName(event.target.value)}
              placeholder="Sunday morning, maybe?"
              maxLength={60}
            />
          </label>
          <div className="modal-footer">
            <button className="button button-secondary" onClick={() => setShowPresetDialog(false)}>
              Cancel
            </button>
            <button
              className="button button-primary"
              disabled={!presetName.trim()}
              onClick={() => void savePreset()}
            >
              Save preset
              <Icon name="check" size={16} />
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from '../appContext';
import { createId, database } from '../core/database';
import {
  intervalLabel,
  newReviewState,
  reviewRatings,
  scheduleReview,
  type ReviewDirection,
  type ReviewRating,
  type ReviewState,
} from '../core/review';
import type { Flashcard } from '../core/types';
import { TypingSurface } from '../components/TypingSurface';
import { Icon } from '../components/Icon';
import { useAssetUrl } from '../hooks/useAssetUrl';
import { CardPicker } from './CardPicker';

function Attachment({ hash }: { hash?: string }) {
  const url = useAssetUrl(hash);
  return url ? <img className="study-card-image" src={url} alt="Study card attachment" /> : null;
}

const descriptions: Record<ReviewRating, string> = {
  again: 'I forgot',
  hard: 'Correct, but difficult',
  good: 'I remembered',
  easy: 'Effortless',
};

export function SpacedReview({
  initialSetIds,
  initialCardIds,
}: {
  initialSetIds: string[];
  initialCardIds?: string[];
}) {
  const { profileId, preferences, setPreferences, notify } = useApp();
  const cards = useLiveQuery(
    () => database.cards.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const states = useLiveQuery(
    () => database.reviews.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const attempts = useLiveQuery(
    () => database.attempts.where('profileId').equals(profileId).toArray(),
    [profileId],
    [],
  );
  const [selectedIds, setSelectedIds] = useState<string[]>(initialCardIds ?? []);
  const [direction, setDirection] = useState<ReviewDirection>('recall');
  const [newLimit, setNewLimit] = useState(preferences.reviewLimits?.newCards ?? 20);
  const [reviewLimit, setReviewLimit] = useState(preferences.reviewLimits?.reviews ?? 100);
  const [queue, setQueue] = useState<Flashcard[]>([]);
  const [running, setRunning] = useState(false);
  const [response, setResponse] = useState('');
  const [revealed, setRevealed] = useState(false);
  const [sessionId, setSessionId] = useState('');
  const [graded, setGraded] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [busy, setBusy] = useState(false);
  const [finished, setFinished] = useState(false);
  const [clock, setClock] = useState(Date.now());
  const [undo, setUndo] = useState<{
    card: Flashcard;
    previous?: ReviewState;
    attemptId: string;
    remembered: boolean;
  } | null>(null);
  const started = useRef(0);
  const lock = useRef(false);
  const card = queue[0];
  const relevantStates = states.filter((state) => state.direction === direction);
  const selected = cards.filter((item) => selectedIds.includes(item.id) && !item.suspended);
  const stateFor = (id: string) => relevantStates.find((state) => state.cardId === id);
  const counts = selected.reduce(
    (total, item) => {
      const state = stateFor(item.id);
      if (!state || state.state === 'new') total.new++;
      else if (state.state === 'learning' || state.state === 'relearning') total.learning++;
      else if (state.dueAt <= clock) total.due++;
      return total;
    },
    { new: 0, learning: 0, due: 0 },
  );
  const midnight = new Date().setHours(0, 0, 0, 0);
  const introducedToday = relevantStates.filter(
    (state) => (state.introducedAt ?? state.updatedAt) >= midnight,
  ).length;
  const reviewedToday = new Set(
    attempts
      .filter(
        (attempt) =>
          attempt.rating && attempt.createdAt >= midnight && attempt.direction === direction,
      )
      .map((attempt) => attempt.cardId),
  ).size;
  const currentState = card
    ? (stateFor(card.id) ?? newReviewState(profileId, card.id, direction))
    : undefined;

  useEffect(() => {
    setPreferences({ reviewLimits: { newCards: newLimit, reviews: reviewLimit } });
  }, [newLimit, reviewLimit]);

  useEffect(() => {
    const timer = setInterval(() => setClock(Date.now()), 15000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    const shortcut = (event: KeyboardEvent) => {
      if (!running || !revealed || busy || event.ctrlKey || event.metaKey || event.altKey) return;
      const rating = reviewRatings[Number(event.key) - 1];
      if (rating) {
        event.preventDefault();
        void grade(rating);
      }
    };
    window.addEventListener('keydown', shortcut);
    return () => window.removeEventListener('keydown', shortcut);
  }, [running, revealed, busy, card, states, graded, correct]);

  async function start() {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    try {
      const now = Date.now();
      const learning = selected.filter((item) => {
        const state = stateFor(item.id);
        return state && ['learning', 'relearning'].includes(state.state) && state.dueAt <= now;
      });
      const due = selected
        .filter((item) => {
          const state = stateFor(item.id);
          return state?.state === 'review' && state.dueAt <= now;
        })
        .sort((a, b) => stateFor(a.id)!.dueAt - stateFor(b.id)!.dueAt)
        .slice(0, Math.max(0, reviewLimit - reviewedToday));
      const fresh = selected
        .filter((item) => !stateFor(item.id) || stateFor(item.id)?.state === 'new')
        .slice(0, Math.max(0, newLimit - introducedToday));
      const next = [...learning, ...due, ...fresh];
      if (!next.length) {
        notify(
          'Nothing is due in this selection. Browse your cards, practice Recall, or return when a learning step is ready.',
        );
        return;
      }
      const id = createId();
      await database.sessions.add({
        id,
        profileId,
        mode: 'review',
        setIds: [...new Set(next.map((item) => item.setId))],
        startedAt: now,
        duration: 0,
        cardsStudied: 0,
        correct: 0,
        rawWpm: null,
        adjustedWpm: null,
        accuracy: null,
        insertedCharacters: 0,
        score: 0,
      });
      setSessionId(id);
      setQueue(next);
      setRunning(true);
      setFinished(false);
      setGraded(0);
      setCorrect(0);
      setResponse('');
      setRevealed(false);
      setUndo(null);
      started.current = performance.now();
    } catch (error) {
      notify(`Could not begin review: ${(error as Error).message}`);
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }

  async function grade(rating: ReviewRating) {
    if (!card || !currentState || lock.current) return;
    lock.current = true;
    setBusy(true);
    try {
      const previous = stateFor(card.id);
      const next = scheduleReview(currentState, rating, Date.now());
      const attemptId = createId();
      const remembered = rating !== 'again';
      await database.transaction(
        'rw',
        [database.reviews, database.attempts, database.sessions],
        async () => {
          await database.reviews.put(next);
          await database.attempts.add({
            id: attemptId,
            profileId,
            sessionId,
            cardId: card.id,
            direction,
            rating,
            correct: remembered,
            createdAt: Date.now(),
          });
          await database.sessions.update(sessionId, {
            cardsStudied: graded + 1,
            correct: correct + Number(remembered),
            duration: (performance.now() - started.current) / 1000,
          });
        },
      );
      setUndo({ card, previous, attemptId, remembered });
      setGraded(graded + 1);
      setCorrect(correct + Number(remembered));
      setQueue(queue.slice(1));
      setResponse('');
      setRevealed(false);
      setClock(Date.now());
      if (queue.length === 1) {
        setRunning(false);
        setFinished(true);
      }
    } catch {
      notify('This rating could not be saved. Please try again.');
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }

  async function undoRating() {
    if (!undo || lock.current) return;
    lock.current = true;
    setBusy(true);
    try {
      await database.transaction(
        'rw',
        [database.reviews, database.attempts, database.sessions],
        async () => {
          if (undo.previous) await database.reviews.put(undo.previous);
          else await database.reviews.delete(newReviewState(profileId, undo.card.id, direction).id);
          await database.attempts.delete(undo.attemptId);
          await database.sessions.update(sessionId, {
            cardsStudied: graded - 1,
            correct: correct - Number(undo.remembered),
          });
        },
      );
      setQueue([undo.card, ...queue]);
      setGraded(graded - 1);
      setCorrect(correct - Number(undo.remembered));
      setUndo(null);
      setRunning(true);
      setFinished(false);
      setResponse('');
      setRevealed(false);
    } catch {
      notify('The last rating could not be undone.');
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }

  if (running && card && currentState)
    return (
      <section className="review-session active-session">
        <div className="session-topline">
          <span className="session-mode">
            Spaced review · {queue.length} remaining · {graded} rated
          </span>
          <div className="row-actions">
            <button
              className="text-button"
              disabled={!undo || busy}
              onClick={() => void undoRating()}
            >
              Undo rating
            </button>
            <button
              className="text-button"
              onClick={() => {
                setRunning(false);
                setFinished(true);
              }}
            >
              Finish
            </button>
          </div>
        </div>
        <div className="recall-prompt">
          <span className="eyebrow muted">
            {direction === 'reverse' ? 'REMEMBER THE PROMPT' : 'WHAT COMES TO MIND?'} ·{' '}
            {currentState.state}
          </span>
          <h2>{direction === 'reverse' ? card.answer : card.prompt}</h2>
          <Attachment hash={direction === 'reverse' ? card.backImage : card.frontImage} />
        </div>
        <TypingSurface
          key={card.id}
          value={response}
          onChange={setResponse}
          disabled={revealed}
          placeholder="Type what you remember, then reveal…"
          onSubmit={() => setRevealed(true)}
          label="Review response"
        />
        {revealed ? (
          <div className="answer-reveal">
            <span className="eyebrow muted">COMPARE WITH YOUR ANSWER</span>
            <p>{direction === 'reverse' ? card.prompt : card.answer}</p>
            <Attachment hash={direction === 'reverse' ? card.frontImage : card.backImage} />
            <div className="review-ratings">
              {reviewRatings.map((rating, index) => (
                <button
                  key={rating}
                  className={`review-rating rating-${rating}`}
                  disabled={busy}
                  onClick={() => void grade(rating)}
                >
                  <small>
                    {intervalLabel(scheduleReview(currentState, rating, clock).dueAt, clock)}
                  </small>
                  <strong>
                    {index + 1} · {rating}
                  </strong>
                  <span>{descriptions[rating]}</span>
                </button>
              ))}
            </div>
            <p className="fine-print">
              Again means forgotten. Hard means you remembered, with difficulty. Each rating saves
              immediately.
            </p>
          </div>
        ) : (
          <div className="reveal-actions">
            <button className="button button-primary" onClick={() => setRevealed(true)}>
              Reveal answer <kbd>↵</kbd>
            </button>
            <button
              className="text-button"
              onClick={() => {
                setQueue(queue.slice(1));
                setResponse('');
                if (queue.length === 1) {
                  setRunning(false);
                  setFinished(true);
                }
              }}
            >
              Skip for this session
            </button>
          </div>
        )}
      </section>
    );

  return (
    <section className="review-setup">
      {finished && (
        <div className="review-finished">
          <Icon name="check" size={24} />
          <div>
            <h2>{graded} cards rated. Your progress is saved.</h2>
            <p>
              Learning cards return when their next step is due. There’s no need to wait on this
              screen.
            </p>
          </div>
          {undo && (
            <button className="text-button" onClick={() => void undoRating()}>
              Undo last rating
            </button>
          )}
        </div>
      )}
      <div className="review-intro">
        <div>
          <h2>A little today. A little later.</h2>
          <p>Type, reveal, and rate your memory. Clacko schedules your next review.</p>
        </div>
        <div className="review-counts">
          <span>
            <strong>{counts.new}</strong>New
          </span>
          <span>
            <strong>{counts.learning}</strong>Learning
          </span>
          <span>
            <strong>{counts.due}</strong>Due
          </span>
        </div>
      </div>
      <CardPicker
        initialSetIds={initialSetIds}
        initialCardIds={initialCardIds}
        onSelect={setSelectedIds}
      />
      <div className="setup-controls">
        <label className="field-label">
          Review direction
          <select
            value={direction}
            onChange={(event) => setDirection(event.target.value as ReviewDirection)}
          >
            <option value="recall">Prompt → answer</option>
            <option value="reverse">Answer → prompt</option>
          </select>
        </label>
        <label className="field-label">
          New cards per day
          <input
            type="number"
            min={0}
            max={1000}
            value={newLimit}
            onChange={(event) =>
              setNewLimit(Math.max(0, Math.min(1000, Number(event.target.value))))
            }
          />
        </label>
        <label className="field-label">
          Review cards per day
          <input
            type="number"
            min={0}
            max={5000}
            value={reviewLimit}
            onChange={(event) =>
              setReviewLimit(Math.max(0, Math.min(5000, Number(event.target.value))))
            }
          />
        </label>
      </div>
      <p className="fine-print">
        {introducedToday} introduced and {reviewedToday} unique cards reviewed today in this
        direction. Daily limits apply across your profile; due learning steps remain available.
      </p>
      <button
        className="button button-primary button-large"
        disabled={busy || !selected.length}
        onClick={() => void start()}
      >
        Review what’s ready
        <Icon name="arrow" size={18} />
      </button>
      <details className="scheduler-details">
        <summary>How scheduling works</summary>
        <p>
          New cards learn at 1 and 10 minute steps, then graduate to days. Again repeats a learning
          step; Hard moves cautiously; Good grows the interval; Easy gives more space. Forward and
          reverse have separate progress. This is Clacko’s simple scheduler, inspired by Anki’s
          review controls. It does not implement FSRS or import Anki scheduling.
        </p>
        <a href="https://docs.ankiweb.net/studying.html" target="_blank" rel="noreferrer">
          Read Anki’s study guide
        </a>
      </details>
    </section>
  );
}

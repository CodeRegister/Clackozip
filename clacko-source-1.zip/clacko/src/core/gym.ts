import { layoutLabels, type KeyboardLayout } from './keyboards';

export interface GymLesson {
  id: number;
  title: string;
  codes: string[];
  tip: string;
}
export type GymExercise = 'keys' | 'words' | 'text';

const stages: Array<[string, string[], string]> = [
  [
    'Find your home',
    ['KeyF', 'KeyJ'],
    'Find the raised bumps under your index fingers. Return here after each reach.',
  ],
  [
    'The home row',
    ['KeyD', 'KeyK', 'KeyS', 'KeyL', 'KeyA', 'Semicolon'],
    'Rest four fingers on each side of the home row. Keep your wrists relaxed.',
  ],
  [
    'Index fingers reach',
    ['KeyG', 'KeyH'],
    'Reach with your index fingers, then return to the bumps.',
  ],
  [
    'Up with the indexes',
    ['KeyR', 'KeyU'],
    'Move only the finger you need. Let the other fingers rest.',
  ],
  ['The middle reach', ['KeyE', 'KeyI'], 'Use your middle fingers for this upper-row reach.'],
  [
    'Rings and pinkies',
    ['KeyW', 'KeyO', 'KeyQ', 'KeyP'],
    'Stay loose. Accuracy comes before speed.',
  ],
  ['Across the top', ['KeyT', 'KeyY'], 'Your index fingers share the center columns.'],
  [
    'Down with indexes',
    ['KeyV', 'KeyM', 'KeyB', 'KeyN'],
    'Keep the movement small and return to the home row.',
  ],
  [
    'The lower corners',
    ['KeyC', 'Comma', 'KeyX', 'Period', 'KeyZ', 'Slash'],
    'Use middle, ring, and pinky fingers for the outer lower keys.',
  ],
  [
    'Punctuation reach',
    ['Quote', 'BracketLeft', 'BracketRight', 'Backslash'],
    'Use the right pinky for the far right keys. Take a break if your hands feel tense.',
  ],
  [
    'Numbers near home',
    ['Digit4', 'Digit5', 'Digit6', 'Digit7'],
    'Lift the index fingers to the number row and return.',
  ],
  [
    'Numbers to the sides',
    ['Digit3', 'Digit8', 'Digit2', 'Digit9'],
    'Reach with middle and ring fingers, one key at a time.',
  ],
  [
    'The outer numbers',
    ['Digit1', 'Digit0', 'Minus', 'Equal'],
    'Pinky reaches are small. Keep your hands level.',
  ],
  ['Everyday rhythm', [], 'Read a little ahead while keeping an even rhythm.'],
  [
    'Your whole keyboard',
    [],
    'Practice comfortably. Speed will follow consistent, accurate typing.',
  ],
];
export const gymLessons: GymLesson[] = stages.map(([title, codes, tip], index) => ({
  id: index + 1,
  title,
  codes,
  tip,
}));

export function lessonCodes(id: number): string[] {
  return [
    ...new Set(gymLessons.filter((lesson) => lesson.id <= id).flatMap((lesson) => lesson.codes)),
  ];
}

// Original short material; no exercise text is copied from TypingStudy.
const words =
  'a as all ask add fall dad sad lad flask salad glass flag half flash shall had hall has lash dash lake jade safe sale fake fade sail idea read dear dare hair fair far air rain train tree tire red ride true try type you your quiet power word world we were what why with without while quick brown fox jumps over lazy dog small steps make good habits calm hands rest light open close home learn every little key practice patient paper remember return focus gentle rhythm'.split(
    ' ',
  );
const sentences = [
  'small steps make good habits.',
  'calm hands find a gentle rhythm.',
  'read a little ahead and return home.',
  'take a breath and try each key again.',
  'your next good habit begins with practice.',
  'we learn a little with every quiet moment.',
  'the quick brown fox jumps over the lazy dog.',
];

export function gymText(
  id: number,
  layout: KeyboardLayout,
  exercise: GymExercise,
  weakCodes: string[] = [],
): string {
  const labels = layoutLabels(layout);
  const allowedCodes = lessonCodes(id);
  const codes = weakCodes.length
    ? weakCodes.filter((code) => allowedCodes.includes(code))
    : allowedCodes;
  const pool = (codes.length ? codes : allowedCodes)
    .map(
      (code) =>
        labels[code] ??
        (code.startsWith('Digit')
          ? code.slice(5)
          : code === 'Minus'
            ? '-'
            : code === 'Equal'
              ? '='
              : ''),
    )
    .filter(Boolean);
  if (exercise === 'keys') {
    const newest =
      gymLessons[id - 1]?.codes
        .filter((code) => codes.includes(code))
        .map(
          (code) =>
            labels[code] ??
            (code.startsWith('Digit') ? code.slice(5) : code === 'Minus' ? '-' : '='),
        ) ?? [];
    const target = weakCodes.length || !newest.length ? pool : [...newest, ...pool];
    return Array.from({ length: 12 }, (_, index) =>
      Array.from({ length: 4 }, (_, column) => target[(index * 3 + column) % target.length]).join(
        '',
      ),
    ).join(' ');
  }
  const available = new Set(pool.join('') + ' ');
  const suitableWords = words.filter((word) => [...word].every((letter) => available.has(letter)));
  if (exercise === 'text') {
    const suitable = sentences.filter((sentence) =>
      [...sentence].every((letter) => available.has(letter)),
    );
    if (suitable.length) return suitable.slice(0, 3).join(' ');
  }
  if (suitableWords.length >= 3)
    return Array.from(
      { length: 20 },
      (_, index) => suitableWords[(index * 7 + id) % suitableWords.length],
    ).join(' ');
  return gymText(id, layout, 'keys', weakCodes);
}

export function codeForCharacter(
  character: string | undefined,
  layout: KeyboardLayout,
): string | undefined {
  if (character === ' ') return 'Space';
  return (
    Object.entries(layoutLabels(layout)).find(([, label]) => label === character)?.[0] ??
    (/^\d$/.test(character ?? '')
      ? `Digit${character}`
      : character === '-'
        ? 'Minus'
        : character === '='
          ? 'Equal'
          : undefined)
  );
}

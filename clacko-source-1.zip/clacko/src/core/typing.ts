export interface TypingMetrics {
  rawWpm: number;
  adjustedWpm: number;
  accuracy: number;
}

export function graphemes(text: string): string[] {
  return Array.from(
    new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(text),
    (item) => item.segment,
  );
}

export function calculateMetrics(
  input: string,
  target: string,
  insertedCharacters: number,
  correctInsertions: number,
  elapsedSeconds: number,
): TypingMetrics {
  const minutes = elapsedSeconds / 60;
  const inputCharacters = graphemes(input);
  const targetCharacters = graphemes(target);
  const retainedCorrect = inputCharacters.filter(
    (character, index) => character === targetCharacters[index],
  ).length;

  return {
    rawWpm: minutes > 0 ? Math.round(insertedCharacters / 5 / minutes) : 0,
    adjustedWpm: minutes > 0 ? Math.round(retainedCorrect / 5 / minutes) : 0,
    accuracy:
      insertedCharacters > 0 ? Math.round((correctInsertions / insertedCharacters) * 100) : 100,
  };
}

/** A phrase remains intact; Remix shuffles complete study entries, never letters. */
export function extractRemixText(
  cards: Array<{ prompt: string; answer: string }>,
  source: 'prompts' | 'answers' | 'both',
): string {
  const phrases = cards.flatMap((card) => {
    if (source === 'prompts') return [card.prompt];
    if (source === 'answers') return [card.answer];
    return [card.prompt, card.answer];
  });
  return [...new Set(phrases.map((phrase) => phrase.trim()).filter(Boolean))].join(' ');
}

export function normalizeAnswer(text: string): string {
  return text.normalize('NFC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('en');
}

export function matchesAnswer(response: string, answer: string): boolean {
  return normalizeAnswer(response) === normalizeAnswer(answer);
}

export function formatDuration(seconds: number): string {
  const wholeSeconds = Math.max(0, Math.floor(seconds));
  return `${Math.floor(wholeSeconds / 60)}:${String(wholeSeconds % 60).padStart(2, '0')}`;
}

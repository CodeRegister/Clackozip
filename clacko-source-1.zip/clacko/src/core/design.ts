import type { KeyboardLayout, KeyboardModel } from './keyboards';
import type { Preferences } from './types';

export interface KeySound {
  packId?: string;
  sampleCode?: string;
  assetHash?: string;
  volume: number;
  procedural?: 'pixel' | 'bell' | 'wood';
}

export interface KeyDesign {
  color?: string;
  legendColor?: string;
  label?: string;
  decal?: string;
  decalOpacity?: number;
  sound?: KeySound;
  effect?: 'press' | 'glow' | 'ripple' | 'bounce' | 'none';
}

export interface KeyboardDesign {
  caseColor: string;
  caseImage?: string;
  imageOpacity: number;
  legendColor: string;
  pressedColor: string;
  keys: Record<string, KeyDesign>;
  model?: KeyboardModel;
  layout?: KeyboardLayout;
  material?: 'plastic' | 'aluminum' | 'wood' | 'glass';
  keyMaterial?: 'abs' | 'pbt' | 'rubber';
  effect?: 'press' | 'glow' | 'ripple' | 'bounce' | 'none';
  effectIntensity?: number;
  effectDuration?: number;
  customRows?: string[][];
  customWidths?: Record<string, number>;
}

export interface CustomTheme {
  canvas: string;
  surface: string;
  ink: string;
  muted: string;
  correct: string;
  incorrect: string;
  caret: string;
}

export interface LocalFont {
  name: string;
  hash: string;
}

export type ZenProfile = 'off' | 'pixel' | 'christmas' | 'spooky' | 'rain';
export interface MusicTrack {
  id: string;
  name: string;
  hash: string;
}
export interface ZenSettings {
  profile: ZenProfile;
  volume: number;
  reactive: boolean;
  playlist: MusicTrack[];
  musicVolume: number;
  loopTrack: boolean;
}

export function defaultKeyboardDesign(): KeyboardDesign {
  return {
    model: 'sixty-five',
    layout: 'qwerty-us',
    material: 'plastic',
    keyMaterial: 'pbt',
    effect: 'press',
    effectIntensity: 1,
    effectDuration: 220,
    caseColor: '#d4d3cc',
    imageOpacity: 0.75,
    legendColor: '#6e6e64',
    pressedColor: '#fe8b19',
    keys: {},
  };
}

export function defaultZenSettings(): ZenSettings {
  return {
    profile: 'off',
    volume: 0.2,
    reactive: true,
    playlist: [],
    musicVolume: 0.35,
    loopTrack: false,
  };
}

/** A single reference walk is shared by profile backups and portable designs. */
export function appearanceAssetHashes(settings: Preferences): string[] {
  const hashes = new Set<string>();
  const add = (hash?: string) => {
    if (hash) hashes.add(hash);
  };
  add(settings.backgroundImage);
  add(settings.keyboard?.caseImage);
  add(settings.customFont?.hash);
  for (const key of Object.values(settings.keyboard?.keys ?? {})) {
    add(key.decal);
    add(key.sound?.assetHash);
  }
  for (const track of settings.zen?.playlist ?? []) add(track.hash);
  return [...hashes];
}

export function referencedPackIds(settings: Preferences): string[] {
  const ids = new Set([settings.soundPackId]);
  for (const key of Object.values(settings.keyboard?.keys ?? {})) {
    if (key.sound?.packId) ids.add(key.sound.packId);
  }
  return [...ids];
}

/** IDs are local to a profile; preserve the sound assignment when importing a look. */
export function remapAppearancePacks(settings: Preferences, ids: Map<string, string>): Preferences {
  return {
    ...settings,
    soundPackId: ids.get(settings.soundPackId) ?? settings.soundPackId,
    keyboard: settings.keyboard
      ? {
          ...settings.keyboard,
          keys: Object.fromEntries(
            Object.entries(settings.keyboard.keys).map(([code, key]) => [
              code,
              {
                ...key,
                sound: key.sound
                  ? {
                      ...key.sound,
                      packId: key.sound.packId
                        ? (ids.get(key.sound.packId) ?? key.sound.packId)
                        : undefined,
                    }
                  : undefined,
              },
            ]),
          ),
        }
      : undefined,
  };
}

import type { CustomTheme, KeyboardDesign, LocalFont, ZenSettings } from './design';

export type StudyMode = 'zen' | 'remix' | 'recall' | 'reverse' | 'mystery' | 'review';
export type Page = 'library' | 'study' | 'personalize' | 'statistics' | 'cards' | 'gym';

export interface Profile {
  id: string;
  name: string;
  createdAt: number;
}

export interface StudySet {
  id: string;
  profileId: string;
  title: string;
  description: string;
  color: 'sand' | 'sage' | 'lavender' | 'rose';
  updatedAt: number;
}

export interface Flashcard {
  id: string;
  profileId: string;
  setId: string;
  prompt: string;
  answer: string;
  tags: string[];
  frontImage?: string;
  backImage?: string;
  position: number;
  starred?: boolean;
  suspended?: boolean;
}

export interface Preferences {
  profileId: string;
  theme: 'paper' | 'midnight' | 'matcha';
  keyColor: string;
  accentColor: string;
  keyRadius: number;
  keyboardSize: number;
  showKeyboard: boolean;
  soundEnabled: boolean;
  soundPackId: string;
  volume: number;
  fontSize: number;
  fontFamily: 'mono' | 'sans' | 'system' | 'custom';
  caretStyle: 'line' | 'block' | 'underline';
  smoothCaret: boolean;
  background: 'plain' | 'dots' | 'grid';
  backgroundImage?: string;
  backgroundDim: number;
  motion: boolean;
  keyboard?: KeyboardDesign;
  customTheme?: CustomTheme;
  customFont?: LocalFont;
  zen?: ZenSettings;
  proceduralScope?: 'zen' | 'study' | 'everywhere';
  homepageGreeting?: boolean;
  reviewLimits?: { newCards: number; reviews: number };
}

export interface AppearancePreset {
  id: string;
  profileId: string;
  name: string;
  preferences: Preferences;
}

export interface MediaAsset {
  hash: string;
  blob: Blob;
}

export interface SoundSegment {
  file: string;
  start: number;
  end?: number;
}

export interface PackKey {
  down: SoundSegment;
  up?: SoundSegment;
}

export interface SoundPack {
  id: string;
  profileId: string;
  name: string;
  author: string;
  keys: Record<string, PackKey>;
  files: Record<string, string>;
  originalConfig: string;
  warnings: string[];
  recommendedVolume: number;
  randomPitch: boolean;
}

export interface StudySession {
  id: string;
  profileId: string;
  mode: StudyMode;
  setIds: string[];
  startedAt: number;
  duration: number;
  cardsStudied: number;
  correct: number;
  rawWpm: number | null;
  adjustedWpm: number | null;
  accuracy: number | null;
  insertedCharacters: number;
  score: number;
}

export interface Attempt {
  id: string;
  profileId: string;
  sessionId: string;
  cardId: string;
  direction: 'recall' | 'reverse' | 'mystery';
  rating?: import('./review').ReviewRating;
  correct: boolean;
  createdAt: number;
}

export interface SessionDraft {
  profileId: string;
  mode: StudyMode;
  setIds: string[];
  cardIds: string[];
  cursor: number;
  response: string;
  elapsed: number;
  correct: number;
  score: number;
  combo: number;
  bestCombo: number;
  sessionId: string;
  source: 'prompts' | 'answers' | 'both';
  secondsPerCard: number;
  cardStartedAt: number;
  insertedCharacters: number;
  correctInsertions: number;
  revealed: boolean;
  timedOut: boolean;
  pasted: boolean;
}

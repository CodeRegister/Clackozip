export type KeyboardModel = 'sixty-five' | 'sixty' | 'tkl' | 'full' | 'typewriter' | 'custom';
export type KeyboardLayout =
  'qwerty-us' | 'qwerty-uk' | 'qwertz-de' | 'azerty-fr' | 'dvorak' | 'colemak';
export interface PhysicalKey {
  code: string;
  label: string;
  width?: number;
}
export const keyboardModels: Array<{ id: KeyboardModel; name: string; detail: string }> = [
  { id: 'sixty-five', name: '65% compact', detail: 'Your everyday keys, plus arrows.' },
  { id: 'sixty', name: '60% minimal', detail: 'A small board with only the essentials.' },
  { id: 'tkl', name: 'Tenkeyless', detail: 'Function row and navigation, no number pad.' },
  { id: 'full', name: 'Full size', detail: 'Function row, navigation, and number pad.' },
  {
    id: 'typewriter',
    name: 'Old-school typewriter',
    detail: 'Round keys and a substantial frame.',
  },
  { id: 'custom', name: 'My own board', detail: 'Build rows from physical key codes.' },
];
export const keyboardLayouts: Array<{ id: KeyboardLayout; name: string; letters: string[] }> = [
  {
    id: 'qwerty-us',
    name: 'English · QWERTY US',
    letters: ['qwertyuiop[]', "asdfghjkl;'", 'zxcvbnm,./'],
  },
  {
    id: 'qwerty-uk',
    name: 'English · QWERTY UK',
    letters: ['qwertyuiop[]', "asdfghjkl;'", 'zxcvbnm,./'],
  },
  {
    id: 'qwertz-de',
    name: 'German · QWERTZ',
    letters: ['qwertzuiopü+', 'asdfghjklöä', 'yxcvbnm,.-'],
  },
  {
    id: 'azerty-fr',
    name: 'French · AZERTY',
    letters: ['azertyuiop^$', 'qsdfghjklmù', 'wxcvbn,;:!'],
  },
  {
    id: 'dvorak',
    name: 'English · Dvorak',
    letters: ["',.pyfgcrl/=", 'aoeuidhtns-', ';qjkxbmwvz'],
  },
  {
    id: 'colemak',
    name: 'English · Colemak',
    letters: ['qwfpgjluy;[]', "arstdhneio'", 'zxcvbkm,./'],
  },
];
const letterCodes = [
  [
    'KeyQ',
    'KeyW',
    'KeyE',
    'KeyR',
    'KeyT',
    'KeyY',
    'KeyU',
    'KeyI',
    'KeyO',
    'KeyP',
    'BracketLeft',
    'BracketRight',
  ],
  ['KeyA', 'KeyS', 'KeyD', 'KeyF', 'KeyG', 'KeyH', 'KeyJ', 'KeyK', 'KeyL', 'Semicolon', 'Quote'],
  ['KeyZ', 'KeyX', 'KeyC', 'KeyV', 'KeyB', 'KeyN', 'KeyM', 'Comma', 'Period', 'Slash'],
];
export function layoutLabels(layout: KeyboardLayout = 'qwerty-us'): Record<string, string> {
  const selected = keyboardLayouts.find((item) => item.id === layout) ?? keyboardLayouts[0];
  const labels: Record<string, string> = { Minus: '-', Equal: '=', Backslash: '\\' };
  for (const digit of '1234567890') labels[`Digit${digit}`] = digit;
  letterCodes.forEach((row, index) =>
    row.forEach((code, column) => {
      labels[code] = [...selected.letters[index]][column];
    }),
  );
  if (layout === 'qwerty-uk') labels.Backslash = '#';
  if (layout === 'dvorak') {
    labels.Minus = '[';
    labels.Equal = ']';
  }
  if (layout === 'qwertz-de') {
    labels.Backslash = '#';
    labels.Minus = 'ß';
    labels.Equal = '´';
  }
  if (layout === 'azerty-fr') {
    [...'&é"\'(-è_çà'].forEach((label, index) => {
      labels[`Digit${(index + 1) % 10}`] = label;
    });
    labels.Backslash = '*';
    labels.Minus = ')';
    labels.Equal = '=';
  }
  return labels;
}
const characters = (letters: string): PhysicalKey[] =>
  [...letters].map((letter) => ({ code: `Key${letter.toUpperCase()}`, label: letter }));
export const baseKeyboardRows: PhysicalKey[][] = [
  [
    { code: 'Escape', label: 'esc' },
    ...[...'1234567890'].map((digit) => ({ code: `Digit${digit}`, label: digit })),
    { code: 'Minus', label: '−' },
    { code: 'Equal', label: '=' },
    { code: 'Backspace', label: 'delete', width: 1.8 },
  ],
  [
    { code: 'Tab', label: 'tab', width: 1.4 },
    ...characters('qwertyuiop'),
    { code: 'BracketLeft', label: '[' },
    { code: 'BracketRight', label: ']' },
    { code: 'Backslash', label: '\\', width: 1.4 },
  ],
  [
    { code: 'CapsLock', label: 'caps', width: 1.7 },
    ...characters('asdfghjkl'),
    { code: 'Semicolon', label: ';' },
    { code: 'Quote', label: "'" },
    { code: 'Enter', label: 'return', width: 2.1 },
  ],
  [
    { code: 'ShiftLeft', label: 'shift', width: 2.2 },
    ...characters('zxcvbnm'),
    { code: 'Comma', label: ',' },
    { code: 'Period', label: '.' },
    { code: 'Slash', label: '/' },
    { code: 'ShiftRight', label: 'shift', width: 2.6 },
  ],
  [
    { code: 'ControlLeft', label: 'ctrl', width: 1.2 },
    { code: 'MetaLeft', label: '⌘', width: 1.2 },
    { code: 'AltLeft', label: 'alt', width: 1.2 },
    { code: 'Space', label: 'clacko', width: 6.2 },
    { code: 'AltRight', label: 'alt', width: 1.2 },
    { code: 'ArrowLeft', label: '←' },
    { code: 'ArrowDown', label: '↓' },
    { code: 'ArrowRight', label: '→' },
  ],
];
const extras: PhysicalKey[] = [
  { code: 'ArrowUp', label: '↑' },
  ...['Home', 'End', 'Insert', 'Delete', 'PageUp', 'PageDown'].map((code) => ({
    code,
    label: code.replace('Page', 'pg'),
  })),
  ...Array.from({ length: 12 }, (_, index) => ({ code: `F${index + 1}`, label: `F${index + 1}` })),
  ...[...'0123456789'].map((number) => ({ code: `Numpad${number}`, label: number })),
  { code: 'NumpadEnter', label: 'enter' },
  { code: 'NumpadAdd', label: '+' },
  { code: 'NumpadSubtract', label: '−' },
  { code: 'NumpadMultiply', label: '*' },
  { code: 'NumpadDivide', label: '/' },
  { code: 'NumpadDecimal', label: '.' },
];
export const allPhysicalKeys = [...baseKeyboardRows.flat(), ...extras];
export function keyboardRowsFor(
  model: KeyboardModel = 'sixty-five',
  layout: KeyboardLayout = 'qwerty-us',
  customRows?: string[][],
): PhysicalKey[][] {
  const rows = baseKeyboardRows.map((row) => row.map((key) => ({ ...key })));
  if (model === 'sixty-five')
    rows[4].splice(rows[4].length - 1, 0, { code: 'ArrowUp', label: '↑' });
  if (model === 'sixty' || model === 'typewriter')
    rows[4] = rows[4].filter((key) => !key.code.startsWith('Arrow'));
  if (model === 'tkl' || model === 'full') {
    rows.unshift([
      { code: 'Escape', label: 'esc' },
      ...extras.filter((key) => /^F\d+$/.test(key.code)),
    ]);
    rows[1] = rows[1].filter((key) => key.code !== 'Escape');
    rows[1].push(...extras.filter((key) => ['Insert', 'Home', 'PageUp'].includes(key.code)));
    rows[2].push(...extras.filter((key) => ['Delete', 'End', 'PageDown'].includes(key.code)));
    rows[4].push({ code: 'ArrowUp', label: '↑' });
  }
  if (model === 'full') {
    rows[1].push(
      ...['NumpadDivide', 'NumpadMultiply', 'NumpadSubtract'].map((code) =>
        extras.find((key) => key.code === code)!,
      ),
    );
    rows[2].push(
      ...['Numpad7', 'Numpad8', 'Numpad9', 'NumpadAdd'].map((code) =>
        extras.find((key) => key.code === code)!,
      ),
    );
    rows[3].push(
      ...['Numpad4', 'Numpad5', 'Numpad6'].map((code) => extras.find((key) => key.code === code)!),
    );
    rows[4].push(
      ...['Numpad1', 'Numpad2', 'Numpad3', 'NumpadEnter'].map((code) =>
        extras.find((key) => key.code === code)!,
      ),
    );
    rows[5].push(
      ...['Numpad0', 'NumpadDecimal'].map((code) => extras.find((key) => key.code === code)!),
    );
  }
  const selectedRows =
    model === 'custom' && customRows?.length
      ? customRows.map((row) =>
          row
            .map((code) => allPhysicalKeys.find((key) => key.code === code))
            .filter((key): key is PhysicalKey => Boolean(key)),
        )
      : rows;
  const labels = layoutLabels(layout);
  return selectedRows.map((row) =>
    row.map((key) => ({ ...key, label: labels[key.code] ?? key.label })),
  );
}
export function fingerForCode(code: string): string {
  if (['KeyF', 'KeyR', 'KeyT', 'KeyG', 'KeyV', 'KeyB', 'Digit4', 'Digit5'].includes(code))
    return 'Left index';
  if (['KeyJ', 'KeyU', 'KeyY', 'KeyH', 'KeyN', 'KeyM', 'Digit6', 'Digit7'].includes(code))
    return 'Right index';
  if (['KeyD', 'KeyE', 'KeyC', 'Digit3'].includes(code)) return 'Left middle';
  if (['KeyK', 'KeyI', 'Comma', 'Digit8'].includes(code)) return 'Right middle';
  if (['KeyS', 'KeyW', 'KeyX', 'Digit2'].includes(code)) return 'Left ring';
  if (['KeyL', 'KeyO', 'Period', 'Digit9'].includes(code)) return 'Right ring';
  if (code === 'Space') return 'Either thumb';
  return ['KeyQ', 'KeyA', 'KeyZ', 'Digit1', 'Tab', 'CapsLock', 'ShiftLeft', 'Escape'].includes(code)
    ? 'Left pinky'
    : 'Right pinky';
}

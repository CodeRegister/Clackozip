import { database, saveAsset } from './database';
import type { LocalFont } from './design';

const MAX_FONT_BYTES = 5 * 1024 * 1024;

export async function importFontFile(file: File, name: string): Promise<LocalFont> {
  if (!/\.(woff2?|ttf|otf)$/i.test(file.name))
    throw new Error('Choose a WOFF2, WOFF, TTF, or OTF font.');
  if (file.size > MAX_FONT_BYTES) throw new Error('Choose a font smaller than 5 MB.');
  const face = new FontFace('ClackoFontCheck', await file.arrayBuffer());
  await face.load();
  return { name: name.trim() || file.name.replace(/\.[^.]+$/, ''), hash: await saveAsset(file) };
}

/** Fetch only font bytes. Downloaded CSS is parsed for a font URL, never injected. */
export async function downloadFont(link: string, name: string): Promise<LocalFont> {
  const url = new URL(link);
  if (url.protocol !== 'https:' || url.username || url.password)
    throw new Error('Use a direct HTTPS font link or a Google Fonts CSS link.');
  const response = await fetch(url, { credentials: 'omit', signal: AbortSignal.timeout(20000) });
  if (!response.ok) throw new Error('The font could not be downloaded. Check its link.');
  if (Number(response.headers.get('content-length')) > MAX_FONT_BYTES)
    throw new Error('This font is larger than 5 MB.');
  let blob = await response.blob();
  if (blob.size > MAX_FONT_BYTES) throw new Error('This font is larger than 5 MB.');
  let extension = url.pathname.split('.').at(-1) ?? 'woff2';
  if (blob.type.includes('text/css') || url.hostname === 'fonts.googleapis.com') {
    const css = await blob.text();
    if (css.length > 150000) throw new Error('Choose a link for one font family.');
    // Prefer the final Latin subset; that is how Google Fonts orders its CSS.
    const urls = [...css.matchAll(/url\(\s*['"]?([^)'"\s]+)['"]?\s*\)/g)];
    const source = urls.at(-1)?.[1];
    if (!source) throw new Error('No downloadable font was found in this stylesheet.');
    const fontUrl = new URL(source, url);
    if (fontUrl.protocol !== 'https:')
      throw new Error('The stylesheet must reference an HTTPS font.');
    const fontResponse = await fetch(fontUrl, {
      credentials: 'omit',
      signal: AbortSignal.timeout(20000),
    });
    if (!fontResponse.ok)
      throw new Error('The font server refused the download. Upload the font file instead.');
    blob = await fontResponse.blob();
    extension = fontUrl.pathname.split('.').at(-1) ?? 'woff2';
  }
  return importFontFile(new File([blob], `download.${extension}`), name || 'My downloaded font');
}

let activeFace: FontFace | undefined;
let fontGeneration = 0;

export async function activateLocalFont(font?: LocalFont): Promise<void> {
  const generation = ++fontGeneration;
  if (!font) return;
  const asset = await database.assets.get(font.hash);
  if (!asset) throw new Error('The saved font file is missing. Please import it again.');
  const face = new FontFace('ClackoCustom', await asset.blob.arrayBuffer());
  await face.load();
  if (generation !== fontGeneration) return;
  if (activeFace) document.fonts.delete(activeFace);
  document.fonts.add(face);
  activeFace = face;
}

export function typingFontFamily(family: string): string {
  if (family === 'custom') return 'ClackoCustom, system-ui, sans-serif';
  if (family === 'system') return 'ui-monospace, "Cascadia Code", "Courier New", monospace';
  return family === 'mono' ? '"JetBrains Mono", monospace' : '"Inter Variable", sans-serif';
}

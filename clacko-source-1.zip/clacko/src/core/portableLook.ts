import { strFromU8, strToU8, unzipSync, zipSync } from 'fflate';
import { createId, database, defaultPreferences } from './database';
import { appearanceAssetHashes, referencedPackIds, remapAppearancePacks } from './design';
import { downloadFile, validatePreferences } from './transfer';
import { parseMechvibesConfig } from './mechvibes';
import type { Preferences, SoundPack } from './types';

export type LookKind = 'keyboard' | 'theme';
interface LookManifest {
  format: 'clacko-look';
  version: 1;
  kind: LookKind;
  name: string;
  settings: Partial<Preferences>;
  packs: SoundPack[];
  assets: Array<{ hash: string; type: string; size: number }>;
}
export interface LookPreview {
  manifest: LookManifest;
  assets: Array<{ hash: string; blob: Blob }>;
}

function scopedSettings(settings: Preferences, kind: LookKind): Partial<Preferences> {
  const keys: Array<keyof Preferences> =
    kind === 'keyboard'
      ? [
          'keyboard',
          'keyColor',
          'keyRadius',
          'keyboardSize',
          'showKeyboard',
          'soundPackId',
          'volume',
          'motion',
        ]
      : [
          'theme',
          'customTheme',
          'accentColor',
          'fontFamily',
          'customFont',
          'fontSize',
          'caretStyle',
          'background',
          'backgroundImage',
          'backgroundDim',
        ];
  return Object.fromEntries(keys.map((key) => [key, settings[key]]));
}

export async function buildLook(
  settings: Preferences,
  kind: LookKind,
  name: string,
): Promise<Uint8Array> {
  const patch = scopedSettings(settings, kind);
  const full = { ...defaultPreferences(settings.profileId), ...patch };
  const packs: SoundPack[] = [];
  const hashes = new Set(appearanceAssetHashes(full));
  for (const id of kind === 'keyboard' ? referencedPackIds(full) : []) {
    const pack = await database.packs.get(id);
    if (pack?.profileId === settings.profileId) {
      packs.push(pack);
      Object.values(pack.files).forEach((hash) => hashes.add(hash));
    }
  }
  const files: Record<string, Uint8Array> = {};
  const assets: LookManifest['assets'] = [];
  for (const hash of hashes) {
    const asset = await database.assets.get(hash);
    if (!asset) throw new Error('A design asset is missing. Reimport it before exporting.');
    files[`assets/${hash}`] = new Uint8Array(await asset.blob.arrayBuffer());
    assets.push({ hash, type: asset.blob.type, size: asset.blob.size });
  }
  files['design.json'] = strToU8(
    JSON.stringify(
      { format: 'clacko-look', version: 1, kind, name, settings: patch, packs, assets },
      null,
      2,
    ),
  );
  return zipSync(files, { level: 1 });
}

export async function exportLook(
  settings: Preferences,
  kind: LookKind,
  name: string,
): Promise<void> {
  const archive = await buildLook(settings, kind, name);
  downloadFile(
    new Blob([new Uint8Array(archive)]),
    `${name.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}.clacko-look`,
  );
}

export async function inspectLook(file: File): Promise<LookPreview> {
  if (file.size > 80 * 1024 * 1024) throw new Error('Choose a design file smaller than 80 MB.');
  let expanded = 0;
  let entries = 0;
  const files = unzipSync(new Uint8Array(await file.arrayBuffer()), {
    filter: (entry) => {
      expanded += entry.originalSize;
      entries++;
      if (expanded > 160 * 1024 * 1024 || entries > 1000)
        throw new Error('This design archive exceeds the import limit.');
      return entry.name === 'design.json' || /^assets\/[a-f0-9]{64}$/.test(entry.name);
    },
  });
  if (!files['design.json'] || files['design.json'].length > 2 * 1024 * 1024)
    throw new Error('A valid design.json is required.');
  const manifest = JSON.parse(strFromU8(files['design.json'])) as LookManifest;
  if (
    manifest.format !== 'clacko-look' ||
    manifest.version !== 1 ||
    !['keyboard', 'theme'].includes(manifest.kind) ||
    typeof manifest.name !== 'string' ||
    !Array.isArray(manifest.assets) ||
    !Array.isArray(manifest.packs)
  )
    throw new Error('This is not a supported Clacko design.');
  // Restrict imported fields to the selected design kind before any settings are applied.
  manifest.settings = scopedSettings(
    { ...defaultPreferences('preview'), ...manifest.settings },
    manifest.kind,
  );
  const full = { ...defaultPreferences('preview'), ...manifest.settings };
  validatePreferences(full);
  const assets = [];
  for (const entry of manifest.assets) {
    if (!/^[a-f0-9]{64}$/.test(entry.hash)) throw new Error('An asset hash is invalid.');
    const bytes = files[`assets/${entry.hash}`];
    if (!bytes || bytes.length !== entry.size)
      throw new Error('An included design asset is missing.');
    const digest = await crypto.subtle.digest('SHA-256', new Uint8Array(bytes));
    const hash = [...new Uint8Array(digest)]
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('');
    if (hash !== entry.hash) throw new Error('A design asset failed its integrity check.');
    assets.push({ hash, blob: new Blob([new Uint8Array(bytes)], { type: entry.type }) });
  }
  const available = new Set(assets.map((asset) => asset.hash));
  const requireHash = (hash: string) => {
    if (!available.has(hash))
      throw new Error('This design refers to an asset it does not contain.');
  };
  appearanceAssetHashes(full).forEach(requireHash);
  for (const pack of manifest.packs) {
    const parsed = parseMechvibesConfig(JSON.parse(pack.originalConfig));
    Object.assign(pack, parsed);
    Object.values(pack.files).forEach(requireHash);
    for (const key of Object.values(pack.keys))
      for (const segment of [key.down, key.up]) {
        if (segment && !pack.files[segment.file])
          throw new Error('A sound-pack file reference is missing.');
      }
  }
  return { manifest, assets };
}

export async function applyLook(
  preview: LookPreview,
  profileId: string,
): Promise<Partial<Preferences>> {
  const ids = new Map(preview.manifest.packs.map((pack) => [pack.id, createId()]));
  await database.transaction('rw', database.assets, database.packs, async () => {
    await database.assets.bulkPut(preview.assets);
    await database.packs.bulkAdd(
      preview.manifest.packs.map((pack) => ({ ...pack, id: ids.get(pack.id)!, profileId })),
    );
  });
  const full = remapAppearancePacks(
    { ...defaultPreferences(profileId), ...preview.manifest.settings },
    ids,
  );
  return scopedSettings(full, preview.manifest.kind);
}

import { database } from './database';
import { inspectSoundPack, activateImportedPack, loadStoredPack } from './soundPackImport';

export interface OfficialPack {
  id: string;
  name: string;
  author: string;
  officialUrl: string;
  downloadUrl: string;
  directDownloadUrl: string;
  license: string;
  keyCount: number;
}

let catalogPromise: Promise<OfficialPack[]> | undefined;

export function officialMechvibesPacks(): Promise<OfficialPack[]> {
  catalogPromise ??= fetch('/mechvibes/catalog.json').then(async (response) => {
    if (!response.ok) throw new Error('The Mechvibes catalog could not be opened.');
    const catalog = await response.json();
    return catalog.packs as OfficialPack[];
  });
  return catalogPromise;
}

/** Download into the user's local profile; restricted recordings are never republished. */
export async function installOfficialPack(entry: OfficialPack, profileId: string): Promise<string> {
  let response: Response;
  try {
    response = await fetch(entry.directDownloadUrl, {
      credentials: 'omit',
      signal: AbortSignal.timeout(15000),
    });
  } catch {
    throw new Error(
      'The Mechvibes server does not allow a direct browser download here. Use Download ZIP, then Import ZIP.',
    );
  }
  if (!response.ok)
    throw new Error(
      'Direct download is unavailable. Download the official ZIP and import it below.',
    );
  const file = new File([await response.blob()], `${entry.id}.zip`, { type: 'application/zip' });
  const { pack, blobs } = await inspectSoundPack(file, profileId);
  await activateImportedPack(pack, blobs);
  return pack.id;
}

export async function loadPackById(
  id: string,
  profileId: string,
  active: () => boolean = () => true,
): Promise<void> {
  const pack = await database.packs.get(id);
  if (pack && pack.profileId === profileId) await loadStoredPack(pack, active);
}

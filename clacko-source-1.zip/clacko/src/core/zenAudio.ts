import { defaultZenSettings, type ZenSettings } from './design';

/** A small generative instrument. No recordings or melody-service requests. */
class ZenSoundscape {
  private context?: AudioContext;
  private master?: GainNode;
  private settings = defaultZenSettings();
  private timer?: ReturnType<typeof setInterval>;
  private noise?: AudioBufferSourceNode;
  private beat = 0;
  private active = false;
  private generation = 0;
  private notes = new Set<OscillatorNode>();

  configure(settings?: ZenSettings): void {
    const next = { ...defaultZenSettings(), ...settings };
    const profileChanged = this.settings.profile !== next.profile;
    this.settings = next;
    if (this.master && this.context)
      this.master.gain.setTargetAtTime(next.volume * 0.22, this.context.currentTime, 0.06);
    if (this.active && profileChanged) {
      this.stop();
      void this.start();
    }
  }

  async start(): Promise<void> {
    this.stop();
    const generation = this.generation;
    this.active = true;
    if (this.settings.profile === 'off') return;
    this.context ??= new AudioContext({ latencyHint: 'interactive' });
    await this.context.resume();
    if (!this.active || generation !== this.generation) return;
    this.master = this.context.createGain();
    this.master.gain.value = this.settings.volume * 0.22;
    this.master.connect(this.context.destination);
    this.beat = 0;
    if (this.settings.profile === 'rain' || this.settings.profile === 'spooky') this.startNoise();
    this.tick();
    this.timer = setInterval(() => this.tick(), this.settings.profile === 'pixel' ? 420 : 850);
  }

  stop(): void {
    this.generation++;
    this.active = false;
    clearInterval(this.timer);
    this.noise?.stop();
    this.noise = undefined;
    for (const note of this.notes) {
      try {
        note.stop();
      } catch {
        /* Already ended. */
      }
    }
    this.notes.clear();
    this.master?.disconnect();
    this.master = undefined;
  }

  react(code: string): void {
    if (!this.active || !this.settings.reactive || !this.context || this.settings.profile === 'off')
      return;
    const index = [...code].reduce((sum, character) => sum + character.charCodeAt(0), 0);
    this.note(index, true);
  }

  private tick(): void {
    if (this.settings.profile !== 'rain') this.note(this.beat++, false);
  }

  private note(index: number, reactive: boolean): void {
    if (!this.context || !this.master || this.notes.size > 15) return;
    const profile = this.settings.profile;
    const scale =
      profile === 'spooky'
        ? [0, 1, 3, 6, 7, 10]
        : profile === 'christmas'
          ? [0, 4, 7, 9, 12, 16, 19]
          : [0, 2, 4, 7, 9, 12];
    const base = profile === 'spooky' ? 110 : profile === 'christmas' ? 523.25 : 261.63;
    const semitone = scale[index % scale.length];
    const oscillator = this.context.createOscillator();
    const envelope = this.context.createGain();
    const now = this.context.currentTime;
    const length = profile === 'christmas' ? 1.6 : profile === 'spooky' ? 1.8 : 0.22;
    oscillator.type = profile === 'pixel' ? 'square' : profile === 'spooky' ? 'triangle' : 'sine';
    oscillator.frequency.value = base * 2 ** (semitone / 12);
    if (profile === 'christmas') oscillator.detune.value = reactive ? 4 : -3;
    envelope.gain.setValueAtTime(0, now);
    envelope.gain.linearRampToValueAtTime(reactive ? 0.4 : 0.2, now + 0.008);
    envelope.gain.exponentialRampToValueAtTime(0.0001, now + length);
    oscillator.connect(envelope);
    envelope.connect(this.master);
    this.notes.add(oscillator);
    oscillator.onended = () => {
      this.notes.delete(oscillator);
      oscillator.disconnect();
      envelope.disconnect();
    };
    oscillator.start(now);
    oscillator.stop(now + length);
  }

  private startNoise(): void {
    const context = this.context!;
    const buffer = context.createBuffer(1, context.sampleRate * 3, context.sampleRate);
    const samples = buffer.getChannelData(0);
    let previous = 0;
    for (let index = 0; index < samples.length; index++) {
      previous = (previous + (Math.random() * 2 - 1) * 0.03) / 1.03;
      samples[index] = previous * (this.settings.profile === 'spooky' ? 0.12 : 0.65);
    }
    const noise = context.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;
    noise.connect(this.master!);
    noise.start();
    this.noise = noise;
  }
}

export const zenAudio = new ZenSoundscape();

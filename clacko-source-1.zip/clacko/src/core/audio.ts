import { bundledStarterPack, starterPackId } from './starterPack';
import { database } from './database';
import { lookupSegment } from './mechvibes';
import type { Preferences, SoundPack } from './types';

interface ActiveVoice {
  source: AudioBufferSourceNode;
  gain: GainNode;
}

/** All decoding happens before activation. A keystroke only schedules a buffer. */
class KeyboardAudio {
  private context?: AudioContext;
  private master?: GainNode;
  private preferences?: Preferences;
  private activePack?: SoundPack;
  private buffers = new Map<string, AudioBuffer>();
  private voices: ActiveVoice[] = [];
  private generated = new Map<string, AudioBuffer>();
  private generation = 0;
  private overrideGeneration = 0;
  private overrideBuffers = new Map<
    string,
    { buffer: AudioBuffer; offset: number; duration: number; volume: number }
  >();

  configure(preferences: Preferences): void {
    this.preferences = preferences;
    if (this.master && this.context)
      this.master.gain.setTargetAtTime(preferences.volume * 0.55, this.context.currentTime, 0.015);
  }

  private createContext(): void {
    if (!this.context) {
      this.context = new AudioContext({ latencyHint: 'interactive' });
      this.master = this.context.createGain();
      this.master.gain.value = (this.preferences?.volume ?? 0.35) * 0.55;
      this.master.connect(this.context.destination);
    }
  }

  async unlock(): Promise<void> {
    this.createContext();
    if (this.context!.state === 'suspended') await this.context!.resume();
  }

  async preparePack(pack: SoundPack, files: Record<string, Blob>): Promise<void> {
    this.createContext();
    const generation = ++this.generation;
    const prepared = new Map<string, AudioBuffer>();
    let decodedBytes = 0;

    const audioFiles = new Set(
      Object.values(pack.keys).flatMap((key) => [key.down.file, ...(key.up ? [key.up.file] : [])]),
    );
    for (const [name, blob] of Object.entries(files)) {
      if (!audioFiles.has(name)) continue;
      let buffer: AudioBuffer;
      try {
        buffer = await this.context!.decodeAudioData(await blob.arrayBuffer());
      } catch {
        throw new Error(`Your browser could not decode ${name}. Try a WAV version of this pack.`);
      }
      decodedBytes += buffer.length * buffer.numberOfChannels * 4;
      if (decodedBytes > 96 * 1024 * 1024)
        throw new Error('This pack needs too much audio memory. Choose a smaller pack.');
      prepared.set(name, buffer);
    }
    for (const mapping of Object.values(pack.keys)) {
      for (const segment of [mapping.down, mapping.up]) {
        if (!segment) continue;
        const buffer = prepared.get(segment.file);
        if (!buffer) throw new Error(`The pack is missing ${segment.file}.`);
        if (segment.start / 1000 >= buffer.duration)
          throw new Error(`A clip starts beyond the end of ${segment.file}.`);
      }
    }
    if (generation !== this.generation) return;
    this.buffers = prepared;
    this.activePack = pack;
  }

  async prepareKeySounds(preferences: Preferences): Promise<void> {
    const generation = ++this.overrideGeneration;
    const entries = Object.entries(preferences.keyboard?.keys ?? {}).filter(([, key]) => key.sound);
    if (!entries.length) {
      this.overrideBuffers.clear();
      return;
    }
    this.createContext();
    const clips = new Map<
      string,
      { buffer: AudioBuffer; offset: number; duration: number; volume: number }
    >();
    const decoded = new Map<string, AudioBuffer>();
    let decodedBytes = 0;
    for (const [code, key] of entries) {
      if (generation !== this.overrideGeneration) return;
      const sound = key.sound!;
      let hash = sound.assetHash;
      let bundledBlob: Blob | undefined;
      let start = 0;
      let end: number | undefined;
      if (sound.packId && !hash) {
        const bundled = sound.packId === starterPackId ? await bundledStarterPack() : undefined;
        const pack = bundled?.pack ?? (await database.packs.get(sound.packId));
        if (!pack || (!bundled && pack.profileId !== preferences.profileId)) continue;
        const segment = lookupSegment(pack.keys, sound.sampleCode || code, true);
        if (!segment) continue;
        bundledBlob = bundled?.files[segment.file];
        hash = bundled ? `included:${segment.file}` : pack.files[segment.file];
        start = segment.start;
        end = segment.end;
      }
      if (!hash) continue;
      let buffer = decoded.get(hash);
      if (!buffer) {
        const asset = bundledBlob ? { blob: bundledBlob } : await database.assets.get(hash);
        if (!asset) throw new Error(`The custom sound for ${code} is missing.`);
        buffer = await this.context!.decodeAudioData(await asset.blob.arrayBuffer());
        decodedBytes += buffer.length * buffer.numberOfChannels * 4;
        if (decodedBytes > 96 * 1024 * 1024)
          throw new Error('The per-key sounds need too much memory. Use shorter clips.');
        decoded.set(hash, buffer);
      }
      const offset = start / 1000;
      const duration = Math.min((end ?? buffer.duration * 1000) / 1000, buffer.duration) - offset;
      if (duration > 0) clips.set(code, { buffer, offset, duration, volume: sound.volume });
    }
    if (generation === this.overrideGeneration) this.overrideBuffers = clips;
  }

  useGeneratedPack(): void {
    this.generation++;
    this.activePack = undefined;
    this.buffers.clear();
  }

  play(code: string, down = true): void {
    if (
      !this.preferences?.soundEnabled ||
      !this.context ||
      !this.master ||
      this.context.state !== 'running'
    )
      return;
    const procedural = this.preferences.keyboard?.keys[code]?.sound;
    if (procedural?.procedural) {
      if (down)
        this.schedule(
          this.getGeneratedSample(procedural.procedural, false),
          0,
          undefined,
          1,
          procedural.volume,
        );
      return;
    }
    const custom = this.overrideBuffers.get(code);
    if (custom) {
      if (down) this.schedule(custom.buffer, custom.offset, custom.duration, 1, custom.volume);
      return;
    }
    const imported = !['soft', 'crisp', 'deep'].includes(this.preferences.soundPackId);
    if (imported && this.activePack?.id !== this.preferences.soundPackId) return;

    if (imported && this.activePack) {
      const segment = lookupSegment(this.activePack.keys, code, down);
      if (!segment) return;
      const buffer = this.buffers.get(segment.file);
      if (!buffer) return;
      const start = segment.start / 1000;
      const end = Math.min((segment.end ?? buffer.duration * 1000) / 1000, buffer.duration);
      this.schedule(
        buffer,
        start,
        end - start,
        this.activePack.randomPitch ? 0.9 + Math.random() * 0.2 : 1,
      );
    } else if (down) {
      this.schedule(this.getGeneratedSample(this.preferences.soundPackId, code === 'Space'), 0);
    }
  }

  private getGeneratedSample(kind: string, space: boolean): AudioBuffer {
    const id = `${kind}-${space}`;
    const cached = this.generated.get(id);
    if (cached) return cached;

    const sampleRate = this.context!.sampleRate;
    const length = Math.floor(sampleRate * 0.085);
    const buffer = this.context!.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);
    const frequency =
      (kind === 'deep' || kind === 'wood'
        ? 155
        : kind === 'bell'
          ? 1100
          : kind === 'crisp' || kind === 'pixel'
            ? 900
            : 330) * (space ? 0.65 : 1);
    let seed = 417;
    for (let index = 0; index < length; index++) {
      const time = index / sampleRate;
      seed = (seed * 16807) % 2147483647;
      const noise = (seed / 2147483647 - 0.5) * (kind === 'crisp' ? 0.8 : 0.25);
      const wave = Math.sin(2 * Math.PI * frequency * time);
      const body = kind === 'pixel' ? Math.sign(wave) * 0.4 : wave * 0.65;
      const envelope = Math.exp(-time * (kind === 'deep' ? 68 : 100));
      data[index] = (body + noise) * envelope;
    }
    this.generated.set(id, buffer);
    return buffer;
  }

  private schedule(
    buffer: AudioBuffer,
    offset: number,
    duration = buffer.duration,
    playbackRate = 1,
    voiceVolume = 1,
  ): void {
    if (duration <= 0) return;
    const context = this.context!;
    const now = context.currentTime;
    if (this.voices.length >= 32) {
      const oldest = this.voices.shift()!;
      oldest.gain.gain.cancelScheduledValues(now);
      oldest.gain.gain.setTargetAtTime(0, now, 0.003);
      oldest.source.stop(now + 0.01);
    }
    const source = context.createBufferSource();
    const gain = context.createGain();
    source.buffer = buffer;
    source.playbackRate.value = playbackRate;
    const audibleDuration = duration / playbackRate;
    source.connect(gain);
    gain.connect(this.master!);
    const fade = Math.min(0.003, audibleDuration / 3);
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(voiceVolume, now + fade);
    gain.gain.setValueAtTime(voiceVolume, now + audibleDuration - fade);
    gain.gain.linearRampToValueAtTime(0, now + audibleDuration);
    const voice = { source, gain };
    this.voices.push(voice);
    source.onended = () => {
      source.disconnect();
      gain.disconnect();
      this.voices = this.voices.filter((candidate) => candidate !== voice);
    };
    source.start(now, offset, duration);
  }
}

export const keyboardAudio = new KeyboardAudio();

import type { Attempt, Flashcard, StudyMode } from './types';

/** Deterministic priorities are easy to explain, inspect, and reproduce. */
export function prioritizeCards(
  cards: Flashcard[],
  attempts: Attempt[],
  mode: StudyMode,
): Flashcard[] {
  const history = new Map<string, { reviews: number; correct: number; lastReview: number }>();
  for (const attempt of attempts) {
    if (attempt.direction !== mode) continue;
    const record = history.get(attempt.cardId) ?? { reviews: 0, correct: 0, lastReview: 0 };
    record.reviews++;
    record.correct += attempt.correct ? 1 : 0;
    record.lastReview = Math.max(record.lastReview, attempt.createdAt);
    history.set(attempt.cardId, record);
  }

  return [...cards].sort((left, right) => {
    const leftHistory = history.get(left.id);
    const rightHistory = history.get(right.id);
    const leftRate = leftHistory ? leftHistory.correct / leftHistory.reviews : -1;
    const rightRate = rightHistory ? rightHistory.correct / rightHistory.reviews : -1;

    return (
      leftRate - rightRate ||
      (leftHistory?.lastReview ?? 0) - (rightHistory?.lastReview ?? 0) ||
      left.position - right.position ||
      left.id.localeCompare(right.id)
    );
  });
}

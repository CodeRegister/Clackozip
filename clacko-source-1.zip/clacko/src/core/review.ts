import type { Flashcard } from './types';

export type ReviewRating = 'again' | 'hard' | 'good' | 'easy';
export type ReviewDirection = 'recall' | 'reverse';
export interface ReviewState {
  id: string;
  profileId: string;
  cardId: string;
  direction: ReviewDirection;
  state: 'new' | 'learning' | 'review' | 'relearning';
  introducedAt?: number;
  dueAt: number;
  intervalDays: number;
  ease: number;
  step: number;
  repetitions: number;
  lapses: number;
  updatedAt: number;
}
export interface GymRun {
  id: string;
  profileId: string;
  layout: string;
  lessonId: number;
  exercise: string;
  duration: number;
  wpm: number;
  accuracy: number;
  passed: boolean;
  characters: number;
  errors: Record<string, number>;
  createdAt: number;
}

const MINUTE = 60000;
const DAY = 24 * 60 * MINUTE;
export const reviewRatings: ReviewRating[] = ['again', 'hard', 'good', 'easy'];

export function newReviewState(
  profileId: string,
  cardId: string,
  direction: ReviewDirection,
): ReviewState {
  return {
    id: `${profileId}:${cardId}:${direction}`,
    profileId,
    cardId,
    direction,
    state: 'new',
    dueAt: 0,
    intervalDays: 0,
    ease: 2.5,
    step: 0,
    repetitions: 0,
    lapses: 0,
    updatedAt: 0,
  };
}

/** Clacko's transparent scheduler, inspired by Anki's review interaction. Not FSRS. */
export function scheduleReview(
  previous: ReviewState,
  rating: ReviewRating,
  now: number,
): ReviewState {
  const next = {
    ...previous,
    repetitions: previous.repetitions + 1,
    updatedAt: now,
    introducedAt: previous.introducedAt ?? now,
  };
  if (previous.state !== 'review') {
    if (rating === 'again') {
      next.state = previous.state === 'relearning' ? 'relearning' : 'learning';
      next.step = 0;
      next.dueAt = now + MINUTE;
    }
    if (rating === 'hard') {
      next.state = previous.state === 'relearning' ? 'relearning' : 'learning';
      next.dueAt = now + (previous.step === 0 ? 6 : 10) * MINUTE;
    }
    if (rating === 'good') {
      if (previous.step === 0 && previous.state !== 'relearning') {
        next.state = 'learning';
        next.step = 1;
        next.dueAt = now + 10 * MINUTE;
      } else {
        next.state = 'review';
        next.intervalDays = Math.max(1, previous.intervalDays);
        next.dueAt = now + next.intervalDays * DAY;
      }
    }
    if (rating === 'easy') {
      next.state = 'review';
      next.intervalDays = Math.max(4, previous.intervalDays);
      next.dueAt = now + next.intervalDays * DAY;
      next.ease = Math.min(3.5, previous.ease + 0.15);
    }
  } else if (rating === 'again') {
    next.state = 'relearning';
    next.step = 0;
    next.lapses++;
    next.intervalDays = Math.max(1, Math.floor(previous.intervalDays * 0.5));
    next.ease = Math.max(1.3, previous.ease - 0.2);
    next.dueAt = now + 10 * MINUTE;
  } else {
    const multiplier =
      rating === 'hard' ? 1.2 : rating === 'easy' ? (previous.ease + 0.15) * 1.3 : previous.ease;
    next.intervalDays = Math.min(
      3650,
      Math.max(previous.intervalDays + 1, Math.round(previous.intervalDays * multiplier)),
    );
    next.ease = Math.max(
      1.3,
      Math.min(3.5, previous.ease + (rating === 'hard' ? -0.15 : rating === 'easy' ? 0.15 : 0)),
    );
    next.dueAt = now + next.intervalDays * DAY;
  }
  return next;
}

export function intervalLabel(dueAt: number, now: number): string {
  const minutes = Math.max(1, Math.round((dueAt - now) / MINUTE));
  if (minutes < 60) return `${minutes}m`;
  if (minutes < 1440) return `${Math.round(minutes / 60)}h`;
  return `${Math.round(minutes / 1440)}d`;
}

export interface CardFilters {
  query: string;
  tag: string;
  status: 'all' | 'new' | 'due' | 'weak' | 'starred';
}
export function filterStudyCards(
  cards: Flashcard[],
  states: ReviewState[],
  filters: CardFilters,
  now = Date.now(),
): Flashcard[] {
  const query = filters.query.toLocaleLowerCase();
  const byCard = new Map<string, ReviewState[]>();
  for (const state of states) {
    const history = byCard.get(state.cardId) ?? [];
    history.push(state);
    byCard.set(state.cardId, history);
  }
  return cards.filter((card) => {
    if (card.suspended) return false;
    if (filters.tag && !card.tags.includes(filters.tag)) return false;
    if (
      query &&
      !`${card.prompt} ${card.answer} ${card.tags.join(' ')}`.toLocaleLowerCase().includes(query)
    )
      return false;
    const history = byCard.get(card.id) ?? [];
    if (filters.status === 'starred') return Boolean(card.starred);
    if (filters.status === 'new')
      return !history.length || history.every((state) => state.state === 'new');
    if (filters.status === 'due')
      return history.some((state) => state.dueAt <= now && state.state !== 'new');
    if (filters.status === 'weak')
      return history.some((state) => state.lapses > 0 || state.state === 'relearning');
    return true;
  });
}

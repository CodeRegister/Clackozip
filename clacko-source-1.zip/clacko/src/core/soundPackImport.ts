import { unzipSync } from 'fflate';
import { createId, database, saveAsset } from './database';
import { keyboardAudio } from './audio';
import { parseMechvibesConfig, safePackPath } from './mechvibes';
import type { SoundPack } from './types';
import { referencedPackIds } from './design';

/** A saved keyboard or preset must never lose a sound silently. */
export async function removeSoundPack(id: string, profileId: string): Promise<void> {
  await database.transaction(
    'rw',
    database.packs,
    database.preferences,
    database.presets,
    async () => {
      const pack = await database.packs.get(id);
      if (!pack || pack.profileId !== profileId) throw new Error('This sound pack is unavailable.');
      const settings = await database.preferences.get(profileId);
      const keyUsesPack = Object.values(settings?.keyboard?.keys ?? {}).some(
        (key) => key.sound?.packId === id,
      );
      const presets = await database.presets.where('profileId').equals(profileId).toArray();
      if (
        keyUsesPack ||
        presets.some((preset) => referencedPackIds(preset.preferences).includes(id))
      ) {
        throw new Error(
          'This pack is used by a key or saved preset. Change those assignments before removing it.',
        );
      }
      await database.packs.delete(id);
    },
  );
}

export async function inspectSoundPack(
  file: File,
  profileId: string,
): Promise<{ pack: SoundPack; blobs: Record<string, Blob> }> {
  if (file.size > 30 * 1024 * 1024) throw new Error('Choose a sound pack ZIP smaller than 30 MB.');
  let totalBytes = 0;
  let entries = 0;
  const archive = unzipSync(new Uint8Array(await file.arrayBuffer()), {
    filter: (entry) => {
      entries++;
      totalBytes += entry.originalSize;
      if (entries > 600 || totalBytes > 60 * 1024 * 1024)
        throw new Error('This archive is too large when unpacked.');
      safePackPath(entry.name.replace(/\/$/, ''));
      return !entry.name.endsWith('/');
    },
  });
  const names = Object.keys(archive);
  const normalizedNames = new Set(names.map((name) => name.toLocaleLowerCase()));
  if (normalizedNames.size !== names.length)
    throw new Error('The ZIP contains duplicate file names.');
  const configs = names.filter((name) => name === 'config.json' || name.endsWith('/config.json'));
  if (configs.length !== 1) throw new Error('The ZIP must contain exactly one config.json.');
  const configPath = configs[0];
  if (archive[configPath].byteLength > 1024 * 1024)
    throw new Error('config.json must be smaller than 1 MB.');
  const prefix = configPath.slice(0, -'config.json'.length);
  const originalConfig = new TextDecoder().decode(archive[configPath]);
  const parsed = parseMechvibesConfig(JSON.parse(originalConfig));
  const blobs: Record<string, Blob> = Object.create(null);
  for (const mapping of Object.values(parsed.keys)) {
    for (const segment of [mapping.down, mapping.up]) {
      if (!segment || blobs[segment.file]) continue;
      const bytes = archive[prefix + segment.file];
      if (!bytes) throw new Error(`The ZIP is missing ${segment.file}.`);
      blobs[segment.file] = new Blob([new Uint8Array(bytes)]);
    }
  }
  for (const name of names.filter((name) =>
    /(^|\/)(license|licence|readme)(\.[^/]*)?$/i.test(name),
  )) {
    if (archive[name].byteLength < 256 * 1024)
      blobs[name.startsWith(prefix) ? name.slice(prefix.length) : name] = new Blob(
        [new Uint8Array(archive[name])],
        { type: 'text/plain' },
      );
  }
  return {
    pack: { id: createId(), profileId, ...parsed, originalConfig, files: {} },
    blobs,
  };
}

export async function activateImportedPack(
  pack: SoundPack,
  blobs: Record<string, Blob>,
): Promise<void> {
  await keyboardAudio.preparePack(pack, blobs);
  for (const [name, blob] of Object.entries(blobs)) pack.files[name] = await saveAsset(blob);
  await database.packs.put(pack);
}

export async function loadStoredPack(
  pack: SoundPack,
  shouldContinue: () => boolean = () => true,
): Promise<void> {
  const files: Record<string, Blob> = Object.create(null);
  for (const [name, hash] of Object.entries(pack.files)) {
    const asset = await database.assets.get(hash);
    if (!asset) throw new Error(`The saved pack is missing ${name}. Reimport the original ZIP.`);
    files[name] = asset.blob;
  }
  if (shouldContinue()) await keyboardAudio.preparePack(pack, files);
}

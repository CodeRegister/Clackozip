import { parseMechvibesConfig } from './mechvibes';
import type { SoundPack } from './types';

export const starterPackId = 'bundled-cherry-brown';
let pending: Promise<{ pack: SoundPack; files: Record<string, Blob> }> | undefined;

/** App assets are shipped and precached with Clacko, including in the source ZIP. */
export function bundledStarterPack() {
  pending ??= (async () => {
    const response = await fetch('/starter-pack/config.json');
    if (!response.ok) throw new Error('The included Cherry MX Brown pack could not be opened.');
    const config = await response.json();
    const parsed = parseMechvibesConfig(config);
    const recording = await fetch('/starter-pack/cherry-brown.wav');
    if (!recording.ok) throw new Error('The included keyboard recording is unavailable.');
    const pack: SoundPack = {
      ...parsed,
      id: starterPackId,
      profileId: '',
      files: {},
      originalConfig: JSON.stringify(config),
      warnings: [],
    };
    return { pack, files: { 'cherry-brown.wav': await recording.blob() } };
  })().catch((error) => {
    pending = undefined;
    throw error;
  });
  return pending;
}

let greeting: HTMLAudioElement | undefined;
export function sayClacko(volume: number) {
  greeting ??= new Audio('/starter-pack/clacko.wav');
  greeting.volume = Math.min(1, volume);
  greeting.currentTime = 0;
  void greeting.play().catch(() => {});
}

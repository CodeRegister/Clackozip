/**
 * Applicable parsing and event lookup logic ported from Mechvibes 3.
 * Copyright (c) 2026 Hải Nguyễn. MIT; see licenses/mechvibes-MIT.txt.
 * Commit: 56d7135bcdf6ceb7fe2f4e06f8ca0903277a9e68.
 * Sources: soundpack_validator.rs, config_converter.rs, audio/engine.rs.
 * Browser adaptation: files remain separate; no native filesystem or rodio.
 */
import { legacyKeyCodes } from './legacyKeyCodes';
import type { PackKey, SoundSegment } from './types';

type JsonObject = Record<string, unknown>;

function isObject(value: unknown): value is JsonObject {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

export function safePackPath(path: string): string {
  const normalized = path.replace(/\\/g, '/').replace(/^\.\//, '');
  if (
    !normalized ||
    normalized.startsWith('/') ||
    normalized.includes(':') ||
    normalized.split('/').some((part) => part === '..' || part === '')
  ) {
    throw new Error(`Unsafe file path: ${path}`);
  }
  return normalized;
}

function parseSegment(value: unknown, file: string): SoundSegment {
  if (!Array.isArray(value) || value.length !== 2)
    throw new Error('A sound segment needs a start and an end.');
  const [start, end] = value;
  if (
    typeof start !== 'number' ||
    typeof end !== 'number' ||
    !Number.isFinite(start) ||
    !Number.isFinite(end) ||
    start < 0 ||
    end <= start
  ) {
    throw new Error('Sound timings must be finite, positive ranges.');
  }
  return { file, start, end };
}

export interface ParsedPack {
  name: string;
  author: string;
  keys: Record<string, PackKey>;
  warnings: string[];
  recommendedVolume: number;
  randomPitch: boolean;
}

export function parseMechvibesConfig(value: unknown): ParsedPack {
  if (!isObject(value)) throw new Error('The pack configuration must be a JSON object.');
  const version = value.config_version === undefined ? undefined : Number(value.config_version);
  if (version !== undefined && version !== 1 && version !== 2)
    throw new Error('This pack uses an unsupported configuration version.');
  if (typeof value.name !== 'string' || !value.name.trim())
    throw new Error('The pack needs a name.');
  if (value.soundpack_type === 'Mouse')
    throw new Error('Mouse packs are not supported by this keyboard studio.');

  const legacy =
    version === 1 ||
    (value.defines !== undefined &&
      value.sound !== undefined &&
      value.definitions === undefined &&
      value.defs === undefined);
  if (!legacy && typeof (value.author ?? value.m_author) !== 'string')
    throw new Error('The V2 pack needs an author.');
  const definitions = legacy ? value.defines : (value.definitions ?? value.defs);
  if (!isObject(definitions)) throw new Error('No key definitions were found in config.json.');

  const keys: Record<string, PackKey> = Object.create(null);
  const warnings: string[] = [];
  const method = String(
    legacy
      ? (value.key_define_type ?? value.method ?? 'single')
      : (value.definition_method ?? 'single'),
  );
  if (method !== 'single' && method !== 'multi')
    throw new Error(`Unsupported definition method: ${method}`);
  const defaultFile =
    typeof (legacy ? value.sound : value.audio_file) === 'string'
      ? safePackPath(String(legacy ? value.sound : value.audio_file))
      : '';

  for (const [rawCode, definition] of Object.entries(definitions)) {
    const code = legacy ? legacyKeyCodes[Number(rawCode)] : rawCode;
    if (!code) {
      warnings.push(`Unknown legacy key ${rawCode} was skipped.`);
      continue;
    }

    if (legacy && method === 'multi') {
      if (typeof definition !== 'string') throw new Error(`The file for ${code} is invalid.`);
      keys[code] = { down: { file: safePackPath(definition), start: 0 } };
      continue;
    }

    if (legacy) {
      if (!defaultFile || !Array.isArray(definition) || definition.length < 2)
        throw new Error(`Invalid classic timing for ${code}.`);
      const [start, duration] = definition;
      if (typeof start !== 'number' || typeof duration !== 'number')
        throw new Error(`Invalid classic timing for ${code}.`);
      keys[code] = { down: parseSegment([start, start + duration], defaultFile) };
      continue;
    }

    const keyObject = isObject(definition) ? definition : undefined;
    const ownFile = keyObject?.audio_file;
    const file = typeof ownFile === 'string' && ownFile ? safePackPath(ownFile) : defaultFile;
    if (!file) throw new Error(`No audio file was specified for ${code}.`);
    const timing = keyObject?.timing ?? (Array.isArray(definition) ? definition : undefined);

    if (timing === undefined && method === 'multi') {
      keys[code] = { down: { file, start: 0 } };
      continue;
    }
    if (!Array.isArray(timing)) throw new Error(`Invalid timing for ${code}.`);
    if (timing.length !== 1 && timing.length !== 2) {
      warnings.push(
        `${code} has ${timing.length} segments and remains silent, matching Mechvibes.`,
      );
      continue;
    }
    keys[code] = {
      down: parseSegment(timing[0], file),
      up: timing.length === 2 ? parseSegment(timing[1], file) : undefined,
    };
  }

  if (!Object.keys(keys).length) throw new Error('This pack has no playable keyboard mappings.');
  const options = isObject(value.options) ? value.options : {};
  const recommendedVolume =
    typeof options.recommended_volume === 'number' && Number.isFinite(options.recommended_volume)
      ? Math.max(0, Math.min(2, options.recommended_volume))
      : 1;
  return {
    name: value.name.trim(),
    author: String(value.author ?? value.m_author ?? 'Unknown author'),
    keys,
    warnings,
    recommendedVolume,
    randomPitch: options.random_pitch === true,
  };
}

/** Port of lookup_timing: one clip means press only; two mean press and release. */
export function lookupSegment(
  keys: Record<string, PackKey>,
  code: string,
  down: boolean,
): SoundSegment | undefined {
  return down ? keys[code]?.down : keys[code]?.up;
}

/** Port of debounce_press, with browser blur handled by clearing the set. */
export function debouncePress(pressed: Set<string>, code: string, down: boolean): boolean {
  if (pressed.has(code) === down) return false;
  if (down) pressed.add(code);
  else pressed.delete(code);
  return true;
}

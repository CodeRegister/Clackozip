import { strFromU8, strToU8, unzipSync, zipSync } from 'fflate';
import { createId, database, defaultPreferences } from './database';
import { appearanceAssetHashes, remapAppearancePacks } from './design';
import { allPhysicalKeys, keyboardLayouts, keyboardModels } from './keyboards';
import type { ReviewState, GymRun } from './review';
import { parseMechvibesConfig } from './mechvibes';
import type {
  AppearancePreset,
  Attempt,
  Flashcard,
  Preferences,
  Profile,
  SoundPack,
  StudySession,
  StudySet,
} from './types';

export function downloadFile(blob: Blob, name: string): void {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

interface ProfileBackup {
  format: 'clacko';
  version: 1;
  profile: Profile;
  preferences: Preferences;
  sets: StudySet[];
  cards: Flashcard[];
  presets: AppearancePreset[];
  packs: SoundPack[];
  sessions: StudySession[];
  attempts: Attempt[];
  reviews?: ReviewState[];
  gymRuns?: GymRun[];
  writing: string;
  assets: Array<{ hash: string; type: string; size: number }>;
}

export async function buildProfileBackup(
  profileId: string,
  preferences: Preferences,
): Promise<Uint8Array> {
  const snapshot = await database.transaction('r', database.tables, async () => {
    const profile = await database.profiles.get(profileId);
    if (!profile) throw new Error('This profile no longer exists.');
    const sets = await database.sets.where('profileId').equals(profileId).toArray();
    const cards = await database.cards.where('profileId').equals(profileId).toArray();
    const presets = await database.presets.where('profileId').equals(profileId).toArray();
    const packs = await database.packs.where('profileId').equals(profileId).toArray();
    const sessions = await database.sessions.where('profileId').equals(profileId).toArray();
    const attempts = await database.attempts.where('profileId').equals(profileId).toArray();
    const reviews = await database.reviews.where('profileId').equals(profileId).toArray();
    const gymRuns = await database.gymRuns.where('profileId').equals(profileId).toArray();
    const writing = (await database.writings.get(profileId))?.text ?? '';
    const hashes = new Set<string>();
    const add = (hash?: string) => {
      if (hash) hashes.add(hash);
    };
    cards.forEach((card) => {
      add(card.frontImage);
      add(card.backImage);
    });
    appearanceAssetHashes(preferences).forEach(add);
    presets.forEach((preset) => appearanceAssetHashes(preset.preferences).forEach(add));
    packs.forEach((pack) => Object.values(pack.files).forEach(add));
    const assets = await database.assets.bulkGet([...hashes]);
    if (assets.some((asset) => !asset))
      throw new Error('An image or sound file is missing. Please repair it before exporting.');
    return {
      profile,
      sets,
      cards,
      presets,
      packs,
      sessions,
      attempts,
      reviews,
      gymRuns,
      writing,
      assets,
    };
  });

  const files: Record<string, Uint8Array> = {};
  const assetMetadata = [];
  for (const asset of snapshot.assets) {
    if (!asset) continue;
    files[`assets/${asset.hash}`] = new Uint8Array(await asset.blob.arrayBuffer());
    assetMetadata.push({ hash: asset.hash, type: asset.blob.type, size: asset.blob.size });
  }
  const manifest: ProfileBackup = {
    ...snapshot,
    preferences,
    assets: assetMetadata,
    format: 'clacko',
    version: 1,
  };
  files['manifest.json'] = strToU8(JSON.stringify(manifest, null, 2));
  return zipSync(files, { level: 1 });
}

export async function exportProfile(profileId: string, preferences: Preferences): Promise<void> {
  const archive = await buildProfileBackup(profileId, preferences);
  downloadFile(
    new Blob([new Uint8Array(archive)], { type: 'application/zip' }),
    'clacko-profile.clacko',
  );
}

function validString(value: unknown): value is string {
  return typeof value === 'string';
}

export function validatePreferences(settings: Preferences): void {
  if (!settings || typeof settings !== 'object')
    throw new Error('Appearance settings are missing.');
  const enums: Array<[unknown, string[]]> = [
    [settings.theme, ['paper', 'midnight', 'matcha']],
    [settings.fontFamily, ['mono', 'sans', 'system', 'custom']],
    [settings.caretStyle, ['line', 'block', 'underline']],
    [settings.background, ['plain', 'dots', 'grid']],
  ];
  if (enums.some(([value, allowed]) => !allowed.includes(String(value))))
    throw new Error('An appearance option is unsupported.');
  if (![settings.keyColor, settings.accentColor].every((value) => /^#[a-f0-9]{6}$/i.test(value)))
    throw new Error('An appearance color is invalid.');
  if (
    settings.customTheme &&
    !Object.values(settings.customTheme).every(
      (color) => typeof color === 'string' && /^#[a-f0-9]{6}$/i.test(color),
    )
  )
    throw new Error('A custom theme color is invalid.');
  if (settings.keyboard) {
    const keyboard = settings.keyboard;
    if (
      !keyboard.keys ||
      Object.keys(keyboard.keys).length > 128 ||
      !/^#[a-f0-9]{6}$/i.test(keyboard.caseColor) ||
      !Number.isFinite(keyboard.imageOpacity) ||
      keyboard.imageOpacity < 0 ||
      keyboard.imageOpacity > 1
    )
      throw new Error('The keyboard design is invalid.');
    const options: Array<[unknown, string[]]> = [
      [keyboard.model, keyboardModels.map((model) => model.id)],
      [keyboard.layout, keyboardLayouts.map((layout) => layout.id)],
      [keyboard.material, ['plastic', 'aluminum', 'wood', 'glass']],
      [keyboard.keyMaterial, ['abs', 'pbt', 'rubber']],
      [keyboard.effect, ['press', 'glow', 'ripple', 'bounce', 'none']],
    ];
    if (options.some(([value, allowed]) => value !== undefined && !allowed.includes(String(value))))
      throw new Error('A keyboard option is unsupported.');
    if (
      keyboard.effectIntensity !== undefined &&
      (!Number.isFinite(keyboard.effectIntensity) ||
        keyboard.effectIntensity < 0 ||
        keyboard.effectIntensity > 2)
    )
      throw new Error('Effect intensity is invalid.');
    if (
      keyboard.effectDuration !== undefined &&
      (!Number.isFinite(keyboard.effectDuration) ||
        keyboard.effectDuration < 80 ||
        keyboard.effectDuration > 1000)
    )
      throw new Error('Effect duration is invalid.');
    if (keyboard.customRows) {
      if (
        !Array.isArray(keyboard.customRows) ||
        !keyboard.customRows.length ||
        keyboard.customRows.length > 8 ||
        keyboard.customRows.some(
          (row) =>
            !Array.isArray(row) ||
            !row.length ||
            row.length > 24 ||
            row.some((code) => !allPhysicalKeys.some((key) => key.code === code)),
        ) ||
        new Set(keyboard.customRows.flat()).size !== keyboard.customRows.flat().length
      )
        throw new Error('Custom keyboard rows are invalid.');
    }
    if (
      keyboard.customWidths &&
      Object.values(keyboard.customWidths).some(
        (width) => !Number.isFinite(width) || width < 0.5 || width > 8,
      )
    )
      throw new Error('Custom key widths are invalid.');
    for (const [code, key] of Object.entries(keyboard.keys)) {
      if (
        !/^[A-Za-z][A-Za-z0-9]{0,30}$/.test(code) ||
        (key.label && (typeof key.label !== 'string' || key.label.length > 12))
      )
        throw new Error('A key label or identifier is invalid.');
      if (key.effect && !['press', 'glow', 'ripple', 'bounce', 'none'].includes(key.effect))
        throw new Error('A key effect is invalid.');
      if (key.sound?.procedural && !['pixel', 'bell', 'wood'].includes(key.sound.procedural))
        throw new Error('A procedural key sound is invalid.');
      for (const color of [key.color, key.legendColor])
        if (color && !/^#[a-f0-9]{6}$/i.test(color)) throw new Error('A key color is invalid.');
      if (
        key.sound &&
        (!Number.isFinite(key.sound.volume) || key.sound.volume < 0 || key.sound.volume > 1)
      )
        throw new Error('A key sound volume is invalid.');
    }
  }
  if (
    settings.zen &&
    (!Array.isArray(settings.zen.playlist) ||
      settings.zen.playlist.length > 1000 ||
      !['off', 'pixel', 'christmas', 'spooky', 'rain'].includes(settings.zen.profile))
  )
    throw new Error('The Zen sound profile is invalid.');
  if (
    settings.reviewLimits &&
    (!Number.isInteger(settings.reviewLimits.newCards) ||
      settings.reviewLimits.newCards < 0 ||
      settings.reviewLimits.newCards > 1000 ||
      !Number.isInteger(settings.reviewLimits.reviews) ||
      settings.reviewLimits.reviews < 0 ||
      settings.reviewLimits.reviews > 5000)
  )
    throw new Error('Review limits are invalid.');
  const ranges = [
    [settings.keyRadius, 2, 18],
    [settings.keyboardSize, 65, 100],
    [settings.volume, 0, 1],
    [settings.fontSize, 18, 36],
    [settings.backgroundDim, 35, 95],
  ];
  if (ranges.some(([value, min, max]) => !Number.isFinite(value) || value < min || value > max))
    throw new Error('An appearance value is out of range.');
  if (
    ![settings.showKeyboard, settings.soundEnabled, settings.motion].every(
      (value) => typeof value === 'boolean',
    )
  )
    throw new Error('An appearance switch is invalid.');
}

export async function inspectBackup(
  file: File,
): Promise<{ manifest: ProfileBackup; assets: Array<{ hash: string; blob: Blob }> }> {
  if (file.size > 80 * 1024 * 1024)
    throw new Error('This backup is larger than the current 80 MB import limit.');
  let expandedBytes = 0;
  let entryCount = 0;
  const archive = unzipSync(new Uint8Array(await file.arrayBuffer()), {
    filter: (entry) => {
      expandedBytes += entry.originalSize;
      entryCount++;
      if (expandedBytes > 160 * 1024 * 1024 || entryCount > 5000)
        throw new Error('The expanded backup exceeds the safe import limit.');
      return entry.name === 'manifest.json' || /^assets\/[a-f0-9]{64}$/.test(entry.name);
    },
  });
  if (!archive['manifest.json']) throw new Error('This is not a Clacko backup.');
  if (archive['manifest.json'].byteLength > 12 * 1024 * 1024)
    throw new Error('The backup manifest is too large.');
  const manifest = JSON.parse(strFromU8(archive['manifest.json'])) as ProfileBackup;
  if (manifest.format !== 'clacko' || manifest.version !== 1)
    throw new Error('This backup uses an unsupported format or version.');
  if (!manifest.profile || !validString(manifest.profile.name) || !manifest.preferences)
    throw new Error('The backup profile is incomplete.');
  for (const field of [
    'sets',
    'cards',
    'presets',
    'packs',
    'sessions',
    'attempts',
    'assets',
  ] as const) {
    if (!Array.isArray(manifest[field])) throw new Error(`The backup is missing ${field}.`);
  }
  validatePreferences(manifest.preferences);
  for (const preset of manifest.presets) {
    if (!validString(preset.id) || !validString(preset.name))
      throw new Error('An appearance preset is invalid.');
    validatePreferences(preset.preferences);
  }
  const knownModes = new Set(['zen', 'remix', 'recall', 'reverse', 'mystery', 'review']);
  for (const session of manifest.sessions) {
    if (
      !validString(session.id) ||
      !knownModes.has(session.mode) ||
      !Array.isArray(session.setIds) ||
      !session.setIds.every(validString) ||
      !Number.isFinite(session.startedAt) ||
      !Number.isFinite(session.duration) ||
      session.duration < 0 ||
      !Number.isFinite(session.cardsStudied) ||
      !Number.isFinite(session.correct)
    ) {
      throw new Error('A study session is invalid.');
    }
  }
  for (const pack of manifest.packs) {
    if (
      !validString(pack.id) ||
      !validString(pack.originalConfig) ||
      !pack.files ||
      typeof pack.files !== 'object'
    )
      throw new Error('A sound pack is invalid.');
    const parsed = parseMechvibesConfig(JSON.parse(pack.originalConfig));
    pack.keys = parsed.keys;
    pack.name = parsed.name;
    pack.author = parsed.author;
    pack.recommendedVolume = parsed.recommendedVolume;
    pack.randomPitch = parsed.randomPitch;
    for (const key of Object.values(parsed.keys)) {
      for (const segment of [key.down, key.up]) {
        if (segment && !validString(pack.files[segment.file]))
          throw new Error('A sound pack audio reference is missing.');
      }
    }
  }
  const setIds = new Set(manifest.sets.map((set) => set.id));
  const cardIds = new Set(manifest.cards.map((card) => card.id));
  const sessionIds = new Set(manifest.sessions.map((session) => session.id));
  if (
    setIds.size !== manifest.sets.length ||
    cardIds.size !== manifest.cards.length ||
    sessionIds.size !== manifest.sessions.length
  )
    throw new Error('The backup contains duplicate record identifiers.');
  if (manifest.sets.some((set) => !validString(set.id) || !validString(set.title)))
    throw new Error('A study set is invalid.');
  if (
    manifest.cards.some(
      (card) =>
        !setIds.has(card.setId) ||
        !validString(card.prompt) ||
        !validString(card.answer) ||
        !Array.isArray(card.tags) ||
        !card.tags.every(validString) ||
        !Number.isFinite(card.position),
    )
  )
    throw new Error('A flashcard or its set reference is invalid.');
  if (
    manifest.attempts.some(
      (attempt) =>
        !sessionIds.has(attempt.sessionId) ||
        !validString(attempt.cardId) ||
        typeof attempt.correct !== 'boolean' ||
        !Number.isFinite(attempt.createdAt),
    )
  )
    throw new Error('A review attempt has an invalid session reference.');
  if (manifest.reviews !== undefined && !Array.isArray(manifest.reviews))
    throw new Error('Review scheduling data is invalid.');
  if (manifest.gymRuns !== undefined && !Array.isArray(manifest.gymRuns))
    throw new Error('Gym progress is invalid.');
  const reviewKeys = new Set<string>();
  for (const state of manifest.reviews ?? []) {
    const key = `${state.cardId}:${state.direction}`;
    if (
      !validString(state.id) ||
      !validString(state.cardId) ||
      !['recall', 'reverse'].includes(state.direction) ||
      !['new', 'learning', 'review', 'relearning'].includes(state.state) ||
      [
        state.dueAt,
        state.intervalDays,
        state.ease,
        state.step,
        state.repetitions,
        state.lapses,
        state.updatedAt,
      ].some((number) => !Number.isFinite(number) || number < 0) ||
      state.ease > 4 ||
      state.intervalDays > 3650 ||
      reviewKeys.has(key)
    )
      throw new Error('A card schedule is invalid or duplicated.');
    reviewKeys.add(key);
  }
  for (const run of manifest.gymRuns ?? []) {
    if (
      !validString(run.id) ||
      !keyboardLayouts.some((layout) => layout.id === run.layout) ||
      !Number.isInteger(run.lessonId) ||
      run.lessonId < 1 ||
      run.lessonId > 15 ||
      !['keys', 'words', 'text', 'weak'].includes(run.exercise) ||
      [run.duration, run.wpm, run.accuracy, run.characters, run.createdAt].some(
        (number) => !Number.isFinite(number) || number < 0,
      ) ||
      run.accuracy > 100 ||
      typeof run.passed !== 'boolean' ||
      !run.errors ||
      typeof run.errors !== 'object' ||
      Object.values(run.errors).some((number) => !Number.isInteger(number) || number < 0)
    )
      throw new Error('A gym result is invalid.');
  }
  const assets = [];
  for (const metadata of manifest.assets) {
    if (!/^[a-f0-9]{64}$/.test(metadata.hash)) throw new Error('An asset identifier is invalid.');
    const bytes = archive[`assets/${metadata.hash}`];
    if (!bytes || bytes.byteLength !== metadata.size)
      throw new Error('An image or audio file is missing or incomplete.');
    const digest = await crypto.subtle.digest('SHA-256', new Uint8Array(bytes));
    const actualHash = Array.from(new Uint8Array(digest), (byte) =>
      byte.toString(16).padStart(2, '0'),
    ).join('');
    if (actualHash !== metadata.hash)
      throw new Error('An image or audio file did not pass its integrity check.');
    assets.push({
      hash: metadata.hash,
      blob: new Blob([new Uint8Array(bytes)], { type: metadata.type }),
    });
  }
  const available = new Set(assets.map((asset) => asset.hash));
  const requireAsset = (hash?: string) => {
    if (hash && !available.has(hash))
      throw new Error('The backup refers to an asset it does not include.');
  };
  manifest.cards.forEach((card) => {
    requireAsset(card.frontImage);
    requireAsset(card.backImage);
  });
  appearanceAssetHashes(manifest.preferences).forEach(requireAsset);
  manifest.presets.forEach((preset) =>
    appearanceAssetHashes(preset.preferences).forEach(requireAsset),
  );
  manifest.packs.forEach((pack) => Object.values(pack.files).forEach(requireAsset));
  return { manifest, assets };
}

export async function restoreBackup(
  backup: Awaited<ReturnType<typeof inspectBackup>>,
): Promise<string> {
  const { manifest, assets } = backup;
  const profileId = createId();
  const mapIds = <T extends { id: string }>(items: T[]) =>
    new Map(items.map((item) => [item.id, createId()]));
  const setIds = mapIds(manifest.sets);
  const cardIds = mapIds(manifest.cards);
  const packIds = mapIds(manifest.packs);
  const sessionIds = mapIds(manifest.sessions);
  const restoredPreferences = (settings: Preferences): Preferences =>
    remapAppearancePacks(
      {
        ...defaultPreferences(profileId),
        ...settings,
        profileId,
        soundPackId:
          packIds.get(settings.soundPackId) ??
          (['soft', 'crisp', 'deep', 'bundled-cherry-brown'].includes(settings.soundPackId)
            ? settings.soundPackId
            : 'bundled-cherry-brown'),
      },
      packIds,
    );

  await database.transaction('rw', database.tables, async () => {
    await database.profiles.add({
      id: profileId,
      name: `${manifest.profile.name} (restored)`,
      createdAt: Date.now(),
    });
    await database.preferences.add(restoredPreferences(manifest.preferences));
    await database.sets.bulkAdd(
      manifest.sets.map((set) => ({ ...set, id: setIds.get(set.id)!, profileId })),
    );
    await database.cards.bulkAdd(
      manifest.cards.map((card) => ({
        ...card,
        id: cardIds.get(card.id)!,
        setId: setIds.get(card.setId)!,
        profileId,
      })),
    );
    await database.presets.bulkAdd(
      manifest.presets.map((preset) => ({
        ...preset,
        id: createId(),
        profileId,
        preferences: restoredPreferences(preset.preferences),
      })),
    );
    await database.packs.bulkAdd(
      manifest.packs.map((pack) => ({ ...pack, id: packIds.get(pack.id)!, profileId })),
    );
    await database.sessions.bulkAdd(
      manifest.sessions.map((session) => ({
        ...session,
        id: sessionIds.get(session.id)!,
        setIds: session.setIds
          .map((id) => setIds.get(id))
          .filter((id): id is string => Boolean(id)),
        profileId,
      })),
    );
    await database.attempts.bulkAdd(
      manifest.attempts.map((attempt) => ({
        ...attempt,
        id: createId(),
        cardId: cardIds.get(attempt.cardId) ?? attempt.cardId,
        sessionId: sessionIds.get(attempt.sessionId)!,
        profileId,
      })),
    );
    await database.reviews.bulkAdd(
      (manifest.reviews ?? [])
        .filter((state) => cardIds.has(state.cardId))
        .map((state) => ({
          ...state,
          id: `${profileId}:${cardIds.get(state.cardId)!}:${state.direction}`,
          cardId: cardIds.get(state.cardId)!,
          profileId,
        })),
    );
    await database.gymRuns.bulkAdd(
      (manifest.gymRuns ?? []).map((run) => ({ ...run, id: createId(), profileId })),
    );
    await database.assets.bulkPut(assets);
    if (manifest.writing) await database.writings.put({ profileId, text: manifest.writing });
  });
  return profileId;
}

/** Two-column CSV/TSV parser. Quoted delimiters, escaped quotes, and newlines are preserved. */
export function parseCards(text: string, delimiter = '\t'): Array<[string, string]> {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let quoted = false;
  const normalized = text.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
  for (let index = 0; index < normalized.length; index++) {
    const character = normalized[index];
    if (character === '"') {
      if (quoted && normalized[index + 1] === '"') {
        field += '"';
        index++;
      } else if (quoted || field === '') quoted = !quoted;
      else field += character;
    } else if (!quoted && character === delimiter) {
      row.push(field);
      field = '';
    } else if (!quoted && character === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else field += character;
  }
  if (quoted) throw new Error('A quoted field is missing its closing quote.');
  if (field || row.length) {
    row.push(field);
    rows.push(row);
  }
  const nonempty = rows.filter((item) => item.some((value) => value.trim()));
  if (nonempty.some((item) => item.length !== 2 || !item[0].trim() || !item[1].trim()))
    throw new Error('Each row needs exactly two nonempty columns: prompt and answer.');
  return nonempty.map((item) => [item[0].trim(), item[1].trim()]);
}

import { appearanceAssetHashes, defaultKeyboardDesign, defaultZenSettings } from './design';
import type { ReviewState, GymRun } from './review';
import Dexie, { type EntityTable } from 'dexie';
import type {
  AppearancePreset,
  Attempt,
  Flashcard,
  MediaAsset,
  Preferences,
  Profile,
  SessionDraft,
  SoundPack,
  StudySession,
  StudySet,
} from './types';

class ClackoDatabase extends Dexie {
  reviews!: EntityTable<ReviewState, 'id'>;
  gymRuns!: EntityTable<GymRun, 'id'>;
  profiles!: EntityTable<Profile, 'id'>;
  sets!: EntityTable<StudySet, 'id'>;
  cards!: EntityTable<Flashcard, 'id'>;
  preferences!: EntityTable<Preferences, 'profileId'>;
  presets!: EntityTable<AppearancePreset, 'id'>;
  assets!: EntityTable<MediaAsset, 'hash'>;
  packs!: EntityTable<SoundPack, 'id'>;
  sessions!: EntityTable<StudySession, 'id'>;
  attempts!: EntityTable<Attempt, 'id'>;
  drafts!: EntityTable<SessionDraft, 'profileId'>;
  writings!: EntityTable<{ profileId: string; text: string }, 'profileId'>;

  constructor() {
    super('clacko');
    this.version(1).stores({
      profiles: 'id',
      sets: 'id, profileId',
      cards: 'id, profileId, [profileId+setId]',
      preferences: 'profileId',
      presets: 'id, profileId',
      assets: 'hash',
      packs: 'id, profileId',
      sessions: 'id, profileId',
      attempts: 'id, profileId, [profileId+cardId]',
      drafts: 'profileId',
      writings: 'profileId',
    });
    this.version(2).stores({
      reviews: 'id, profileId, [profileId+cardId]',
      gymRuns: 'id, profileId, [profileId+layout]',
    });
  }
}

export const database = new ClackoDatabase();
export const createId = (): string => crypto.randomUUID();

export function defaultPreferences(profileId: string): Preferences {
  return {
    profileId,
    keyboard: defaultKeyboardDesign(),
    zen: defaultZenSettings(),
    theme: 'paper',
    keyColor: '#fbfaf7',
    accentColor: '#fe8b19',
    keyRadius: 9,
    keyboardSize: 100,
    showKeyboard: true,
    soundEnabled: true,
    soundPackId: 'bundled-cherry-brown',
    volume: 0.65,
    homepageGreeting: true,
    proceduralScope: 'zen',
    fontSize: 25,
    fontFamily: 'system',
    caretStyle: 'line',
    smoothCaret: true,
    background: 'plain',
    backgroundDim: 65,
    motion: true,
  };
}

const starterSets: Array<{
  title: string;
  description: string;
  color: StudySet['color'];
  cards: Array<[string, string]>;
}> = [
  {
    title: 'Small steps, big ideas',
    description: 'A little inspiration for your next study break.',
    color: 'sand',
    cards: [
      ['What makes progress possible?', 'Small steps, repeated often.'],
      ['What is active recall?', 'Remembering information without looking at your notes.'],
      ['What is spaced repetition?', 'Reviewing information over increasing intervals.'],
      ['What helps a new habit stick?', 'A simple action and a consistent cue.'],
      ['What should you do after a mistake?', 'Notice it, learn from it, and try again.'],
      ['What is the best time to begin?', 'A little bit today is a good start.'],
    ],
  },
  {
    title: 'The web, simply',
    description: 'Get comfortable with the building blocks of the web.',
    color: 'sage',
    cards: [
      ['What does HTML describe?', 'The structure and meaning of a web page.'],
      ['What does CSS control?', 'The appearance and layout of a web page.'],
      ['What does JavaScript add?', 'Behavior and interaction.'],
      ['What is a variable?', 'A named place to store a value.'],
      ['What is a function?', 'A reusable block of instructions.'],
      ['What is an array?', 'An ordered collection of values.'],
      ['What is an event?', 'Something that happens, such as a key press or a click.'],
      [
        'What is an offline-first app?',
        'An application designed to work without a network connection.',
      ],
    ],
  },
  {
    title: 'Stay a step ahead',
    description: 'Everyday information security, one card at a time.',
    color: 'lavender',
    cards: [
      ['What is phishing?', 'A deceptive attempt to steal sensitive information.'],
      ['What is authentication?', 'Verifying that someone is who they claim to be.'],
      [
        'What is multi-factor authentication?',
        'Using more than one kind of proof to verify identity.',
      ],
      ['What is encryption?', 'Transforming readable data into a protected form.'],
      ['What is a backup?', 'A separate copy of data that can be restored.'],
      ['What should you check before opening a link?', 'Check the sender, domain, and context.'],
    ],
  },
];

export async function initializeDatabase(): Promise<void> {
  await database.transaction(
    'rw',
    [database.profiles, database.preferences, database.sets, database.cards],
    async () => {
      if (await database.profiles.count()) return;

      const profileId = createId();
      await database.profiles.add({
        id: profileId,
        name: 'My little corner',
        createdAt: Date.now(),
      });
      await database.preferences.add(defaultPreferences(profileId));

      for (const starter of starterSets) {
        const setId = createId();
        await database.sets.add({
          id: setId,
          profileId,
          title: starter.title,
          description: starter.description,
          color: starter.color,
          updatedAt: Date.now(),
        });
        await database.cards.bulkAdd(
          starter.cards.map(([prompt, answer], position) => ({
            id: createId(),
            profileId,
            setId,
            prompt,
            answer,
            tags: [],
            position,
          })),
        );
      }
    },
  );
}

export async function createProfile(name: string): Promise<string> {
  const id = createId();
  await database.transaction('rw', database.profiles, database.preferences, async () => {
    await database.profiles.add({ id, name: name.trim(), createdAt: Date.now() });
    await database.preferences.add(defaultPreferences(id));
  });
  return id;
}

/** Hash the original bytes, so backups preserve images and pack files exactly. */
export async function saveAsset(blob: Blob): Promise<string> {
  const bytes = await blob.arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  const hash = Array.from(new Uint8Array(digest), (byte) =>
    byte.toString(16).padStart(2, '0'),
  ).join('');
  await database.assets.put({ hash, blob });
  return hash;
}

/** References are scanned in the same transaction as deletion, including other profiles. */
export async function removeUnusedAssets(): Promise<void> {
  await database.transaction(
    'rw',
    [database.assets, database.cards, database.preferences, database.presets, database.packs],
    async () => {
      const used = new Set<string>();
      for (const card of await database.cards.toArray()) {
        if (card.frontImage) used.add(card.frontImage);
        if (card.backImage) used.add(card.backImage);
      }
      for (const settings of await database.preferences.toArray()) {
        appearanceAssetHashes(settings).forEach((hash) => used.add(hash));
      }
      for (const preset of await database.presets.toArray()) {
        appearanceAssetHashes(preset.preferences).forEach((hash) => used.add(hash));
      }
      for (const pack of await database.packs.toArray()) {
        Object.values(pack.files).forEach((hash) => used.add(hash));
      }
      await database.assets.filter((asset) => !used.has(asset.hash)).delete();
    },
  );
}

export async function deleteProfile(profileId: string): Promise<void> {
  await database.transaction('rw', database.tables, async () => {
    for (const table of [
      database.sets,
      database.cards,
      database.presets,
      database.packs,
      database.sessions,
      database.attempts,
      database.reviews,
      database.gymRuns,
    ]) {
      await table.where('profileId').equals(profileId).delete();
    }
    await database.preferences.delete(profileId);
    await database.drafts.delete(profileId);
    await database.writings.delete(profileId);
    await database.profiles.delete(profileId);
  });
  await removeUnusedAssets();
}

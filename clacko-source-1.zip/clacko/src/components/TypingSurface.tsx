import { useEffect, useLayoutEffect, useRef, useState, type CSSProperties } from 'react';
import { useApp } from '../appContext';
import { typingFontFamily } from '../core/fonts';
import { graphemes } from '../core/typing';

interface TypingSurfaceProps {
  value: string;
  onChange: (value: string, inserted: string, offset: number, pasted: boolean) => void;
  target?: string;
  placeholder?: string;
  disabled?: boolean;
  compact?: boolean;
  onSubmit?: () => void;
  label?: string;
}

/** The textarea owns real input and selection; the overlay only paints feedback. */
export function TypingSurface({
  value,
  onChange,
  target,
  placeholder = 'Your thoughts go here. No rush.',
  disabled = false,
  compact = false,
  onSubmit,
  label = 'Typing area',
}: TypingSurfaceProps) {
  const { preferences } = useApp();
  const textarea = useRef<HTMLTextAreaElement>(null);
  const overlay = useRef<HTMLDivElement>(null);
  const previous = useRef(value);
  const composing = useRef(false);
  const pasted = useRef(false);
  const [focused, setFocused] = useState(false);
  const [caret, setCaret] = useState(value.length);

  useEffect(() => {
    if (!composing.current) previous.current = value;
  }, [value]);

  function commit(next: string) {
    let start = 0;
    const oldValue = previous.current;
    while (start < oldValue.length && start < next.length && oldValue[start] === next[start])
      start++;
    let oldEnd = oldValue.length;
    let newEnd = next.length;
    while (oldEnd > start && newEnd > start && oldValue[oldEnd - 1] === next[newEnd - 1]) {
      oldEnd--;
      newEnd--;
    }
    const inserted = next.slice(start, newEnd);
    onChange(next, inserted, start, pasted.current);
    previous.current = next;
    pasted.current = false;
  }

  const display = target ?? value;
  const cursor = caret;
  const showOverlay = Boolean(target);
  const characters = graphemes(display);
  let characterOffset = 0;

  useLayoutEffect(() => {
    if (!target || !focused || !overlay.current) return;
    const activeCaret = overlay.current.querySelector<HTMLElement>('[data-caret="true"]');
    if (!activeCaret) return;
    const relativeTop = activeCaret.offsetTop;
    const visibleBottom = overlay.current.scrollTop + overlay.current.clientHeight;
    if (relativeTop + activeCaret.offsetHeight > visibleBottom - 15) {
      overlay.current.scrollTop =
        relativeTop - overlay.current.clientHeight + activeCaret.offsetHeight + 25;
    } else if (relativeTop < overlay.current.scrollTop + 10) {
      overlay.current.scrollTop = Math.max(0, relativeTop - 25);
    }
  }, [value, target, focused, caret]);

  return (
    <div
      className={`typing-surface ${compact ? 'typing-compact' : ''} ${focused ? 'typing-focused' : ''} ${showOverlay ? 'typing-copy' : ''}`}
      style={
        {
          '--typing-size': `${compact ? 17 : preferences.fontSize}px`,
          '--typing-font': typingFontFamily(preferences.fontFamily),
        } as CSSProperties
      }
      onClick={() => textarea.current?.focus()}
    >
      {showOverlay && (
        <div ref={overlay} className="typing-overlay" aria-hidden="true">
          {characters.map((character, index) => {
            const offset = characterOffset;
            characterOffset += character.length;
            const activeCaret = offset === cursor && focused;
            return (
              <span
                key={index}
                data-caret={activeCaret ? 'true' : undefined}
                className={`${offset < value.length ? (value.slice(offset, offset + character.length) === character ? 'character-correct' : 'character-incorrect') : 'character-pending'} ${activeCaret ? `caret-${preferences.caretStyle}` : ''}`}
              >
                {character}
              </span>
            );
          })}
          {cursor >= display.length && (
            <span
              data-caret={focused ? 'true' : undefined}
              className={`end-caret ${focused ? `caret-${preferences.caretStyle}` : ''}`}
            >
              {' '}
            </span>
          )}
          {value.length > display.length && (
            <span className="character-incorrect">{value.slice(display.length)}</span>
          )}
        </div>
      )}
      <textarea
        ref={textarea}
        aria-label={label}
        spellCheck={false}
        autoCapitalize="off"
        autoCorrect="off"
        value={value}
        placeholder={showOverlay ? undefined : placeholder}
        disabled={disabled}
        className={showOverlay ? 'input-transparent' : ''}
        onPaste={() => {
          pasted.current = true;
        }}
        onCompositionStart={() => {
          composing.current = true;
        }}
        onCompositionEnd={(event) => {
          composing.current = false;
          commit(event.currentTarget.value);
        }}
        onChange={(event) => {
          const next = event.currentTarget.value;
          if (composing.current) onChange(next, '', 0, false);
          else commit(next);
          setCaret(event.currentTarget.selectionStart);
        }}
        onSelect={(event) => setCaret(event.currentTarget.selectionStart)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        onScroll={(event) => {
          if (overlay.current) overlay.current.scrollTop = event.currentTarget.scrollTop;
        }}
        onKeyDown={(event) => {
          if (
            event.key === 'Enter' &&
            !event.shiftKey &&
            onSubmit &&
            !event.nativeEvent.isComposing
          ) {
            event.preventDefault();
            onSubmit();
          }
        }}
      />
      {!value && !focused && !showOverlay && (
        <span className="typing-invitation">click here & make some noise</span>
      )}
    </div>
  );
}

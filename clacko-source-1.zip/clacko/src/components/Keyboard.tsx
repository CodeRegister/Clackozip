import { useState, type CSSProperties } from 'react';
import { useApp } from '../appContext';
import { defaultKeyboardDesign, type KeyDesign } from '../core/design';
import { useAssetUrl } from '../hooks/useAssetUrl';
import { keyboardAudio } from '../core/audio';

export { baseKeyboardRows as keyboardRows } from '../core/keyboards';
import { keyboardRowsFor, fingerForCode } from '../core/keyboards';
function KeyArtwork({ design }: { design?: KeyDesign }) {
  const image = useAssetUrl(design?.decal);
  return image ? (
    <img
      className="key-decal"
      src={image}
      alt=""
      style={{ opacity: design?.decalOpacity ?? 0.65 }}
    />
  ) : null;
}

export function Keyboard({
  decorative = false,
  selectedCode,
  onSelectKey,
  targetCode,
  showFingers = false,
}: {
  decorative?: boolean;
  selectedCode?: string;
  onSelectKey?: (code: string) => void;
  targetCode?: string;
  showFingers?: boolean;
}) {
  const { preferences, pressedKeys } = useApp();
  const design = preferences.keyboard ?? defaultKeyboardDesign();
  const rows = keyboardRowsFor(design.model, design.layout, design.customRows);
  const caseImage = useAssetUrl(design.caseImage);
  const [previewKey, setPreviewKey] = useState('');

  function preview(code: string) {
    setPreviewKey(code);
    keyboardAudio.unlock().then(() => keyboardAudio.play(code));
    window.setTimeout(() => {
      setPreviewKey('');
      keyboardAudio.play(code, false);
    }, 100);
  }

  return (
    <div
      className={`keyboard-wrap model-${design.model ?? 'sixty-five'} material-${design.material ?? 'plastic'} caps-${design.keyMaterial ?? 'pbt'} ${decorative ? 'keyboard-hero' : ''} ${showFingers ? 'show-fingers' : ''}`}
      style={
        {
          '--key-color': preferences.keyColor,
          '--case-color': design.caseColor,
          '--legend-color': design.legendColor,
          '--pressed-color': design.pressedColor,
          '--key-radius': `${preferences.keyRadius}px`,
          '--keyboard-scale': preferences.keyboardSize / 100,
          '--effect-intensity': design.effectIntensity ?? 1,
          '--effect-duration': `${design.effectDuration ?? 220}ms`,
        } as CSSProperties
      }
    >
      <div className="keyboard-case" role="group" aria-label="Interactive keyboard sound preview">
        <div
          className="keyboard-case-art"
          style={{
            backgroundImage: caseImage ? `url(${caseImage})` : undefined,
            opacity: design.imageOpacity,
          }}
        />
        <div className="keyboard-screw screw-left" />
        <div className="keyboard-screw screw-right" />
        {rows.map((row, rowIndex) => (
          <div className="keyboard-row" key={rowIndex}>
            {row.map((key) => (
              <button
                key={key.code}
                tabIndex={onSelectKey ? 0 : -1}
                className={`keycap effect-${design.keys[key.code]?.effect ?? design.effect ?? 'press'} ${targetCode === key.code ? 'key-target' : ''} finger-${fingerForCode(key.code).toLowerCase().replaceAll(' ', '-')} ${selectedCode === key.code ? 'key-selected' : ''} ${['Escape', 'Enter'].includes(key.code) ? 'key-accent' : ''} ${key.code === 'Space' ? 'space-key' : ''} ${pressedKeys.has(key.code) || previewKey === key.code ? 'key-pressed' : ''}`}
                style={{
                  flex: design.customWidths?.[key.code] ?? key.width ?? 1,
                  backgroundColor: design.keys[key.code]?.color,
                  color: design.keys[key.code]?.legendColor ?? design.legendColor,
                }}
                title={`${key.code} · ${fingerForCode(key.code)}`}
                onClick={() => {
                  preview(key.code);
                  onSelectKey?.(key.code);
                }}
                aria-label={onSelectKey ? `Customize ${key.code}` : `Preview ${key.code} sound`}
              >
                <KeyArtwork design={design.keys[key.code]} />
                <span className="key-legend">{design.keys[key.code]?.label ?? key.label}</span>
                {key.code === 'Space' && <span className="space-smile">⌣</span>}
              </button>
            ))}
          </div>
        ))}
      </div>
      <div className="keyboard-shadow" />
    </div>
  );
}

export function Mascot({ className = '', happy = false }: { className?: string; happy?: boolean }) {
  return (
    <svg className={`mascot ${className}`} viewBox="0 0 120 126" fill="none" aria-hidden="true">
      <path
        d="M25 15c2-8 11-11 35-11s33 3 35 11l15 72c3 14-5 23-17 25-22 4-44 4-66 0-12-2-20-11-17-25L25 15Z"
        fill="#cf650e"
      />
      <path
        d="M26 15c2-7 10-10 34-10s32 3 34 10l8 57c2 12-4 18-15 20-18 3-36 3-54 0-11-2-17-8-15-20l8-57Z"
        fill="#fe8b19"
        stroke="#e77b13"
        strokeWidth="2"
      />
      <path d="M33 16c13-4 39-4 53 0" stroke="#ffc47b" strokeWidth="4" strokeLinecap="round" />
      {happy ? (
        <>
          <path
            d="m37 44 6-5 6 5m22 0 6-5 6 5"
            stroke="#35231a"
            strokeWidth="5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </>
      ) : (
        <>
          <ellipse cx="43" cy="43" rx="5" ry="8" fill="#35231a" />
          <ellipse cx="77" cy="43" rx="5" ry="8" fill="#35231a" />
        </>
      )}
      <path d="M47 62c5 10 21 10 26 0" stroke="#35231a" strokeWidth="4" strokeLinecap="round" />
      <path
        d="m25 102-10 12m80-12 10 12M11 112l-4 1m100-1 4 1"
        stroke="#35231a"
        strokeWidth="4"
        strokeLinecap="round"
      />
    </svg>
  );
}

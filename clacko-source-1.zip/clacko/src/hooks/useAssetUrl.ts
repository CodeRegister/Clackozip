import { useEffect, useState } from 'react';
import { database } from '../core/database';

export function useAssetUrl(hash?: string): string | undefined {
  const [url, setUrl] = useState<string>();

  useEffect(() => {
    let active = true;
    let objectUrl: string | undefined;
    setUrl(undefined);

    if (hash) {
      database.assets.get(hash).then((asset) => {
        if (!active || !asset) return;
        objectUrl = URL.createObjectURL(asset.blob);
        setUrl(objectUrl);
      });
    }

    return () => {
      active = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [hash]);

  return url;
}

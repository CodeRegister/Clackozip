import type { CSSProperties } from 'react';
import { useApp } from '../appContext';
import { useAssetUrl } from './useAssetUrl';

/** Readability belongs to the typing surface, even with a vivid uploaded image. */
export function useSceneStyle(): CSSProperties {
  const { preferences } = useApp();
  const imageUrl = useAssetUrl(preferences.backgroundImage);
  if (!imageUrl) return {};

  const color = preferences.theme === 'midnight' ? '44, 45, 41' : '255, 255, 255';
  const dimming = preferences.backgroundDim / 100;
  const overlay = `rgba(${color}, ${dimming})`;

  return {
    backgroundImage: `linear-gradient(${overlay}, ${overlay}), url(${imageUrl})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
  };
}

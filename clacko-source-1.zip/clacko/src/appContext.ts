import { createContext, useContext } from 'react';
import type { Page, Preferences } from './core/types';

export interface AppState {
  profileId: string;
  switchProfile: (id: string) => void;
  preferences: Preferences;
  setPreferences: (patch: Partial<Preferences>) => void;
  pressedKeys: Set<string>;
  clacks: number;
  page: Page;
  navigate: (page: Page) => void;
  notify: (message: string) => void;
}

export const AppContext = createContext<AppState | null>(null);

export function useApp(): AppState {
  const app = useContext(AppContext);
  if (!app) throw new Error('useApp must be used inside AppProvider.');
  return app;
}

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { database, defaultPreferences } from './core/database';
import { keyboardAudio } from './core/audio';
import { debouncePress } from './core/mechvibes';
import { activateLocalFont } from './core/fonts';
import { zenAudio } from './core/zenAudio';
import { bundledStarterPack, starterPackId, sayClacko } from './core/starterPack';
import { loadStoredPack } from './core/soundPackImport';
import { AppContext } from './appContext';
import type { Page, Preferences } from './core/types';

function currentPage(): Page {
  const route = window.location.hash.slice(1).split('/')[0];
  return ['library', 'study', 'personalize', 'statistics', 'cards', 'gym'].includes(route)
    ? (route as Page)
    : 'library';
}

export function AppProvider({
  children,
  initialProfileId,
}: {
  children: ReactNode;
  initialProfileId: string;
}) {
  const [profileId, setProfileId] = useState(initialProfileId);
  const stored = useLiveQuery(() => database.preferences.get(profileId), [profileId]);
  const [preferences, updatePreferences] = useState(defaultPreferences(profileId));
  const preferencesRef = useRef(preferences);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [pressedKeys, setPressedKeys] = useState(new Set<string>());
  const [clacks, setClacks] = useState(0);
  const packReady = useRef<Promise<void>>(Promise.resolve());
  const greeted = useRef(false);
  const pageRef = useRef<Page>(currentPage());
  const heldKeys = useRef(new Set<string>());
  const [page, setPage] = useState<Page>(currentPage);
  pageRef.current = page;
  const [message, setMessage] = useState('');
  const messageTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  function notify(text: string) {
    setMessage(text);
    clearTimeout(messageTimer.current);
    messageTimer.current = setTimeout(() => setMessage(''), 4500);
  }

  useEffect(() => {
    if (stored) {
      const normalized = { ...defaultPreferences(profileId), ...stored };
      updatePreferences(normalized);
      preferencesRef.current = normalized;
    }
  }, [stored]);

  useEffect(() => {
    keyboardAudio.configure(preferences);
    zenAudio.configure(preferences.zen);
  }, [preferences]);

  // Color and label changes must not decode audio again while someone is typing.
  const keySoundSignature = JSON.stringify(
    Object.entries(preferences.keyboard?.keys ?? {})
      .filter(([, key]) => key.sound)
      .map(([code, key]) => [code, key.sound]),
  );
  useEffect(() => {
    keyboardAudio.prepareKeySounds(preferences).catch((error: Error) => notify(error.message));
  }, [profileId, keySoundSignature]);

  useEffect(() => {
    activateLocalFont(preferences.customFont).catch((error: Error) => notify(error.message));
  }, [preferences.customFont?.hash]);

  useEffect(() => {
    let active = true;
    const packId = preferences.soundPackId;
    if (['soft', 'crisp', 'deep'].includes(packId)) {
      keyboardAudio.useGeneratedPack();
      return;
    }
    packReady.current = (
      packId === starterPackId
        ? bundledStarterPack().then(async ({ pack, files }) => {
            if (active) await keyboardAudio.preparePack(pack, files);
          })
        : database.packs.get(packId).then(async (pack) => {
            if (pack && pack.profileId === profileId && active)
              await loadStoredPack(pack, () => active);
            else if (active) setPreferences({ soundPackId: starterPackId });
          })
    ).catch((error: Error) => {
      if (active) notify(error.message);
    });
    return () => {
      active = false;
    };
  }, [preferences.soundPackId, profileId]);

  useEffect(() => {
    const onHashChange = () => setPage(currentPage());
    const unlock = () => {
      keyboardAudio.unlock().catch(() => {});
    };
    const down = (event: KeyboardEvent) => {
      if (
        !greeted.current &&
        pageRef.current === 'library' &&
        event.key.length === 1 &&
        preferencesRef.current.homepageGreeting &&
        preferencesRef.current.soundEnabled
      ) {
        greeted.current = true;
        sayClacko(preferencesRef.current.volume);
      }
      if (!debouncePress(heldKeys.current, event.code, true)) return;
      setPressedKeys(new Set(heldKeys.current));
      setClacks((count) => count + 1);
      zenAudio.react(event.code);
      Promise.all([keyboardAudio.unlock(), packReady.current])
        .then(() => keyboardAudio.play(event.code, true))
        .catch(() => {});
    };
    const up = (event: KeyboardEvent) => {
      if (!debouncePress(heldKeys.current, event.code, false)) return;
      setPressedKeys(new Set(heldKeys.current));
      keyboardAudio.play(event.code, false);
    };
    const blur = () => {
      heldKeys.current.clear();
      setPressedKeys(new Set());
    };
    window.addEventListener('hashchange', onHashChange);
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('hashchange', onHashChange);
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
    };
  }, []);

  useEffect(() => {
    const scope = preferences.proceduralScope ?? 'zen';
    const enabled =
      scope === 'everywhere' || (scope === 'study' && ['study', 'gym'].includes(page));
    if (!enabled) return;
    const start = () => {
      void zenAudio.start();
    };
    window.addEventListener('pointerdown', start, { once: true });
    window.addEventListener('keydown', start, { once: true });
    return () => {
      window.removeEventListener('pointerdown', start);
      window.removeEventListener('keydown', start);
      zenAudio.stop();
    };
  }, [page, profileId, preferences.proceduralScope]);

  function setPreferences(patch: Partial<Preferences>) {
    const next = { ...preferencesRef.current, ...patch, profileId };
    preferencesRef.current = next;
    updatePreferences(next);
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      database.preferences
        .put(next)
        .catch(() => notify('Your changes could not be saved. Check your browser storage.'));
    }, 250);
  }

  function switchProfile(id: string) {
    clearTimeout(saveTimer.current);
    database.preferences.put(preferencesRef.current).catch(() => {});
    localStorage.setItem('clacko-profile', id);
    setProfileId(id);
    const defaults = defaultPreferences(id);
    preferencesRef.current = defaults;
    updatePreferences(defaults);
    window.location.hash = 'library';
  }

  return (
    <AppContext.Provider
      value={{
        profileId,
        switchProfile,
        preferences,
        setPreferences,
        pressedKeys,
        clacks,
        page,
        navigate: (next) => {
          window.location.hash = next;
        },
        notify,
      }}
    >
      {children}
      {message && (
        <div className="toast" role="status">
          {message}
        </div>
      )}
    </AppContext.Provider>
  );
}

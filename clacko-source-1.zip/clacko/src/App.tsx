import { lazy, Suspense, useEffect, useState, type CSSProperties } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useApp } from './appContext';
import { database } from './core/database';
import { Icon } from './components/Icon';
import { Mascot } from './components/Mascot';
import { Modal } from './components/Modal';
const CardLibrary = lazy(() =>
  import('./features/CardLibrary').then((module) => ({ default: module.CardLibrary })),
);
const ClackoGym = lazy(() =>
  import('./features/ClackoGym').then((module) => ({ default: module.ClackoGym })),
);
import { Library } from './features/Library';
const StudyStudio = lazy(() =>
  import('./features/StudyStudio').then((module) => ({ default: module.StudyStudio })),
);
const PersonalizationStudio = lazy(() =>
  import('./features/PersonalizationStudio').then((module) => ({
    default: module.PersonalizationStudio,
  })),
);
const Statistics = lazy(() =>
  import('./features/Statistics').then((module) => ({ default: module.Statistics })),
);
import { ProfileSettings } from './features/ProfileSettings';
import { useAssetUrl } from './hooks/useAssetUrl';
import type { Page } from './core/types';

const navigation: Array<{ page: Page; label: string }> = [
  { page: 'library', label: 'Home' },
  { page: 'cards', label: 'Cards' },
  { page: 'study', label: 'Study Studio' },
  { page: 'gym', label: 'Clacko Gym' },
  { page: 'personalize', label: 'Make it yours' },
  { page: 'statistics', label: 'Little wins' },
];

export default function App() {
  const { profileId, preferences, setPreferences, clacks, page, navigate } = useApp();
  const profile = useLiveQuery(() => database.profiles.get(profileId), [profileId]);
  const backgroundUrl = useAssetUrl(preferences.backgroundImage);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [selectedSetIds, setSelectedSetIds] = useState<string[]>([]);
  const [selectedCardIds, setSelectedCardIds] = useState<string[] | undefined>();
  const [online, setOnline] = useState(navigator.onLine);
  const [offlineReady, setOfflineReady] = useState(
    Boolean(localStorage.getItem('clacko-offline-ready')),
  );
  const [updateAvailable, setUpdateAvailable] = useState(false);

  useEffect(() => {
    const updateNetwork = () => setOnline(navigator.onLine);
    const ready = () => {
      setOfflineReady(true);
      localStorage.setItem('clacko-offline-ready', 'yes');
    };
    const update = () => setUpdateAvailable(true);
    window.addEventListener('online', updateNetwork);
    window.addEventListener('offline', updateNetwork);
    window.addEventListener('clacko-offline-ready', ready);
    window.addEventListener('clacko-update', update);
    return () => {
      window.removeEventListener('online', updateNetwork);
      window.removeEventListener('offline', updateNetwork);
      window.removeEventListener('clacko-offline-ready', ready);
      window.removeEventListener('clacko-update', update);
    };
  }, []);

  function startStudy(ids: string[] = [], cards?: string[]) {
    setSelectedCardIds(cards);
    setSelectedSetIds(ids);
    navigate('study');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <div
      className={`app-root theme-${preferences.theme} texture-${preferences.background} ${preferences.motion ? '' : 'motion-off'}`}
      style={
        {
          '--accent': preferences.accentColor,
          ...(preferences.customTheme
            ? {
                '--canvas': preferences.customTheme.canvas,
                '--surface': preferences.customTheme.surface,
                '--ink': preferences.customTheme.ink,
                '--muted': preferences.customTheme.muted,
                '--correct': preferences.customTheme.correct,
                '--incorrect': preferences.customTheme.incorrect,
                '--caret': preferences.customTheme.caret,
              }
            : {}),
        } as CSSProperties
      }
    >
      {backgroundUrl && (
        <div
          className="custom-background"
          style={{
            backgroundImage: `url(${backgroundUrl})`,
            opacity: 1 - preferences.backgroundDim / 100,
          }}
        />
      )}
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="app-header">
        <div className="header-inner">
          <button className="wordmark" onClick={() => navigate('library')} aria-label="Clacko home">
            <Mascot />
            <span>
              clacko<span className="logo-period">.</span>
            </span>
          </button>
          <nav className="main-nav" aria-label="Main navigation">
            {navigation.map((item) => (
              <button
                key={item.page}
                className={page === item.page ? 'active' : ''}
                aria-current={page === item.page ? 'page' : undefined}
                onClick={() => {
                  navigate(item.page);
                  window.scrollTo({ top: 0 });
                }}
              >
                {item.label}
                {page === item.page && <span />}
              </button>
            ))}
          </nav>
          <div className="header-actions">
            <button
              className="icon-button audio-toggle"
              title={preferences.soundEnabled ? 'Mute keyboard sounds' : 'Enable keyboard sounds'}
              aria-label={
                preferences.soundEnabled ? 'Mute keyboard sounds' : 'Enable keyboard sounds'
              }
              aria-pressed={preferences.soundEnabled}
              onClick={() => setPreferences({ soundEnabled: !preferences.soundEnabled })}
            >
              <Icon name={preferences.soundEnabled ? 'volume' : 'mute'} size={19} />
            </button>
            <span className="header-divider" />
            <button
              className="profile-button"
              onClick={() => setSettingsOpen(true)}
              aria-label="Profiles and data settings"
            >
              <span className="profile-avatar">
                {profile?.name.slice(0, 1).toUpperCase() ?? 'M'}
              </span>
              <span className="profile-name">{profile?.name ?? 'My little corner'}</span>
              <Icon name="chevron" size={15} />
            </button>
          </div>
        </div>
      </header>
      <main id="main" className="main-content" key={profileId}>
        {updateAvailable && (
          <div className="update-banner">
            <span>A fresh little update is ready. Finish your session before refreshing.</span>
            <button
              className="text-button"
              onClick={() => {
                if (
                  window.confirm(
                    'Refresh Clacko now? Your unfinished session can be resumed from its latest saved draft.',
                  )
                )
                  window.dispatchEvent(new Event('clacko-apply-update'));
              }}
            >
              Refresh
              <Icon name="refresh" size={14} />
            </button>
          </div>
        )}
        <Suspense
          fallback={
            <p className="empty-message" role="status">
              Opening your little space…
            </p>
          }
        >
          {page === 'library' && <Library onStudy={startStudy} />}
          {page === 'study' && (
            <StudyStudio initialSetIds={selectedSetIds} initialCardIds={selectedCardIds} />
          )}
          {page === 'cards' && <CardLibrary onStudy={startStudy} />}
          {page === 'gym' && <ClackoGym />}
          {page === 'personalize' && <PersonalizationStudio />}
          {page === 'statistics' && <Statistics onStudy={startStudy} />}
        </Suspense>
      </main>
      <footer className="app-footer">
        <div>
          <button className="footer-logo" onClick={() => navigate('library')}>
            clacko.
          </button>
          <span>A little more you, with every click.</span>
        </div>
        <div className="footer-right">
          <span className="device-status">
            <span className={`tiny-dot ${!online ? 'offline-dot' : ''}`} />
            {!online
              ? 'A little offline. Still right here.'
              : offlineReady
                ? 'Ready for your offline moments'
                : 'Made to stay on your device'}
          </span>
          <button onClick={() => setAboutOpen(true)}>The little details</button>
          <a href="/clacko-source.zip" download>
            Source code
            <Icon name="download" size={13} />
          </a>
        </div>
      </footer>
      {settingsOpen && <ProfileSettings onClose={() => setSettingsOpen(false)} />}
      {aboutOpen && (
        <Modal title="Made for your kind of mind." onClose={() => setAboutOpen(false)}>
          <div className="about-mascot">
            <Mascot />
          </div>
          <p>
            Clacko is a free, local study and typing playground. Your cards, images, writing, and
            progress live in this browser.
          </p>
          <p className="muted">
            {clacks.toLocaleString()} little clacks this visit. No global tracking. No account
            required by Clacko.
          </p>
          <p className="muted">
            This version includes spaced review, an untimed card library, Clacko Gym, portable
            keyboard designs, custom themes, font downloads, local profiles, procedural Zen worlds,
            music playlists, and complete profile backups. Anki packages, image occlusion, and
            arcade games remain on the roadmap.
          </p>
          <p className="fine-print">
            Audio parsing includes TypeScript ports from{' '}
            <a href="https://github.com/hainguyents13/mechvibes" target="_blank" rel="noreferrer">
              Mechvibes 3
            </a>
            , © 2026 Hải Nguyễn, MIT license. The Mechvibes 3 library offers official personal-use
            downloads. The included Cherry MX Brown recording is by majod (CC0). Optional
            synthesized sounds are made by Clacko. Bundled fonts: Nunito, Inter, JetBrains Mono
            (OFL); you can also bring your own.
          </p>
          <div className="modal-footer">
            <button
              className="button button-secondary"
              onClick={() => {
                setAboutOpen(false);
                setSettingsOpen(true);
              }}
            >
              Profiles & backups
              <Icon name="shield" size={16} />
            </button>
            <a className="button button-primary" href="/clacko-source.zip" download>
              Readable source
              <Icon name="download" size={16} />
            </a>
          </div>
        </Modal>
      )}
    </div>
  );
}

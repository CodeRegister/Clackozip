# Clacko

A small, offline-first study and typing playground. Make studying feel a little more like play.

This is the learning and keyboard release (0.3). It uses React, TypeScript, Vite, plain CSS, Dexie/IndexedDB, and native Web Audio. There is no application backend, cloud database, analytics, or Clacko account system.

## Run it

Use Node.js 22 or later and npm:

```bash
npm ci
npm run dev
```

Open the local URL printed by Vite. To verify and build:

```bash
npm test
npm run format
npm run build
```

Serve the `dist` directory over HTTPS or localhost. The build includes the PWA manifest, offline service worker, local fonts, and a downloadable source ZIP. `npm run build` creates that ZIP from an explicit source allowlist; it excludes hosting identity, credentials, Git metadata, and user data.

## What works

- Separate local profiles, with creation, rename, switching, and confirmed deletion.
- Study sets and multiline cards: create, edit, duplicate, remove, reorder, and tag.
- Original image attachments on either side through file selection, drop, or paste into the attachment area.
- A typeable welcome playground and a shared live 2D keyboard.
- Zen free writing, with optional counters and explicit keep/discard.
- Remix copying of visible prompts, answers, or both from selected sets.
- Recall and Reverse with typed responses, reveal, and self-evaluation.
- Spaced Review with typed recall, Again/Hard/Good/Easy ratings, interval previews, daily limits, direction-specific schedules, skip, and undo.
- Untimed Cards library with all definitions, flip-through browsing, search, tags, individual/bulk selection, stars, suspension, and CSV export.
- Clacko Gym: 15 original lessons, key/word/text drills, weak-key practice, finger guidance, blind practice, local progress and history per layout.
- Six layouts: QWERTY US/UK, QWERTZ, AZERTY, Dvorak, and Colemak. The OS layout must match; the app does not remap hardware.
- Pause, finish, and recovery of unfinished sessions from saved drafts.
- Themes, key colors, keyboard size/radius/visibility, motion, uploaded backgrounds, typography, and copying-caret styles.
- Named full appearance presets, local persistence, and a live typing playground.
- Mechvibes 3.5.6's official ten-pack catalog, personal local download/install, and ZIP import. App v3 and pack-format V2 are clearly distinguished.
- 60%, 65%, tenkeyless, full-size, typewriter, and custom-row keyboard models, with plastic/aluminum/wood/glass frames and keycap finishes.
- Per-key colors, legends, decals, uploaded clips, recorded/procedural sound assignments, widths on custom boards, and individual click effects.
- Press, glow, ripple, bounce, or no effect, with intensity/duration controls.
- A real Cherry MX Brown recording bundled and selected by default, with no installation step.
- Keyboard frame images and portable keyboard/theme ZIPs with original asset integrity checks.
- User-selected system/bundled fonts, uploaded font files, and direct HTTPS or Google Fonts CSS downloads saved for offline use.
- Custom theme tokens for canvas, surface, text, feedback, and caret; save them as named presets.
- Procedural Zen pixel, festive bell, spooky, and rain soundscapes with typing-reactive notes.
- Local music/loop playback, multiple audio-file import, and browser folder selection for playlists.
- Three optional original synthesized fallback typing sounds.
- Two-column CSV, TSV, and Anki text imports with a preview before saving.
- Profile backups containing study data, histories, preserved writing, settings, presets, original images, and imported audio.
- Learning history, weak-card review, activity, and separate Remix typing statistics.

## Find your way around

The homepage note accepts free writing, including physical typing on blank areas of the homepage, and greets you with “Clacko!”. Home holds sets and the card editor; Cards offers untimed reading and flipping. Use **New set** to create one, or **Import** to preview two columns of prompts and answers. Press `/` outside a text field to focus the library search.

Study Studio has Zen, Remix, Recall, Reverse, and Spaced Review. Choose one, select sets, tags, states, or individual cards if needed, and begin. Recall, Reverse, and Remix also offer set order, shuffle, and practice-priority order. Recall and Reverse ask you to judge your own answer. Remix shows the material you are copying and does not award knowledge mastery. Recall and Reverse are free practice and leave the spaced schedule unchanged. In recall modes, Enter reveals an answer; Shift+Enter adds a line. Spaced Review uses 1–4 for ratings after revealing, and saves each rating immediately. It uses Clacko’s transparent scheduler, not FSRS or Anki-compatible scheduling.

Make it yours changes the typing environment immediately. In Keyboard, click a virtual key or choose its physical code to edit only that key. Add a keyboard frame image, per-key decal, or a short custom sound. Export keyboard saves a `.clacko-look` ZIP; Import previews it before application. Keyboard and theme exports affect separate settings.

Typography lets you choose a font, upload WOFF/WOFF2/TTF/OTF, or enter an HTTPS font/Google Fonts CSS link. Downloads happen on an explicit button press and become local copies. Remote stylesheets are parsed for font URLs rather than injected.

Zen world includes optional generative sound profiles, with scope controls for Zen sessions, study/Gym, or every page. Their notes respond to physical typing. The music player accepts local audio files or a folder selection, copies tracks locally, supports looping one track, and advances through multiple tracks. Use Just the keys to disable the procedural instrument. Keyboard sounds, soundscape volume, and music volume are independent.

Presets keep complete setups. Click a virtual key to preview its sound. Audio needs a browser user gesture before it can play.

The profile button opens local profiles and backups. Export a `.clacko` backup regularly. Restore previews the contents and integrity checks, then creates a separate profile. It never overwrites a current profile.

## Readable source map

| Location                                    | Responsibility                                                       |
| ------------------------------------------- | -------------------------------------------------------------------- |
| `src/components/`                           | Shared keyboard, typing surface, icons, mascot, and modal.           |
| `src/features/`                             | Library, editor, import preview, studios, statistics, and profiles.  |
| `src/core/database.ts`                      | IndexedDB schema, profile creation, original media storage, cleanup. |
| `src/core/typing.ts`                        | Grapheme handling, copying metrics, matching, content extraction.    |
| `src/core/mechvibes.ts`                     | Attributed pack normalization and event-lookup ports.                |
| `src/core/legacyKeyCodes.ts`                | Attributed legacy IOHook-to-browser mapping table.                   |
| `src/core/audio.ts`                         | Browser audio decoding, generated samples, voices, fades.            |
| `src/core/soundPackImport.ts`               | ZIP limits, preview, media ownership, saved pack loading.            |
| `src/core/transfer.ts`                      | Backup validation/restoration and two-column text parsing.           |
| `src/hooks/`                                | Object URL ownership and readable background presentation.           |
| `src/appContext.ts` / `src/AppProvider.tsx` | Active profile, narrow shared settings, physical key feedback.       |
| `src/styles.css`                            | Commented visual sections and responsive layouts.                    |
| `tests/`                                    | Behavior-focused tests for metrics, imports, storage, and backups.   |

All authored source uses descriptive names, normal indentation, explicit types, and Prettier formatting. The compiled `dist` files are optimized output; the ZIP and repository retain the readable originals.

## Offline data and recovery

All owned content lives in IndexedDB, including review schedules and layout-specific Gym runs. `localStorage` only holds the selected profile ID and an offline-readiness hint. Imported media is copied into local Blob storage and identified by SHA-256 of the exact bytes. Shared assets are removed only after checking references across profiles, cards, backgrounds, presets, and packs in a transaction.

The initial profile includes three editable example sets. New profiles are empty. The service worker caches the application shell and shipped assets after the first online load. Private hosting may require a first online authentication at the hosting layer. Your actual study data stays local. Do not assume the app is ready offline until installation/cache setup has finished.

Draft sessions save approximately once per second and on in-app navigation. A crash can lose the final unsaved second. Recovered sessions resume paused. A browser may prevent final asynchronous writes during a forced shutdown. Clearing browser/site storage can remove everything; maintain external backups. **Ask the browser to keep my data** requests persistent storage where supported; browsers decide whether to grant it.

## Audio and source attribution

The pack adapter includes TypeScript ports from Mechvibes 3 at commit `56d7135bcdf6ceb7fe2f4e06f8ca0903277a9e68`. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) and [docs/MECHVIBES.md](docs/MECHVIBES.md).

Classic V1 single/multi keyboard packs and V2 single/multi keyboard packs are supported within documented browser limits. Pack preview reports skipped mappings. Every referenced audio file must decode before activation. Native rodio playback and system-wide key capture are replaced by Web Audio and in-app browser events.

The official Mechvibes 3 default catalog is included with exact source configs and license labels. These recordings are listed as free for personal use, with redistribution restricted. Clacko therefore installs recordings into the user's own local profile instead of putting them in its source ZIP. Direct installation depends on the server allowing browser CORS access; the official download + local ZIP import path is also provided. Three optional Clacko synthesized sounds remain available as fallbacks. The shipped default is a separate CC0 Cherry MX Brown recording by majod, edited into eight switch transients; see `public/starter-pack/LICENSE.txt`. It is ready without installing an official pack. The audible Clacko greeting is generated with CMU Flite and its voice notice is included. Import only packs you are entitled to use. Audio cannot play for typing in other applications.

## Design ownership and backups

Full profile backups include review schedules, Gym progress, keyboard frame images, per-key decals and clips, imported fonts, music playlists, and all preset media. Content hashes deduplicate identical files. Portable keyboard and theme imports validate asset hashes and remap imported sound-pack IDs into the destination profile. Deleting a sound pack that is used by a key or saved preset is blocked until those assignments are changed.

## Current limits

- Anki `.apkg` / `.colpkg`, rich Anki note templates, and image occlusion are not implemented. Two-column text exports work.
- Arcade games are deliberately deferred.
- Keyboard models are stylized 2D representations, not manufacturer-specific CAD replicas. Layout maps cover their unshifted ANSI positions; regional ISO extra keys, Shift/capital drills, additional languages, and full hardware remapping are not implemented.
- Presets can be saved, applied, and deleted; rename and duplicate actions are not yet available.
- Remix is currently an untimed, finite passage. Timed, word-count, random-order, and unlimited variants remain planned.
- Custom copying carets use character highlights; fully interpolated caret movement remains planned.
- Text imports require exactly two nonempty columns. Header removal is explicit. Unsupported rich markup is retained as text rather than executed.
- Music folder selection imports a snapshot of supported audio files; it does not continuously watch a folder. Current limits are 100 tracks per selection, 12 MB per track, and 50 MB per batch. Key sounds are limited to 5 MB / 12 seconds. Custom fonts are limited to 5 MB.
- A text import is limited to 3 MB; original images to 8 MB; sound ZIPs to 30 MB compressed / 60 MB expanded; decoded pack audio to 96 MB; backups to 80 MB compressed / 160 MB expanded.
- Parsing and small archive work currently run on the main thread under these limits. Worker-based large imports remain planned.
- Zen/Remix/Recall/Reverse keep one unfinished draft per profile. Spaced Review commits each rating atomically; its current ungraded answer is not recovered after reload. Starting another free-practice session replaces its previous draft. Editing cards during a session is not yet supported.
- Weak-card ranking is deterministic, with new cards first and lower successful-review ratios next. Each selected card appears at most once in a session; adaptive within-session repetition remains planned.
- Browser audio latency, codec support, and installation behavior vary by platform. Do not interpret a successful import as a universal cross-browser compatibility guarantee.
- The interface includes responsive CSS, but this release has not been verified on a physical mobile device or with a screen reader.

See [docs/ROADMAP.md](docs/ROADMAP.md) for the remaining work and [docs/METRICS.md](docs/METRICS.md) for scoring definitions.

## License

Clacko source is MIT licensed. Attributed ports retain the upstream MIT notice. Bundled fonts use the SIL Open Font License; copies are included in `licenses/`.

import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import {
  createProfile,
  database,
  defaultPreferences,
  deleteProfile,
  initializeDatabase,
  removeUnusedAssets,
  saveAsset,
} from '../src/core/database';
import { buildProfileBackup, inspectBackup, restoreBackup } from '../src/core/transfer';
import { strToU8, unzipSync, zipSync } from 'fflate';

beforeEach(async () => {
  await database.delete();
  await database.open();
  await initializeDatabase();
});

describe('offline profile storage', () => {
  it('initializes once and preserves saved cards across reopening', async () => {
    const count = await database.cards.count();
    await initializeDatabase();
    expect(await database.cards.count()).toBe(count);
    database.close();
    await database.open();
    expect(await database.cards.count()).toBe(count);
  });

  it('isolates profiles and retains images still referenced by another profile', async () => {
    const original = (await database.profiles.toArray())[0];
    const second = await createProfile('Another corner');
    const imageHash = await saveAsset(new Blob(['original-image-bytes'], { type: 'image/png' }));
    const firstCard = (await database.cards.toArray())[0];
    await database.cards.update(firstCard.id, { frontImage: imageHash });
    await database.preferences.update(second, { backgroundImage: imageHash });
    expect(await database.sets.where('profileId').equals(second).count()).toBe(0);
    await deleteProfile(original.id);
    expect(await database.assets.get(imageHash)).toBeDefined();
    expect(await database.cards.where('profileId').equals(original.id).count()).toBe(0);
    await database.preferences.update(second, { backgroundImage: undefined });
    await removeUnusedAssets();
    expect(await database.assets.get(imageHash)).toBeUndefined();
  });

  it('rolls back an interrupted transaction', async () => {
    const original = (await database.sets.toArray())[0];
    await expect(
      database.transaction('rw', database.sets, async () => {
        await database.sets.update(original.id, { title: 'Should not persist' });
        throw new Error('Simulated storage failure');
      }),
    ).rejects.toThrow('Simulated');
    expect((await database.sets.get(original.id))?.title).toBe(original.title);
  });

  it('deduplicates media by exact original bytes', async () => {
    const first = await saveAsset(new Blob(['same bytes']));
    const second = await saveAsset(new Blob(['same bytes']));
    expect(first).toBe(second);
    expect(await database.assets.count()).toBe(1);
  });
});

describe('complete profile backups', () => {
  it('rejects corrupt appearance settings without touching existing data', async () => {
    const profile = (await database.profiles.toArray())[0];
    const archive = await buildProfileBackup(profile.id, defaultPreferences(profile.id));
    const files = unzipSync(archive);
    const manifest = JSON.parse(new TextDecoder().decode(files['manifest.json']));
    manifest.preferences.fontSize = 999999;
    files['manifest.json'] = strToU8(JSON.stringify(manifest));
    const corrupted = zipSync(files);
    await expect(
      inspectBackup(new File([new Uint8Array(corrupted)], 'corrupt.clacko')),
    ).rejects.toThrow('out of range');
    expect(await database.profiles.count()).toBe(1);
  });

  it('restores into a separate profile and preserves media byte-for-byte', async () => {
    const profile = (await database.profiles.toArray())[0];
    const card = (await database.cards.toArray())[0];
    const originalBytes = new Uint8Array([0, 255, 13, 10, 42, 128]);
    const hash = await saveAsset(new Blob([originalBytes], { type: 'image/png' }));
    await database.cards.update(card.id, { frontImage: hash });
    await database.writings.put({ profileId: profile.id, text: 'A private little thought.' });
    const archive = await buildProfileBackup(profile.id, defaultPreferences(profile.id));
    const preview = await inspectBackup(new File([new Uint8Array(archive)], 'backup.clacko'));
    const restoredId = await restoreBackup(preview);
    expect(restoredId).not.toBe(profile.id);
    expect(await database.profiles.count()).toBe(2);
    const restoredCards = await database.cards.where('profileId').equals(restoredId).toArray();
    expect(restoredCards).toHaveLength(
      await database.cards.where('profileId').equals(profile.id).count(),
    );
    expect(restoredCards.find((item) => item.prompt === card.prompt)?.frontImage).toBe(hash);
    expect(new Uint8Array(await (await database.assets.get(hash))!.blob.arrayBuffer())).toEqual(
      originalBytes,
    );
    expect((await database.writings.get(restoredId))?.text).toBe('A private little thought.');
  });

  it('rejects tampered assets before creating a restored profile', async () => {
    const profile = (await database.profiles.toArray())[0];
    const card = (await database.cards.toArray())[0];
    const hash = await saveAsset(new Blob(['original']));
    await database.cards.update(card.id, { backImage: hash });
    const archive = await buildProfileBackup(profile.id, defaultPreferences(profile.id));
    const files = unzipSync(archive);
    files[`assets/${hash}`] = strToU8('tampered');
    const tampered = zipSync(files);
    await expect(
      inspectBackup(new File([new Uint8Array(tampered)], 'tampered.clacko')),
    ).rejects.toThrow('integrity');
    expect(await database.profiles.count()).toBe(1);
  });
});

it('backs up and remaps scheduling and Gym progress without losing legacy backup support', async () => {
  const profile = (await database.profiles.toArray())[0];
  const card = (await database.cards.toArray())[0];
  const { newReviewState, scheduleReview } = await import('../src/core/review');
  const state = scheduleReview(newReviewState(profile.id, card.id, 'reverse'), 'good', Date.now());
  await database.reviews.put(state);
  await database.gymRuns.add({
    id: 'gym-run',
    profileId: profile.id,
    layout: 'dvorak',
    lessonId: 3,
    exercise: 'keys',
    duration: 30,
    wpm: 12,
    accuracy: 97,
    passed: true,
    characters: 90,
    errors: { KeyJ: 2 },
    createdAt: Date.now(),
  });
  const archive = await buildProfileBackup(profile.id, defaultPreferences(profile.id));
  const inspected = await inspectBackup(new File([new Uint8Array(archive)], 'new.clacko'));
  const restored = await restoreBackup(inspected);
  const restoredCard = (await database.cards.where('profileId').equals(restored).toArray()).find(
    (item) => item.prompt === card.prompt,
  )!;
  const restoredState = (await database.reviews.where('profileId').equals(restored).toArray())[0];
  expect(restoredState.cardId).toBe(restoredCard.id);
  expect(restoredState.id).toBe(`${restored}:${restoredCard.id}:reverse`);
  expect(restoredState.dueAt).toBe(state.dueAt);
  expect((await database.gymRuns.where('profileId').equals(restored).toArray())[0].errors).toEqual({
    KeyJ: 2,
  });
  const entries = unzipSync(archive);
  const legacy = JSON.parse(new TextDecoder().decode(entries['manifest.json']));
  delete legacy.reviews;
  delete legacy.gymRuns;
  entries['manifest.json'] = strToU8(JSON.stringify(legacy));
  const oldPreview = await inspectBackup(
    new File([new Uint8Array(zipSync(entries))], 'old.clacko'),
  );
  expect(await restoreBackup(oldPreview)).toBeTypeOf('string');
});

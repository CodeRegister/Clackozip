import { describe, expect, it } from 'vitest';
import { prioritizeCards } from '../src/core/study';
import type { Attempt, Flashcard } from '../src/core/types';

const card = (id: string, position: number): Flashcard => ({
  id,
  position,
  profileId: 'profile',
  setId: 'set',
  prompt: `Prompt ${id}`,
  answer: `Answer ${id}`,
  tags: [],
});

const attempt = (
  cardId: string,
  correct: boolean,
  direction: Attempt['direction'] = 'recall',
): Attempt => ({
  id: `${cardId}-${direction}`,
  profileId: 'profile',
  sessionId: 'session',
  cardId,
  direction,
  correct,
  createdAt: 100,
});

describe('deterministic review priorities', () => {
  it('puts new and weak cards before mastered cards without repeating any item', () => {
    const cards = [card('known', 0), card('weak', 1), card('new', 2)];
    const result = prioritizeCards(
      cards,
      [attempt('known', true), attempt('weak', false)],
      'recall',
    );
    expect(result.map((item) => item.id)).toEqual(['new', 'weak', 'known']);
    expect(new Set(result.map((item) => item.id)).size).toBe(cards.length);
    expect(cards[0].id).toBe('known');
  });

  it('keeps review directions independent', () => {
    const cards = [card('first', 0), card('second', 1)];
    const history = [attempt('first', false, 'reverse'), attempt('second', true, 'recall')];
    expect(prioritizeCards(cards, history, 'reverse').map((item) => item.id)).toEqual([
      'second',
      'first',
    ]);
  });
});

import { describe, expect, it } from 'vitest';
import {
  debouncePress,
  lookupSegment,
  parseMechvibesConfig,
  safePackPath,
} from '../src/core/mechvibes';
import { inspectSoundPack } from '../src/core/soundPackImport';
import { strToU8, zipSync } from 'fflate';

describe('Mechvibes source ports', () => {
  it('converts classic start/duration to start/end without inventing release sounds', () => {
    const parsed = parseMechvibesConfig({
      name: 'Classic',
      config_version: 1,
      sound: 'sound.wav',
      defines: { '30': [100, 80] },
    });
    expect(parsed.keys.KeyA.down).toEqual({ file: 'sound.wav', start: 100, end: 180 });
    expect(lookupSegment(parsed.keys, 'KeyA', false)).toBeUndefined();
  });

  it('keeps V2 press and release segments distinct', () => {
    const parsed = parseMechvibesConfig({
      name: 'V2',
      author: 'Someone',
      config_version: '2',
      audio_file: 'sound.wav',
      definitions: {
        KeyA: {
          timing: [
            [0, 30],
            [30, 60],
          ],
        },
      },
    });
    expect(lookupSegment(parsed.keys, 'KeyA', false)).toEqual({
      file: 'sound.wav',
      start: 30,
      end: 60,
    });
    expect(lookupSegment(parsed.keys, 'KeyZ', true)).toBeUndefined();
  });

  it('normalizes field aliases and multi-file whole-clip entries', () => {
    const parsed = parseMechvibesConfig({
      name: 'Multi',
      m_author: 'A maker',
      config_version: 2,
      definition_method: 'multi',
      defs: { KeyA: { audio_file: './a.wav' } },
    });
    expect(parsed.author).toBe('A maker');
    expect(parsed.keys.KeyA.down).toEqual({ file: 'a.wav', start: 0 });
  });

  it('preserves extended legacy key mapping rather than JavaScript keyCode', () => {
    const parsed = parseMechvibesConfig({
      name: 'Classic',
      sound: 's.wav',
      defines: { '3675': [0, 20], '30': [20, 30] },
    });
    expect(parsed.keys.MetaLeft).toBeDefined();
    expect(parsed.keys.KeyA.down.end).toBe(50);
  });

  it('reports unsupported segment counts and rejects unsupported versions', () => {
    const parsed = parseMechvibesConfig({
      name: 'Odd',
      author: 'Maker',
      audio_file: 's.wav',
      definitions: {
        KeyA: { timing: [[0, 10]] },
        KeyB: {
          timing: [
            [0, 10],
            [10, 20],
            [20, 30],
          ],
        },
      },
    });
    expect(parsed.keys.KeyB).toBeUndefined();
    expect(parsed.warnings).toHaveLength(1);
    expect(() => parseMechvibesConfig({ name: 'Future', config_version: 3 })).toThrow(
      'unsupported',
    );
  });

  it('rejects malformed clip ranges and unsafe paths', () => {
    expect(() => safePackPath('../s.wav')).toThrow('Unsafe');
    expect(() => safePackPath('C:\\s.wav')).toThrow('Unsafe');
    expect(() =>
      parseMechvibesConfig({
        name: 'Invalid',
        author: 'Maker',
        audio_file: 's.wav',
        definitions: { KeyA: { timing: [[20, 10]] } },
      }),
    ).toThrow('positive ranges');
  });

  it('debounces repeated physical downs while retaining release events', () => {
    const held = new Set<string>();
    expect(debouncePress(held, 'KeyA', true)).toBe(true);
    expect(debouncePress(held, 'KeyA', true)).toBe(false);
    expect(debouncePress(held, 'KeyA', false)).toBe(true);
    expect(debouncePress(held, 'KeyA', false)).toBe(false);
  });

  it('previews a real ZIP without committing files or profile data', async () => {
    const zip = zipSync({
      'config.json': strToU8(
        JSON.stringify({
          name: 'Fixture',
          author: 'Clacko',
          audio_file: 'sound.wav',
          definitions: { KeyA: { timing: [[0, 30]] } },
        }),
      ),
      'sound.wav': new Uint8Array([1, 2, 3]),
    });
    const result = await inspectSoundPack(
      new File([new Uint8Array(zip)], 'fixture.zip'),
      'test-profile',
    );
    expect(result.pack.name).toBe('Fixture');
    expect(result.blobs['sound.wav'].size).toBe(3);
    expect(result.pack.files).toEqual({});
  });
});

import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { strToU8, unzipSync, zipSync } from 'fflate';
import {
  createId,
  createProfile,
  database,
  defaultPreferences,
  initializeDatabase,
  removeUnusedAssets,
  saveAsset,
} from '../src/core/database';
import {
  appearanceAssetHashes,
  defaultKeyboardDesign,
  defaultZenSettings,
} from '../src/core/design';
import { applyLook, buildLook, inspectLook } from '../src/core/portableLook';
import { buildProfileBackup, inspectBackup, restoreBackup } from '../src/core/transfer';

beforeEach(async () => {
  await database.delete();
  await database.open();
  await initializeDatabase();
});

async function designedSettings() {
  const profile = (await database.profiles.toArray())[0];
  const settings = defaultPreferences(profile.id);
  const hash = await saveAsset(new Blob(['an original asset'], { type: 'image/png' }));
  settings.keyboard = {
    ...defaultKeyboardDesign(),
    caseImage: hash,
    keys: {
      KeyA: {
        label: 'Clacko!',
        color: '#edb267',
        decal: hash,
        sound: { assetHash: hash, volume: 0.6 },
      },
    },
  };
  settings.customFont = { name: 'My own font', hash };
  settings.zen = {
    ...defaultZenSettings(),
    profile: 'pixel',
    playlist: [{ id: createId(), name: 'My song', hash }],
  };
  return { settings, hash };
}

describe('portable designs and complete media ownership', () => {
  it('finds every asset referenced by keys, frame, font, and playlist once', async () => {
    const { settings, hash } = await designedSettings();
    expect(appearanceAssetHashes(settings)).toEqual([hash]);
    await database.preferences.put(settings);
    await removeUnusedAssets();
    expect(await database.assets.get(hash)).toBeDefined();
  });

  it('exports a keyboard with decals and clips, without changing theme settings', async () => {
    const { settings, hash } = await designedSettings();
    const archive = await buildLook(settings, 'keyboard', 'A small keyboard');
    const preview = await inspectLook(new File([new Uint8Array(archive)], 'keyboard.clacko-look'));
    expect(preview.assets[0].hash).toBe(hash);
    const second = await createProfile('Other profile');
    const patch = await applyLook(preview, second);
    expect(patch.keyboard?.keys.KeyA.label).toBe('Clacko!');
    expect(patch.keyboard?.keys.KeyA.sound?.assetHash).toBe(hash);
    expect(patch).not.toHaveProperty('theme');
    expect(patch).not.toHaveProperty('zen');
  });

  it('preserves a custom font in a theme export without copying keyboard settings', async () => {
    const { settings, hash } = await designedSettings();
    settings.customTheme = {
      canvas: '#fdf6e3',
      surface: '#ffffff',
      ink: '#222222',
      muted: '#777777',
      correct: '#548c48',
      incorrect: '#bf524a',
      caret: '#fb941a',
    };
    const archive = await buildLook(settings, 'theme', 'My theme');
    const preview = await inspectLook(new File([new Uint8Array(archive)], 'theme.clacko-look'));
    const patch = await applyLook(preview, settings.profileId);
    expect(patch.customFont?.hash).toBe(hash);
    expect(patch.customTheme?.canvas).toBe('#fdf6e3');
    expect(patch).not.toHaveProperty('keyboard');
  });

  it('remaps per-key imported pack IDs into the destination profile', async () => {
    const { settings } = await designedSettings();
    const audioHash = await saveAsset(new Blob(['clip']));
    const packId = createId();
    const config = {
      name: 'A real configuration',
      author: 'Fixture',
      config_version: '2',
      audio_file: 's.wav',
      definitions: { KeyA: { timing: [[0, 20]] } },
    };
    await database.packs.add({
      id: packId,
      profileId: settings.profileId,
      name: config.name,
      author: config.author,
      keys: { KeyA: { down: { file: 's.wav', start: 0, end: 20 } } },
      files: { 's.wav': audioHash },
      originalConfig: JSON.stringify(config),
      warnings: [],
      recommendedVolume: 1,
      randomPitch: false,
    });
    settings.keyboard!.keys.KeyB = { sound: { packId, sampleCode: 'KeyA', volume: 1 } };
    const archive = await buildLook(settings, 'keyboard', 'Sounds included');
    const preview = await inspectLook(new File([new Uint8Array(archive)], 'look.clacko-look'));
    const second = await createProfile('Destination');
    const patch = await applyLook(preview, second);
    const newId = patch.keyboard!.keys.KeyB.sound!.packId!;
    expect(newId).not.toBe(packId);
    expect((await database.packs.get(newId))?.profileId).toBe(second);
  });

  it('restores frame, per-key media, custom font, and playlist byte-for-byte', async () => {
    const { settings, hash } = await designedSettings();
    const archive = await buildProfileBackup(settings.profileId, settings);
    const preview = await inspectBackup(new File([new Uint8Array(archive)], 'profile.clacko'));
    const restored = await restoreBackup(preview);
    const preferences = (await database.preferences.get(restored))!;
    expect(preferences.keyboard?.keys.KeyA.decal).toBe(hash);
    expect(preferences.customFont?.name).toBe('My own font');
    expect(preferences.zen?.playlist[0].hash).toBe(hash);
    expect(await (await database.assets.get(hash))!.blob.text()).toBe('an original asset');
  });

  it('rejects tampered or incomplete portable media before applying anything', async () => {
    const { settings, hash } = await designedSettings();
    const archive = await buildLook(settings, 'keyboard', 'Test');
    const entries = unzipSync(archive);
    entries[`assets/${hash}`] = strToU8('tampered');
    await expect(
      inspectLook(new File([new Uint8Array(zipSync(entries))], 'bad.clacko-look')),
    ).rejects.toThrow();
    expect(await database.profiles.count()).toBe(1);
  });
});

it('round-trips custom rows, materials, key effects, and procedural assignments', async () => {
  const { settings } = await designedSettings();
  settings.keyboard = {
    ...settings.keyboard!,
    model: 'custom',
    layout: 'dvorak',
    material: 'wood',
    keyMaterial: 'abs',
    effect: 'ripple',
    effectIntensity: 1.4,
    effectDuration: 300,
    customRows: [['KeyF', 'KeyJ'], ['Space']],
    customWidths: { Space: 6 },
    keys: { KeyF: { effect: 'glow', sound: { procedural: 'bell', volume: 0.5 } } },
  };
  const bytes = await buildLook(settings, 'keyboard', 'My board');
  const preview = await inspectLook(new File([new Uint8Array(bytes)], 'board.clacko-look'));
  const destination = await createProfile('Another keyboard');
  const patch = await applyLook(preview, destination);
  expect(patch.keyboard).toEqual(settings.keyboard);
});

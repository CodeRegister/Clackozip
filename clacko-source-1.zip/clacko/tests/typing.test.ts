import { describe, expect, it } from 'vitest';
import { calculateMetrics, extractRemixText, graphemes, matchesAnswer } from '../src/core/typing';
import { parseCards } from '../src/core/transfer';

describe('typing metrics and study content', () => {
  it('keeps historical mistakes after corrections', () => {
    const metrics = calculateMetrics('hello', 'hello', 6, 5, 60);
    expect(metrics).toEqual({ rawWpm: 1, adjustedWpm: 1, accuracy: 83 });
  });

  it('does not count a retained wrong character as adjusted WPM', () => {
    expect(calculateMetrics('hello world', 'hello there', 11, 6, 60).adjustedWpm).toBe(1);
  });

  it('handles zero elapsed time without invalid values', () => {
    expect(calculateMetrics('', '', 0, 0, 0)).toEqual({ rawWpm: 0, adjustedWpm: 0, accuracy: 100 });
  });

  it('counts composed characters and emoji as graphemes', () => {
    expect(graphemes('a\u0301👩‍💻')).toHaveLength(2);
  });

  it('copies meaningful whole phrases and removes identical entries', () => {
    expect(
      extractRemixText(
        [
          { prompt: 'A question?', answer: 'A useful phrase.' },
          { prompt: 'Another?', answer: 'A useful phrase.' },
        ],
        'answers',
      ),
    ).toBe('A useful phrase.');
  });

  it('matches case and whitespace without discarding punctuation', () => {
    expect(matchesAnswer('  Careful   HABITS. ', 'Careful habits.')).toBe(true);
    expect(matchesAnswer('Careful habits', 'Careful habits.')).toBe(false);
    expect(matchesAnswer('cafe\u0301', 'café')).toBe(true);
  });
});

describe('two-column text import', () => {
  it('preserves quoted commas, escaped quotes, and multiline text', () => {
    expect(parseCards('"What, exactly?","A ""small"" answer.\nOn two lines."', ',')).toEqual([
      ['What, exactly?', 'A "small" answer.\nOn two lines.'],
    ]);
  });

  it('accepts BOMs and Windows line endings', () => {
    expect(parseCards('\uFEFFQuestion\tAnswer\r\nNext\tAnother\r\n')).toHaveLength(2);
  });

  it('rejects incomplete cards and broken quotes before writing anything', () => {
    expect(() => parseCards('Question\t')).toThrow('nonempty');
    expect(() => parseCards('"Question\tAnswer')).toThrow('closing quote');
    expect(() => parseCards('Question\tAnswer\tExtra')).toThrow('exactly two');
  });
});

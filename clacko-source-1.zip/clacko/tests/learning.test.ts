import { describe, expect, it } from 'vitest';
import { filterStudyCards, newReviewState, scheduleReview } from '../src/core/review';
import {
  keyboardLayouts,
  keyboardModels,
  keyboardRowsFor,
  layoutLabels,
} from '../src/core/keyboards';
import { codeForCharacter, gymLessons, gymText, lessonCodes } from '../src/core/gym';
import { parseMechvibesConfig } from '../src/core/mechvibes';
import { defaultPreferences } from '../src/core/database';

const now = 1700000000000;
const minute = 60000;
const day = minute * 1440;

describe('Clacko review scheduling', () => {
  it('learns, graduates, and relearns without confusing Hard with forgotten', () => {
    const fresh = newReviewState('profile', 'card', 'recall');
    const again = scheduleReview(fresh, 'again', now);
    const hard = scheduleReview(fresh, 'hard', now);
    const good = scheduleReview(fresh, 'good', now);
    expect(again.dueAt).toBe(now + minute);
    expect(hard.dueAt).toBe(now + 6 * minute);
    expect(good.dueAt).toBe(now + 10 * minute);
    const graduated = scheduleReview(good, 'good', good.dueAt);
    expect(graduated.state).toBe('review');
    expect(graduated.dueAt).toBe(good.dueAt + day);
    const failed = scheduleReview(graduated, 'again', graduated.dueAt);
    expect(failed.state).toBe('relearning');
    expect(failed.lapses).toBe(1);
    expect(failed.dueAt).toBe(graduated.dueAt + 10 * minute);
    const difficult = scheduleReview(graduated, 'hard', graduated.dueAt);
    expect(difficult.state).toBe('review');
    expect(difficult.lapses).toBe(0);
    expect(graduated.introducedAt).toBe(now);
  });

  it('keeps direction identities separate and uses longer successful intervals', () => {
    const forward = newReviewState('p', 'c', 'recall');
    const reverse = newReviewState('p', 'c', 'reverse');
    expect(forward.id).not.toBe(reverse.id);
    let state = scheduleReview(forward, 'easy', now);
    expect(state.intervalDays).toBe(4);
    for (let count = 0; count < 10; count++) {
      const next = scheduleReview(state, 'good', state.dueAt);
      expect(next.intervalDays).toBe(
        Math.min(
          3650,
          Math.max(state.intervalDays + 1, Math.round(state.intervalDays * state.ease)),
        ),
      );
      expect(next.dueAt).toBeGreaterThan(state.dueAt);
      state = next;
    }
    expect(forward.state).toBe('new');
    expect(reverse.repetitions).toBe(0);
  });

  it('filters visible material by tags, status, and search while excluding suspension', () => {
    const base = { profileId: 'p', setId: 's', position: 0, tags: ['web'], answer: 'A definition' };
    const cards = [
      { ...base, id: 'a', prompt: 'Alpha', starred: true },
      { ...base, id: 'b', prompt: 'Beta' },
      { ...base, id: 'c', prompt: 'Gamma', suspended: true },
    ];
    const state = {
      ...newReviewState('p', 'b', 'recall'),
      state: 'relearning' as const,
      dueAt: now - 1,
      lapses: 1,
    };
    const filters = { query: '', tag: '', status: 'all' as const };
    expect(filterStudyCards(cards, [state], filters, now).map((card) => card.id)).toEqual([
      'a',
      'b',
    ]);
    expect(
      filterStudyCards(cards, [state], { ...filters, status: 'due' }, now).map((card) => card.id),
    ).toEqual(['b']);
    expect(
      filterStudyCards(cards, [state], { ...filters, status: 'new' }, now).map((card) => card.id),
    ).toEqual(['a']);
    expect(
      filterStudyCards(cards, [state], { ...filters, status: 'weak' }, now).map((card) => card.id),
    ).toEqual(['b']);
    expect(
      filterStudyCards(
        cards,
        [state],
        { ...filters, query: 'definition', tag: 'web', status: 'starred' },
        now,
      ).map((card) => card.id),
    ).toEqual(['a']);
  });
});

describe('models, layouts, and original Gym drills', () => {
  it('produces distinct models without duplicated physical keys', () => {
    for (const model of keyboardModels) {
      const codes = keyboardRowsFor(model.id)
        .flat()
        .map((key) => key.code);
      expect(new Set(codes).size).toBe(codes.length);
    }
    expect(
      keyboardRowsFor('sixty')
        .flat()
        .some((key) => key.code === 'ArrowUp'),
    ).toBe(false);
    expect(
      keyboardRowsFor('sixty-five')
        .flat()
        .some((key) => key.code === 'ArrowUp'),
    ).toBe(true);
    expect(
      keyboardRowsFor('full')
        .flat()
        .some((key) => key.code === 'Numpad9'),
    ).toBe(true);
    expect(
      keyboardRowsFor('tkl')
        .flat()
        .some((key) => key.code === 'Numpad9'),
    ).toBe(false);
    expect(
      keyboardRowsFor('custom', 'colemak', [['KeyQ', 'KeyW'], ['Space']]).map((row) =>
        row.map((key) => key.label),
      ),
    ).toEqual([['q', 'w'], ['clacko']]);
  });

  it('maps regional and alternative labels to physical positions', () => {
    expect(layoutLabels('qwertz-de').KeyY).toBe('z');
    expect(layoutLabels('azerty-fr').KeyA).toBe('q');
    expect(layoutLabels('azerty-fr').Digit2).toBe('é');
    expect(layoutLabels('dvorak').KeyF).toBe('u');
    expect(layoutLabels('colemak').KeyJ).toBe('n');
    expect(codeForCharacter('é', 'azerty-fr')).toBe('Digit2');
  });

  it('uses only acquired keys in every drill across every layout', () => {
    expect(gymLessons).toHaveLength(15);
    for (const layout of keyboardLayouts)
      for (const lesson of gymLessons)
        for (const exercise of ['keys', 'words', 'text'] as const) {
          const target = gymText(lesson.id, layout.id, exercise);
          expect(target.length).toBeGreaterThan(15);
          for (const character of target) {
            if (character === ' ') continue;
            const code = codeForCharacter(character, layout.id);
            expect(code, `${layout.id} lesson ${lesson.id}: ${character}`).toBeDefined();
            expect(
              lessonCodes(lesson.id),
              `${layout.id} lesson ${lesson.id}: ${character} → ${code}`,
            ).toContain(code);
          }
        }
  });
});

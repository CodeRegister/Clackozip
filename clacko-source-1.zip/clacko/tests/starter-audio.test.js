import { describe, it, expect } from 'vitest';
import { readFileSync } from 'node:fs';
import { parseMechvibesConfig } from '../src/core/mechvibes';
import { defaultPreferences } from '../src/core/database';

describe('included recorded starter pack', () => {
  it('ships playable non-silent audio, valid mappings, and provenance as the default', () => {
    const config = JSON.parse(readFileSync('public/starter-pack/config.json', 'utf8'));
    const pack = parseMechvibesConfig(config);
    const wav = readFileSync('public/starter-pack/cherry-brown.wav');
    expect(wav.toString('ascii', 0, 4)).toBe('RIFF');
    expect(wav.toString('ascii', 8, 12)).toBe('WAVE');
    expect(wav.byteLength).toBeGreaterThan(44100);
    expect(wav.subarray(44).some((byte) => byte !== 0)).toBe(true);
    for (const code of ['KeyA', 'Space', 'Enter', 'Backspace', 'Numpad9']) {
      expect(pack.keys[code].down.start).toBeGreaterThanOrEqual(0);
      expect(pack.keys[code].down.end).toBeLessThanOrEqual(1040);
    }
    expect(defaultPreferences('p').soundPackId).toBe('bundled-cherry-brown');
    expect(readFileSync('public/starter-pack/LICENSE.txt', 'utf8')).toContain('CC0');
  });
});

it('preloads the recorded default while suspended and schedules a clip after a gesture', async () => {
  const { vi } = await import('vitest');
  const starts = [];
  let resumes = 0;
  class TestAudioContext {
    state = 'suspended';
    currentTime = 0;
    sampleRate = 44100;
    destination = {};
    createGain() {
      return {
        connect() {},
        disconnect() {},
        gain: {
          value: 1,
          setTargetAtTime() {},
          setValueAtTime() {},
          linearRampToValueAtTime() {},
          cancelScheduledValues() {},
        },
      };
    }
    createBufferSource() {
      return {
        connect() {},
        disconnect() {},
        stop() {},
        playbackRate: { value: 1 },
        start(...args) {
          starts.push(args);
        },
      };
    }
    async decodeAudioData() {
      return { duration: 1.04, length: 45864, numberOfChannels: 1 };
    }
    async resume() {
      resumes++;
      this.state = 'running';
    }
  }
  vi.stubGlobal('AudioContext', TestAudioContext);
  try {
    const { keyboardAudio } = await import('../src/core/audio');
    const parsed = parseMechvibesConfig(
      JSON.parse(readFileSync('public/starter-pack/config.json', 'utf8')),
    );
    keyboardAudio.configure(defaultPreferences('p'));
    await keyboardAudio.preparePack(
      { ...parsed, id: 'bundled-cherry-brown', profileId: '', files: {}, originalConfig: '{}' },
      { 'cherry-brown.wav': new Blob([readFileSync('public/starter-pack/cherry-brown.wav')]) },
    );
    expect(resumes).toBe(0);
    await keyboardAudio.unlock();
    keyboardAudio.play('Space');
    expect(resumes).toBe(1);
    expect(starts).toHaveLength(1);
    expect(starts[0][2]).toBeCloseTo(0.13);
    keyboardAudio.play('Space', false);
    expect(starts).toHaveLength(1);
  } finally {
    vi.unstubAllGlobals();
  }
});

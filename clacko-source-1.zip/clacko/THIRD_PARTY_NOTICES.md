# Third-party notices

## Mechvibes 3

Copyright (c) 2026 Hải Nguyễn. MIT License.

https://github.com/hainguyents13/mechvibes

Source portions adapted into `src/core/legacyKeyCodes.ts` and `src/core/mechvibes.ts`, with source-model adaptation in `types.ts`. Commit and function provenance are recorded in the file headers and `docs/MECHVIBES.md`.

The complete upstream license is included in `licenses/mechvibes-MIT.txt` and must remain with distributed substantial portions of the ports.

Official Mechvibes recordings are not redistributed. The default is a separate CC0 Cherry MX Brown keyboard recording by majod: https://freesound.org/people/majod/sounds/400167/. Clacko edited eight transients from the public preview. See `public/starter-pack/LICENSE.txt`. The Clacko greeting was generated using CMU Flite’s slt voice; its notice is included in `licenses/flite-voice.txt`. User-imported packs retain their own authorship and licensing.

## Fonts

Nunito, Inter, and JetBrains Mono are bundled as local Latin WOFF2 subsets through their Fontsource packages. Their SIL Open Font License texts are included in `licenses/`. They work without a font CDN after installation.

## Other packages

React, React DOM, Dexie, dexie-react-hooks, and fflate provide application functionality. The dependency lockfile records the exact installed versions and resolved packages. Their upstream license notices remain in the respective npm distributions.

/** Package readable source, never credentials, hosting identity, or local data. */
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { zipSync } from 'fflate';

const archiveFiles = {};
const excluded = new Set(['clacko-source.zip', 'node_modules', 'dist', '.git', '.openai']);

async function collectDirectory(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (excluded.has(entry.name)) continue;
    const relativePath = join(directory, entry.name);
    if (entry.isDirectory()) await collectDirectory(relativePath);
    else if (entry.isFile()) archiveFiles[`clacko/${relativePath}`] = new Uint8Array(await readFile(relativePath));
  }
}

for (const directory of ['src', 'public', 'tests', 'scripts', 'docs', 'licenses']) {
  await collectDirectory(directory);
}
for (const file of ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html', '.gitignore', '.prettierrc.json', 'README.md', 'LICENSE', 'THIRD_PARTY_NOTICES.md']) {
  archiveFiles[`clacko/${file}`] = new Uint8Array(await readFile(file));
}

await writeFile('public/clacko-source.zip', zipSync(archiveFiles, { level: 6 }));
console.log(`Packaged ${Object.keys(archiveFiles).length} readable source files.`);

# Mechvibes 3 default-pack provenance

Verified November 9, 2026 against the actual Mechvibes 3 source checkout and the official pack pages.

## What is included

`public/mechvibes/catalog.json` lists the ten keyboard packs bundled by the Mechvibes 3 native application. It records their official pages, the exact official download endpoints observed on those pages, current ZIP revision URLs, author, license label, source path, and config hash.

`public/mechvibes/configs/` contains the ten original configuration files copied byte-for-byte from source commit `56d7135bcdf6ceb7fe2f4e06f8ca0903277a9e68`. All use config format V2 with 104 keyboard mappings, as used by Mechvibes 3. The pinned native source declares application version 3.5.6 in Cargo.toml; its sound-pack configuration format is 2. These version numbers describe different things.

The source/config notice is preserved in `public/mechvibes/LICENSE-code-and-config.txt`.

## Recording permissions are separate

The current official pages label all ten default keyboard packs **Personal use**. Every inspected page lists a separate `LICENSE.txt` inside its downloadable ZIP. The official terms say Personal use packs may not be redistributed or used commercially. The official sound-pack guide also says choosing a software or pack license does not grant rights to someone else's recordings.

Consequently, no sound recordings or pack cover images are copied into this public directory or the downloadable source ZIP. The top-level repository's MIT notice is not represented as overriding the recording-specific terms. The native application providing the recordings free of charge does not establish permission for another app to redistribute them.

Clacko can present these official default packs and send a user to download the pack from Mechvibes, then import it into local browser storage. A direct client-side download may work if the official server permits cross-origin requests; if it does not, use the official download link and local ZIP import. Do not proxy or bundle Personal use recordings merely to avoid a CORS restriction. Imports should retain their original license file and original config.

All ten default keyboard packs were checked; none is currently labeled CC0, CC BY, or MIT on its official pack page. This conclusion is limited to the default packs, not the entire community library.

## Primary evidence

- [Official pack licenses and sharing rules](https://mechvibes.com/docs/sound-packs).
- [Official terms: using packs from the library](https://mechvibes.com/terms).
- [CherryMX Black ABS](https://mechvibes.com/sound-packs/cherrymx-black-abs-keycaps).
- [CherryMX Black PBT](https://mechvibes.com/sound-packs/cherrymx-black-pbt-keycaps).
- [CherryMX Blue ABS](https://mechvibes.com/sound-packs/cherrymx-blue-abs-keycaps).
- [CherryMX Blue PBT](https://mechvibes.com/sound-packs/cherrymx-blue-pbt-keycaps).
- [CherryMX Brown ABS](https://mechvibes.com/sound-packs/cherrymx-brown-abs-keycaps).
- [CherryMX Brown PBT](https://mechvibes.com/sound-packs/cherrymx-brown-pbt-keycaps).
- [CherryMX Red ABS](https://mechvibes.com/sound-packs/cherrymx-red-abs-keycaps).
- [EG Crystal Purple](https://mechvibes.com/sound-packs/eg-crystal-purple).
- [EG Oreo](https://mechvibes.com/sound-packs/eg-oreo).
- [Topre Purple Hybrid PBT](https://mechvibes.com/sound-packs/topre-purple-hybrid-pbt-keycaps).

The ZIP endpoints resolve to the direct URLs recorded in the catalog. Downloading the actual current ZIP was blocked in this research environment, so the separate `LICENSE.txt` text itself was not read and no additional permissions are inferred from it. The license labels and terms above were verified on the official HTML pages.

## Ambient recordings

Mechvibes 3's source includes ten ambient MP3s in `assets/sounds/`: chatter, cricket, fire, forest, ocean, rain, river, stream, thunderstorm, and wind. They have no recording-specific attribution/permission metadata in the inspected checkout. They are not copied into Clacko based only on the code license. Clacko's own procedural ambience and user-owned local files can provide Zen sound profiles independently.

## Further source reuse

Applicable source beyond the existing compatibility ports includes:

- `src/state/ambiance.rs`: separate playback intent from actual muted/silenced state; preserve each track's volume under a master control.
- `src/utils/mood_sounds.rs`: content-addressed imports, locally owned audio, and stable identity for repeated imports.
- `src/state/saved_themes.rs` and `src/components/customize/look_editor.rs`: complete presets, draft changes, and clear saved-theme identity.
- `src/utils/theme_share.rs`: bounded theme containers and validation before applying imported appearance data.

These are source adaptation candidates, not claims that the native Rust audio engine runs in the browser. Mechvibes 3 uses rodio/native input; a browser adapter still needs Web Audio and browser input events.

## Included Clacko starter recording

`public/starter-pack/cherry-brown.wav` is edited from **Cherry MX Brown Mechanical Keyboard Typing** by **majod**, Freesound sound 400167, licensed CC0 1.0 Universal. Source: https://freesound.org/people/majod/sounds/400167/. The public high-quality preview supplied the source bytes. Eight short isolated transients were selected, peak-normalized, faded, and joined into a 1.04-second 44.1 kHz mono PCM WAV. The V2 config maps physical keys to those varied transients; it does not claim to identify individual key recordings. Both WAV and config ship with the app and service-worker cache. This recording is independent of the restricted official Mechvibes default recordings.

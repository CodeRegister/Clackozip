# Typing and learning metrics

## Remix

Clacko uses five characters per word. Active time excludes a paused session and hidden-tab pauses.

- Raw WPM: all evaluated inserted graphemes / 5 / active minutes.
- Adjusted WPM: correctly retained target-position graphemes / 5 / active minutes.
- Accuracy: historically correct insertion events / all evaluated insertion events × 100.

Backspace does not remove historical mistakes. Selection replacement counts the new insertion. Pure deletion adds no insertion. Composition is evaluated after a committed composition event. Spaces and punctuation count. Text is segmented with `Intl.Segmenter` into graphemes, so a combining character or joined emoji is not counted as multiple keystrokes.

Pasting into Remix makes the session unscored; it is still valid exposure/practice. Displayed metrics are zero until enough time/input exists to compute a meaningful value. Empty input displays 100% until the first evaluated insertion. Rates are rounded to integers.

The welcome and personalization playgrounds do not create performance records. They are for experimenting.

## Recall and Reverse

The learner types, reveals the expected answer, and self-evaluates using **Got it** or **Still learning**. The result is recorded under the relevant direction. Typing speed never decides whether the learner remembers the answer.

## Mystery Type

Normalize both answers using Unicode NFC, trim outer whitespace, collapse internal whitespace, and compare case-insensitively. Punctuation remains significant. A timeout is incorrect regardless of the typed draft.

A correct answer earns 100 points plus 20 per previous consecutive correct answer, capped at ten combo bonuses. An incorrect answer resets the combo. The timer pauses with the session; time spent examining the revealed answer does not consume the next question's time.

## Zen

Zen has no accuracy target or mandatory score. Optional counters describe time and characters; they do not measure knowledge. Writing remains local. **Keep this writing** preserves it, while **Discard** clears both the current writing and the preserved copy after confirmation.

## History

Learning attempts and copying performance remain separate. A copied term never marks a flashcard as remembered. Activity counts sessions with actual elapsed time or reviewed cards; starting an untouched session does not create an activity square. Heatmap dates currently use the browser's local timezone. Changing timezone can regroup past sessions; retaining the original study-day timezone is planned.

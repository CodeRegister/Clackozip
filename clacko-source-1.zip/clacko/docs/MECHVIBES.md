# Mechvibes browser adaptation

Upstream: https://github.com/hainguyents13/mechvibes

Inspected application version: **3.5.6**. Its **V2 sound-pack format** is a separate version, not the Mechvibes 2 app.

Research and port commit: `56d7135bcdf6ceb7fe2f4e06f8ca0903277a9e68`.

## Adaptation ledger

| Original source                                                                        | Clacko source                    | Adaptation                                                                                                                                                    |
| -------------------------------------------------------------------------------------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `src/utils/config_converter.rs`: `create_iohook_to_web_key_mapping` and numpad aliases | `legacyKeyCodes.ts`              | The numeric lookup table is translated into a readable TypeScript object.                                                                                     |
| `src/utils/config_converter.rs`: V1 single/multi conversion branches                   | `mechvibes.ts`                   | Preserve numeric mappings and start-plus-duration conversion. Keep per-file buffers instead of concatenating and rewriting a WAV.                             |
| `src/utils/soundpack_validator.rs`: version/structure detection                        | `mechvibes.ts`                   | Recognize legacy fields, normalize aliases, reject unsupported versions, validate ranges and paths. Browser limits are stricter.                              |
| `src/libs/audio/engine.rs`: `lookup_timing`                                            | `mechvibes.ts`: `lookupSegment`  | Press-only versus press/release lookup preserved in a normalized map. Unsupported segment counts are reported and skipped.                                    |
| `src/libs/audio/engine.rs`: `debounce_press`                                           | `mechvibes.ts`: `debouncePress`  | Same transition check using a Set; clear held state on window blur.                                                                                           |
| `src/state/soundpack.rs`                                                               | `types.ts`                       | Browser-specific typed model with per-file media hashes and normalized segments.                                                                              |
| `src/libs/audio/soundpack_loader.rs`                                                   | `audio.ts`, `soundPackImport.ts` | Replaced native filesystem/decoder loading with Blob ownership and browser `decodeAudioData`. Multi clips remain separate and are clamped to their own files. |

The browser playback engine is original Clacko code informed by the native architecture. It is not the native engine compiled for the web. There is no Rust, rodio, OS input hook, or native process in the delivered stack.

## Compatibility boundaries

V1 `[start, duration]` becomes `[start, start + duration]`, and its keyboard clip plays only on press. V2 `[start, end]` is preserved. One segment is press-only; two segments are press and release. More segments remain silent with a warning.

V2 `definitions` / `defs`, `author` / `m_author`, and numeric/string version fields are normalized before playback. For multi-file packs, a missing per-key timing means the entire file. A missing per-key file may use the pack-level audio file. Missing referenced files reject the import. Unknown legacy codes are reported rather than guessed. Mouse-specific packs are outside this release.

Upstream native loading and validation have differences in accepted shapes. Clacko deliberately normalizes known aliases into one browser model rather than promising every upstream edge case. Legacy mouse release encodings are not supported.

Volume is user-controlled; recommended volume seeds the import level. Random-pitch playback uses a small variation when requested by a pack. Original configs and recording bytes are preserved for backup. No native-format configuration is written back to a user's source ZIP.

## Audio lifecycle

Unlock one AudioContext after a user gesture. Decode once per pack selection, then schedule short-lived AudioBufferSourceNodes with reusable buffers. Overlapping foreground voices are capped at 32, and the oldest fades over 10 ms when replaced. Source and gain nodes disconnect when finished. The event path does not access IndexedDB or decode files.

## Verification

Automated tests cover classic timing conversion, field aliases, multi-file mappings, extended key codes, invalid ranges, unsupported segment counts/versions, physical debounce, and ZIP preview. The browser import path was also exercised with the actual upstream Cherry MX Black ABS pack: 104 mappings, OGG decoded before activation. This recording was used only as an internal compatibility fixture and is not shipped in source or app assets.

Additional real-world V1/multi-file collections, Firefox/Safari codecs, and end-to-end audio latency measurements remain to be verified. No universal latency claim is made.

## Official default-pack access

Clacko ships the exact upstream default configurations and the official catalog, including names, authors, URLs, and recording-specific license labels. All ten current default listings specify personal use, so their recordings are installed only into a user's local profile, not redistributed inside Clacko. Retained ZIP license/readme files are stored with the personal import and survive backups. A server CORS restriction may require downloading the official ZIP and importing it locally.

See `MECHVIBES_ASSET_PROVENANCE.md` for the inspected source and catalog verification. Per-key sound overrides reuse installed packs or locally owned clips; prepared audio stays out of the typing input path.

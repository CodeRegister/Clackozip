# Clacko roadmap

This release ships a coherent first working studio, not the entire long-term specification.

## Delivered foundation

- Local profiles, study sets, multiline cards, tags, and original image ownership.
- Six navigation areas and a playable welcome keyboard.
- One input surface shared by five study modes and the live playground.
- Attributed Mechvibes ports, source notices, imported ZIP preview, browser audio preparation.
- Core keyboard/theme/background/type customization and named presets.
- Typing/learning separation, basic weak-card prioritization, session pause and draft recovery.
- Two-column text imports and self-contained profile backups with media integrity checks.
- PWA build, bundled fonts, responsive styling, and readable downloadable source.

## Next: deepen and harden the studios

1. Broaden real pack fixtures and add browser audio performance measurements.
2. Add regional ISO/Shift coverage, full caret interpolation, and preset rename/duplicate. Per-key colors, labels, decals, audio assignments, frame artwork, portable exports, and custom theme tokens are implemented.
3. Add timed/word-count/unlimited Remix and meaningful phrase shuffling.
4. Add in-session card editing, multiple saved session drafts, and adaptive repetition within a session.
5. Move archive/import work to workers and add storage stress/migration tests.
6. Broaden keyboard, screen reader, physical mobile, offline cold-start, and service-worker update verification.

## Expanded personalization delivered

The 0.2 update adds a ten-pack Mechvibes 3.5.6 catalog with recording-specific licensing, local font download/upload, portable keyboard and theme files, original per-key media ownership, and a procedural Zen instrument with pixel, Christmas, spooky, and rain profiles. It also adds local playlist playback and file/folder import. The homepage keeps its note and accepts typing outside form controls.

## Later import coverage

Implement Anki package/SQLite/media-map import using tested version fixtures. Support image occlusion only with explicitly implemented note templates and masks. Preview unsupported content before committing; never silently claim successful conversion.

## Future arcade

All games remain typing-focused. Zombie waves, bosses, and other arcade ideas stay deferred until the Study Studio and Personalization Studio are dependable.

## Learning and keyboard release (0.3)

Delivered: bundled CC0 recorded Cherry MX Brown default; audible homepage greeting; keyboard models, materials and click effects; six unshifted layouts; custom physical rows/widths; untimed card library; selection/filter/star/suspend tools; Anki-inspired spaced review with four ratings, limits and undo; original 15-lesson Clacko Gym with finger hints, weak-key practice, blind practice and per-layout history. Mystery Type is retired; its historic records remain readable. Procedural sound can play in study/Gym or everywhere and individual keys can use generated sounds. Profile backups preserve schedules and Gym runs.

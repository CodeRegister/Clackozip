# Study and touch-typing references

Research checked November 8, 2026. This is implementation guidance, not copied lesson content.

## Anki-inspired review experience

Primary references:

- https://docs.ankiweb.net/manual/studying
- https://docs.ankiweb.net/manual/deck-options
- https://docs.ankiweb.net/manual/filtered-decks

Anki separates new, learning, and due review cards. A learner sees the prompt, reveals the answer, then evaluates recall. Again means forgotten/incorrect; Hard means correct but difficult; Good means correct with effort; Easy means effortless. Answer buttons show the next interval. Shortcuts 1–4 select the ratings. Its study screen does not require a countdown.

Learning steps use short delays before graduation to longer intervals. Again returns a card to an earlier learning step; Good advances it. Failed review cards can enter relearning. Daily new-card and review limits control load. Anki's current scheduling options include FSRS, which is a specific algorithm; a few fixed intervals are not FSRS.

Filtered study can select by state or tags, revisit forgotten cards, review ahead, and preview material without altering its normal schedule. Suspended/buried cards are excluded from regular review. Sorting and limits determine which matching cards enter a session.

## Recommended Clacko adaptation

These choices are original product decisions inspired by the documented interaction:

- Replace Mystery Type with **Spaced Review**. Keep typed recall, answer reveal, four self-ratings, and interval labels; remove the quiz countdown and combo score.
- Store per-card, per-profile, per-direction scheduling state. Front-to-back and reverse practice should not silently overwrite one another.
- A small transparent scheduler may use one-minute and ten-minute learning steps, one-day graduation, and progressively longer review intervals. Name and document it as Clacko's scheduler. Do not label it Anki-compatible or FSRS.
- Put due learning/relearning items first, then due reviews, then the chosen number of new cards. Avoid an immediate duplicate when another card is available. If only a future learning card remains, show its next availability rather than forcing an immediate repeat.
- Preserve user-entered answers and the current card across reloads. Save the rating and updated due date atomically.
- Add a separate **Read Cards** browser: both sides visible, search prompts/answers/tags, deck filter, images, and no timer or grading. Reading must not change review due dates.
- Add individual card selection, select all matching, clear selection, weak/new/due filters, shuffle/order choices, and an explicit number-of-cards control. Show a matched/selected count before beginning.
- Keep **Cram / Practice all** separate from scheduled review, with rescheduling off by default. Make its effect on due dates explicit.
- Useful next controls are suspend/unsuspend, flag/star, skip/bury until tomorrow, and undo last rating. Never delete a card as a consequence of a review rating.

## Touch Typing Study reference

Primary references:

- https://www.typingstudy.com/
- https://www.typingstudy.com/lesson/1
- https://www.typingstudy.com/lesson/2
- https://www.typingstudy.com/speedtest
- https://www.typingstudy.com/keyboard_layouts

The reference offers 15 stepwise lessons, separate speed/typing tests, progress history, and many keyboard layouts. Its introductory material starts at the home row and progressively introduces keys. Lesson sections include new-key drills, broader key practice, words, blind practice, and text. It displays progress, WPM, errors, accuracy, and elapsed time. Its hints emphasize finger guidance and reducing mistakes before chasing speed.

## Original Clacko Gym curriculum

Use newly authored drills and sentences, not the site's exercise text. A compact initial sequence can be:

1. Find the home anchors: physical F/J positions and Space.
2. Home-row inner fingers.
3. Home-row outer fingers.
4. Upper-row index reaches.
5. Upper-row middle and ring reaches.
6. Upper-row pinky reaches.
7. Lower-row index reaches.
8. Lower-row middle/ring/pinky reaches.
9. Shift and capitals.
10. Numbers and common punctuation.
11. Short words using the acquired keys.
12. Original sentences and weak-key practice.

Each stage can provide a brief placement tip, short key patterns, mixed patterns, words where available, and a final passage. Save best accuracy/WPM and completion per layout. Suggest advancing at 95% accuracy, but permit users to revisit or choose another lesson without a compulsory WPM gate. Accuracy-first progression is Clacko's recommendation, not a claim about TypingStudy's threshold.

Use physical key codes for finger zones and typed text for correctness. Layout selection changes labels and drills; it must not silently remap the OS keyboard. Initially support accurate QWERTY (US/UK), Dvorak, and Colemak maps; AZERTY/QWERTZ can follow only with verified mappings. Filipino users commonly use the US-style alphabetic layout, which can be labeled clearly without pretending to implement every regional input method.

Suggested guidance: show the next target key and its finger, optionally color finger zones, retain familiar F/J anchor hints, provide a hands-off-keyboard reminder, and allow the visual keyboard to be hidden for blind practice. Keep lesson elapsed time informational; a timed speed test can be a separate opt-in activity.
